/*
 * Copyright 2003-2026 The IdeaVim authors
 *
 * Use of this source code is governed by an MIT-style
 * license that can be found in the LICENSE.txt file or at
 * https://opensource.org/licenses/MIT.
 */

package com.maddyhome.idea.vim.newapi

import com.intellij.openapi.components.service
import com.intellij.openapi.components.serviceIfCreated
import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.editor.textarea.TextComponentEditorImpl
import com.maddyhome.idea.vim.api.AutoCmdService
import com.maddyhome.idea.vim.api.EngineEditorHelper
import com.maddyhome.idea.vim.api.ExecutionContextManager
import com.maddyhome.idea.vim.api.LocalOptionInitialisationScenario
import com.maddyhome.idea.vim.api.NativeActionManager
import com.maddyhome.idea.vim.api.SearchWindowGroup
import com.maddyhome.idea.vim.api.SystemInfoService
import com.maddyhome.idea.vim.api.VimAbbreviationGroup
import com.maddyhome.idea.vim.api.VimActionExecutor
import com.maddyhome.idea.vim.api.VimApplication
import com.maddyhome.idea.vim.api.VimChangeGroup
import com.maddyhome.idea.vim.api.VimClipboardManager
import com.maddyhome.idea.vim.api.VimCommandGroup
import com.maddyhome.idea.vim.api.VimCommandLineService
import com.maddyhome.idea.vim.api.VimDigraphGroup
import com.maddyhome.idea.vim.api.VimEditor
import com.maddyhome.idea.vim.api.VimEditorGroup
import com.maddyhome.idea.vim.api.VimEnabler
import com.maddyhome.idea.vim.api.VimExtensionRegistrator
import com.maddyhome.idea.vim.api.VimExternalOpener
import com.maddyhome.idea.vim.api.VimFile
import com.maddyhome.idea.vim.api.VimInjector
import com.maddyhome.idea.vim.api.VimInjectorBase
import com.maddyhome.idea.vim.api.VimJumpService
import com.maddyhome.idea.vim.api.VimKeyGroup
import com.maddyhome.idea.vim.api.VimKeymapGroup
import com.maddyhome.idea.vim.api.VimLookupManager
import com.maddyhome.idea.vim.api.VimMarkService
import com.maddyhome.idea.vim.api.VimMessages
import com.maddyhome.idea.vim.api.VimModalInputService
import com.maddyhome.idea.vim.api.VimMotionGroup
import com.maddyhome.idea.vim.api.VimOptionGroup
import com.maddyhome.idea.vim.api.VimOutputPanelService
import com.maddyhome.idea.vim.api.VimPathExpansion
import com.maddyhome.idea.vim.api.VimPathExpansionImpl
import com.maddyhome.idea.vim.api.VimPluginActivator
import com.maddyhome.idea.vim.api.VimProcessGroup
import com.maddyhome.idea.vim.api.VimPsiService
import com.maddyhome.idea.vim.api.VimRedrawService
import com.maddyhome.idea.vim.api.VimRegexServiceBase
import com.maddyhome.idea.vim.api.VimRegexpService
import com.maddyhome.idea.vim.api.VimScrollGroup
import com.maddyhome.idea.vim.api.VimSearchGroup
import com.maddyhome.idea.vim.api.VimSearchHelper
import com.maddyhome.idea.vim.api.VimStatistics
import com.maddyhome.idea.vim.api.VimStorageService
import com.maddyhome.idea.vim.api.VimStringParser
import com.maddyhome.idea.vim.api.VimTemplateManager
import com.maddyhome.idea.vim.api.VimVisualMotionGroup
import com.maddyhome.idea.vim.api.VimrcFileState
import com.maddyhome.idea.vim.api.VimscriptExecutor
import com.maddyhome.idea.vim.api.VimscriptFunctionService
import com.maddyhome.idea.vim.api.VimscriptParser
import com.maddyhome.idea.vim.api.VirtualBufferGroup
import com.maddyhome.idea.vim.api.injector
import com.maddyhome.idea.vim.api.isInjectorInitialized
import com.maddyhome.idea.vim.diagnostic.VimLogger
import com.maddyhome.idea.vim.extension.ExtensionLoader
import com.maddyhome.idea.vim.extension.JsonExtensionProvider
import com.maddyhome.idea.vim.group.EffectiveIjOptions
import com.maddyhome.idea.vim.group.GlobalIjOptions
import com.maddyhome.idea.vim.group.IjVimOptionGroup
import com.maddyhome.idea.vim.group.LineChangeGroup
import com.maddyhome.idea.vim.group.TabService
import com.maddyhome.idea.vim.group.VimWindowGroup
import com.maddyhome.idea.vim.history.VimHistory
import com.maddyhome.idea.vim.macro.VimMacro
import com.maddyhome.idea.vim.put.VimPut
import com.maddyhome.idea.vim.register.VimRegisterGroup
import com.maddyhome.idea.vim.thinapi.VimHighlightingService
import com.maddyhome.idea.vim.thinapi.VimPluginService
import com.maddyhome.idea.vim.undo.LineChange
import com.maddyhome.idea.vim.undo.VimUndoRedo
import com.maddyhome.idea.vim.vimscript.services.VariableService
import com.maddyhome.idea.vim.yank.VimYankGroup
import javax.swing.JTextArea

/**
 * Currently, injector has to be initialized in all "entry points" from the IJ platform.
 * This means Project Activities, listeners, status bar widgets, statistic collectors, etc.
 * This is a bad pattern and we need to find a solution where the plugin doesn't have an "uninitialized state"
 */
fun initInjector() {
  if (isInjectorInitialized()) return
  injector = IjVimInjector()
}

internal class IjVimInjector : VimInjectorBase() {
  override fun <T : Any> getLogger(clazz: Class<T>): VimLogger = IjVimLogger(Logger.getInstance(clazz))

  override val fallbackWindow: VimEditor by lazy {
    TextComponentEditorImpl(null, JTextArea()).vim.also {
      optionGroup.initialiseLocalOptions(it, null, LocalOptionInitialisationScenario.DEFAULTS)
    }
  }

  override val actionExecutor: VimActionExecutor
    get() = service()
  override val historyGroup: VimHistory
    get() = service()
  override val extensionRegistrator: VimExtensionRegistrator
    get() = service()
  override val jsonExtensionProvider: JsonExtensionProvider
    get() = service()
  override val extensionLoader: ExtensionLoader
    get() = service()
  override val tabService: TabService
    get() = service()
  override val regexpService: VimRegexpService
    get() = VimRegexServiceBase()
  override val clipboardManager: VimClipboardManager
    get() = service()
  override val searchHelper: VimSearchHelper
    get() = service()
  override val motion: VimMotionGroup
    get() = service()
  override val scroll: VimScrollGroup
    get() = service()
  override val lookupManager: VimLookupManager
    get() = service()
  override val templateManager: VimTemplateManager
    get() = service()
  override val searchGroup: VimSearchGroup
    get() = service()
  override val virtualBufferGroup: VirtualBufferGroup
    get() = service()
  override val searchWindowGroup: SearchWindowGroup
    get() = service()
  override val put: VimPut
    get() = service()
  override val window: VimWindowGroup
    get() = service()
  override val yank: VimYankGroup
    get() = service()
  override val file: VimFile
    get() = service()
  override val macro: VimMacro
    get() = service()
  override val undo: VimUndoRedo
    get() = service()
  override val lineChange: LineChange
    get() = LineChangeGroup
  override val psiService: VimPsiService
    get() = service()
  override val nativeActionManager: NativeActionManager
    get() = service()
  override val messages: VimMessages
    get() = service()
  override val registerGroup: VimRegisterGroup
    get() = service()
  override val registerGroupIfCreated: VimRegisterGroup?
    get() = serviceIfCreated()
  override val changeGroup: VimChangeGroup
    get() = service()
  override val processGroup: VimProcessGroup
    get() = service()
  override val keyGroup: VimKeyGroup
    get() = service()
  override val keymapGroup: VimKeymapGroup
    get() = service()
  override val abbreviationGroup: VimAbbreviationGroup
    get() = service()

  override val markService: VimMarkService
    get() = service()
  override val jumpService: VimJumpService
    get() = service()
  override val application: VimApplication
    get() = service()
  override val executionContextManager: ExecutionContextManager
    get() = service()
  override val enabler: VimEnabler
    get() = service()
  override val digraphGroup: VimDigraphGroup
    get() = service()
  override val visualMotionGroup: VimVisualMotionGroup
    get() = service()
  override val statisticsService: VimStatistics
    get() = service()
  override val commandGroup: VimCommandGroup
    get() = service()

  override val functionService: VimscriptFunctionService
    get() = service()
  override val variableService: VariableService
    get() = service()
  override val vimrcFileState: VimrcFileState
    get() = service()
  override val vimscriptExecutor: VimscriptExecutor
    get() = service()
  override val vimscriptParser: VimscriptParser
    get() = com.maddyhome.idea.vim.vimscript.parser.VimscriptParser
  override val commandLine: VimCommandLineService
    get() = service()
  override val modalInput: VimModalInputService
    get() = service()
  override val outputPanel: VimOutputPanelService
    get() = service()

  override val optionGroup: VimOptionGroup
    get() = service()
  override val parser: VimStringParser
    get() = service()

  override val systemInfoService: SystemInfoService
    get() = service()
  override val vimStorageService: VimStorageService
    get() = service()
  override val redrawService: VimRedrawService
    get() = service()
  override val pluginService: VimPluginService
    get() = service()
  override val highlightingService: VimHighlightingService
    get() = service()

  override val pathExpansion: VimPathExpansion = VimPathExpansionImpl()

  override val engineEditorHelper: EngineEditorHelper
    get() = service()
  override val editorGroup: VimEditorGroup
    get() = service()
  override val pluginActivator: VimPluginActivator
    get() = service()
  override val externalOpener: VimExternalOpener
    get() = service()

  override val autoCmd: AutoCmdService get() = service<AutoCmdService>()
}

/**
 * Convenience function to get the IntelliJ implementation specific global option accessor
 */
fun VimInjector.globalIjOptions(): GlobalIjOptions = (this.optionGroup as IjVimOptionGroup).getGlobalIjOptions()

/**
 * Convenience function to get the IntelliJ implementation specific option accessor for the given editor's scope
 */
fun VimInjector.ijOptions(editor: VimEditor): EffectiveIjOptions =
  (this.optionGroup as IjVimOptionGroup).getEffectiveIjOptions(editor)
