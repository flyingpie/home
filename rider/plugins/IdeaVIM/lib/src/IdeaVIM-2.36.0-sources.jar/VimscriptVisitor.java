// Generated from Vimscript.g4 by ANTLR 4.13.2
package com.maddyhome.idea.vim.parser.generated;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link VimscriptParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface VimscriptVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#script}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitScript(VimscriptParser.ScriptContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#forLoop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitForLoop(VimscriptParser.ForLoopContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#whileLoop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileLoop(VimscriptParser.WhileLoopContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#blockMember}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockMember(VimscriptParser.BlockMemberContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#comment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComment(VimscriptParser.CommentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#finishStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFinishStatement(VimscriptParser.FinishStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#continueStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitContinueStatement(VimscriptParser.ContinueStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#breakStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBreakStatement(VimscriptParser.BreakStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#returnStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStatement(VimscriptParser.ReturnStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#throwStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitThrowStatement(VimscriptParser.ThrowStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#ifStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStatement(VimscriptParser.IfStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#ifBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfBlock(VimscriptParser.IfBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#elifBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElifBlock(VimscriptParser.ElifBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#elseBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElseBlock(VimscriptParser.ElseBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#tryStatement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTryStatement(VimscriptParser.TryStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#tryBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTryBlock(VimscriptParser.TryBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#catchBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCatchBlock(VimscriptParser.CatchBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#pattern}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPattern(VimscriptParser.PatternContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#patternBody}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPatternBody(VimscriptParser.PatternBodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#finallyBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFinallyBlock(VimscriptParser.FinallyBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#functionDefinition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionDefinition(VimscriptParser.FunctionDefinitionContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#functionFlag}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionFlag(VimscriptParser.FunctionFlagContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#argumentsDeclaration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgumentsDeclaration(VimscriptParser.ArgumentsDeclarationContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#defaultValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDefaultValue(VimscriptParser.DefaultValueContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#autoCmd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAutoCmd(VimscriptParser.AutoCmdContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#auEvents}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAuEvents(VimscriptParser.AuEventsContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#auEventName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAuEventName(VimscriptParser.AuEventNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#auPattern}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAuPattern(VimscriptParser.AuPatternContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#auCommand}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAuCommand(VimscriptParser.AuCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code GoToLineCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGoToLineCommand(VimscriptParser.GoToLineCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LetCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLetCommand(VimscriptParser.LetCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EchoCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEchoCommand(VimscriptParser.EchoCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code DelfunctionCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDelfunctionCommand(VimscriptParser.DelfunctionCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CallCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallCommand(VimscriptParser.CallCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ExecuteCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExecuteCommand(VimscriptParser.ExecuteCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ShiftLeftCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShiftLeftCommand(VimscriptParser.ShiftLeftCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ShiftRightCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShiftRightCommand(VimscriptParser.ShiftRightCommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CommandWithComment}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommandWithComment(VimscriptParser.CommandWithCommentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CommandWithoutComments}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommandWithoutComments(VimscriptParser.CommandWithoutCommentsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CommandWithBars}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommandWithBars(VimscriptParser.CommandWithBarsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code OtherCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOtherCommand(VimscriptParser.OtherCommandContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#commandArgumentWithBars}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommandArgumentWithBars(VimscriptParser.CommandArgumentWithBarsContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#commandArgumentWithoutBars}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommandArgumentWithoutBars(VimscriptParser.CommandArgumentWithoutBarsContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#lShift}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLShift(VimscriptParser.LShiftContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#rShift}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRShift(VimscriptParser.RShiftContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Let1Command}
	 * labeled alternative in {@link VimscriptParser#letCommands}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLet1Command(VimscriptParser.Let1CommandContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Let2Command}
	 * labeled alternative in {@link VimscriptParser#letCommands}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLet2Command(VimscriptParser.Let2CommandContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#unpackLValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnpackLValue(VimscriptParser.UnpackLValueContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#assignmentOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignmentOperator(VimscriptParser.AssignmentOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#plusAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlusAssign(VimscriptParser.PlusAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#minusAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMinusAssign(VimscriptParser.MinusAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#startAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStartAssign(VimscriptParser.StartAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#divAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDivAssign(VimscriptParser.DivAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#modAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitModAssign(VimscriptParser.ModAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#dotAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDotAssign(VimscriptParser.DotAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#dotDotAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDotDotAssign(VimscriptParser.DotDotAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#shortRange}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortRange(VimscriptParser.ShortRangeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#range}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRange(VimscriptParser.RangeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#rangeUnit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeUnit(VimscriptParser.RangeUnitContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#rangeExpression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeExpression(VimscriptParser.RangeExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#rangeMember}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeMember(VimscriptParser.RangeMemberContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#rangeSeparator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeSeparator(VimscriptParser.RangeSeparatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#search}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSearch(VimscriptParser.SearchContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#rangeOffset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeOffset(VimscriptParser.RangeOffsetContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#numberInOffset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumberInOffset(VimscriptParser.NumberInOffsetContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#plusOneOffset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPlusOneOffset(VimscriptParser.PlusOneOffsetContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#minusOneOffset}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMinusOneOffset(VimscriptParser.MinusOneOffsetContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#commandName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommandName(VimscriptParser.CommandNameContext ctx);
	/**
	 * Visit a parse tree produced by the {@code TernaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTernaryExpression(VimscriptParser.TernaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code DictionaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictionaryExpression(VimscriptParser.DictionaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LogicalAndExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalAndExpression(VimscriptParser.LogicalAndExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FunctionAsMethodCall1}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionAsMethodCall1(VimscriptParser.FunctionAsMethodCall1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code LambdaFunctionCallExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLambdaFunctionCallExpression(VimscriptParser.LambdaFunctionCallExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LogicalOrExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalOrExpression(VimscriptParser.LogicalOrExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FunctionAsMethodCall2}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionAsMethodCall2(VimscriptParser.FunctionAsMethodCall2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code BitwiseShiftExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBitwiseShiftExpression(VimscriptParser.BitwiseShiftExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryExpression(VimscriptParser.UnaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FalsyExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFalsyExpression(VimscriptParser.FalsyExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FunctionCallExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionCallExpression(VimscriptParser.FunctionCallExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RegisterExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRegisterExpression(VimscriptParser.RegisterExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LiteralDictionaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteralDictionaryExpression(VimscriptParser.LiteralDictionaryExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code OptionExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOptionExpression(VimscriptParser.OptionExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code MultiplicativeExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiplicativeExpression(VimscriptParser.MultiplicativeExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BlobExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlobExpression(VimscriptParser.BlobExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AdditiveExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdditiveExpression(VimscriptParser.AdditiveExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IntExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntExpression(VimscriptParser.IntExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ListExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitListExpression(VimscriptParser.ListExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FloatExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatExpression(VimscriptParser.FloatExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code VariableExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariableExpression(VimscriptParser.VariableExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EnvVariableExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnvVariableExpression(VimscriptParser.EnvVariableExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code SublistExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSublistExpression(VimscriptParser.SublistExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ComparisonExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonExpression(VimscriptParser.ComparisonExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IndexedExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIndexedExpression(VimscriptParser.IndexedExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StringExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringExpression(VimscriptParser.StringExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code WrappedExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWrappedExpression(VimscriptParser.WrappedExpressionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LambdaExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLambdaExpression(VimscriptParser.LambdaExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#multiplicativeOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultiplicativeOperator(VimscriptParser.MultiplicativeOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#additiveOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAdditiveOperator(VimscriptParser.AdditiveOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#comparisonOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComparisonOperator(VimscriptParser.ComparisonOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#bitwiseShiftOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBitwiseShiftOperator(VimscriptParser.BitwiseShiftOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#logicalAndOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalAndOperator(VimscriptParser.LogicalAndOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#logicalOrOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalOrOperator(VimscriptParser.LogicalOrOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#register}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRegister(VimscriptParser.RegisterContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#lambda}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLambda(VimscriptParser.LambdaContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable(VimscriptParser.VariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#variableName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariableName(VimscriptParser.VariableNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#variableScope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariableScope(VimscriptParser.VariableScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#curlyBracesName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCurlyBracesName(VimscriptParser.CurlyBracesNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElement(VimscriptParser.ElementContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOption(VimscriptParser.OptionContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#optionName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOptionName(VimscriptParser.OptionNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#optionScope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOptionScope(VimscriptParser.OptionScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#envVariable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnvVariable(VimscriptParser.EnvVariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#envVariableName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEnvVariableName(VimscriptParser.EnvVariableNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#functionCall}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionCall(VimscriptParser.FunctionCallContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#functionName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionName(VimscriptParser.FunctionNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#functionScope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionScope(VimscriptParser.FunctionScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#functionArguments}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionArguments(VimscriptParser.FunctionArgumentsContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#functionArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunctionArgument(VimscriptParser.FunctionArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitList(VimscriptParser.ListContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#dictionary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictionary(VimscriptParser.DictionaryContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#dictionaryEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDictionaryEntry(VimscriptParser.DictionaryEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#literalDictionary}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteralDictionary(VimscriptParser.LiteralDictionaryContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#literalDictionaryEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteralDictionaryEntry(VimscriptParser.LiteralDictionaryEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#literalDictionaryKey}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteralDictionaryKey(VimscriptParser.LiteralDictionaryKeyContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#anyScope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyScope(VimscriptParser.AnyScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#string}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitString(VimscriptParser.StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#unsignedFloat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnsignedFloat(VimscriptParser.UnsignedFloatContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#unsignedInt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnsignedInt(VimscriptParser.UnsignedIntContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#blob}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlob(VimscriptParser.BlobContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#mark}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMark(VimscriptParser.MarkContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#inline_comment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInline_comment(VimscriptParser.Inline_commentContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#anyCaseNameWithDigitsAndUnderscores}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyCaseNameWithDigitsAndUnderscores(VimscriptParser.AnyCaseNameWithDigitsAndUnderscoresContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#anyCaseNameWithDigitsAndUnderscoresExceptKeywords}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyCaseNameWithDigitsAndUnderscoresExceptKeywords(VimscriptParser.AnyCaseNameWithDigitsAndUnderscoresExceptKeywordsContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#uppercaseAlphabeticChar}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUppercaseAlphabeticChar(VimscriptParser.UppercaseAlphabeticCharContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#lowercaseAlphabeticChar}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLowercaseAlphabeticChar(VimscriptParser.LowercaseAlphabeticCharContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#keyword}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeyword(VimscriptParser.KeywordContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperator(VimscriptParser.OperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link VimscriptParser#existingCommands}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExistingCommands(VimscriptParser.ExistingCommandsContext ctx);
}