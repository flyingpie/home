// Generated from Vimscript.g4 by ANTLR 4.13.2
package com.maddyhome.idea.vim.parser.generated;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link VimscriptParser}.
 */
public interface VimscriptListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#script}.
	 * @param ctx the parse tree
	 */
	void enterScript(VimscriptParser.ScriptContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#script}.
	 * @param ctx the parse tree
	 */
	void exitScript(VimscriptParser.ScriptContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#forLoop}.
	 * @param ctx the parse tree
	 */
	void enterForLoop(VimscriptParser.ForLoopContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#forLoop}.
	 * @param ctx the parse tree
	 */
	void exitForLoop(VimscriptParser.ForLoopContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#whileLoop}.
	 * @param ctx the parse tree
	 */
	void enterWhileLoop(VimscriptParser.WhileLoopContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#whileLoop}.
	 * @param ctx the parse tree
	 */
	void exitWhileLoop(VimscriptParser.WhileLoopContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#blockMember}.
	 * @param ctx the parse tree
	 */
	void enterBlockMember(VimscriptParser.BlockMemberContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#blockMember}.
	 * @param ctx the parse tree
	 */
	void exitBlockMember(VimscriptParser.BlockMemberContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#comment}.
	 * @param ctx the parse tree
	 */
	void enterComment(VimscriptParser.CommentContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#comment}.
	 * @param ctx the parse tree
	 */
	void exitComment(VimscriptParser.CommentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#finishStatement}.
	 * @param ctx the parse tree
	 */
	void enterFinishStatement(VimscriptParser.FinishStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#finishStatement}.
	 * @param ctx the parse tree
	 */
	void exitFinishStatement(VimscriptParser.FinishStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#continueStatement}.
	 * @param ctx the parse tree
	 */
	void enterContinueStatement(VimscriptParser.ContinueStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#continueStatement}.
	 * @param ctx the parse tree
	 */
	void exitContinueStatement(VimscriptParser.ContinueStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#breakStatement}.
	 * @param ctx the parse tree
	 */
	void enterBreakStatement(VimscriptParser.BreakStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#breakStatement}.
	 * @param ctx the parse tree
	 */
	void exitBreakStatement(VimscriptParser.BreakStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void enterReturnStatement(VimscriptParser.ReturnStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#returnStatement}.
	 * @param ctx the parse tree
	 */
	void exitReturnStatement(VimscriptParser.ReturnStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#throwStatement}.
	 * @param ctx the parse tree
	 */
	void enterThrowStatement(VimscriptParser.ThrowStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#throwStatement}.
	 * @param ctx the parse tree
	 */
	void exitThrowStatement(VimscriptParser.ThrowStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void enterIfStatement(VimscriptParser.IfStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#ifStatement}.
	 * @param ctx the parse tree
	 */
	void exitIfStatement(VimscriptParser.IfStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#ifBlock}.
	 * @param ctx the parse tree
	 */
	void enterIfBlock(VimscriptParser.IfBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#ifBlock}.
	 * @param ctx the parse tree
	 */
	void exitIfBlock(VimscriptParser.IfBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#elifBlock}.
	 * @param ctx the parse tree
	 */
	void enterElifBlock(VimscriptParser.ElifBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#elifBlock}.
	 * @param ctx the parse tree
	 */
	void exitElifBlock(VimscriptParser.ElifBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#elseBlock}.
	 * @param ctx the parse tree
	 */
	void enterElseBlock(VimscriptParser.ElseBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#elseBlock}.
	 * @param ctx the parse tree
	 */
	void exitElseBlock(VimscriptParser.ElseBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#tryStatement}.
	 * @param ctx the parse tree
	 */
	void enterTryStatement(VimscriptParser.TryStatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#tryStatement}.
	 * @param ctx the parse tree
	 */
	void exitTryStatement(VimscriptParser.TryStatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#tryBlock}.
	 * @param ctx the parse tree
	 */
	void enterTryBlock(VimscriptParser.TryBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#tryBlock}.
	 * @param ctx the parse tree
	 */
	void exitTryBlock(VimscriptParser.TryBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#catchBlock}.
	 * @param ctx the parse tree
	 */
	void enterCatchBlock(VimscriptParser.CatchBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#catchBlock}.
	 * @param ctx the parse tree
	 */
	void exitCatchBlock(VimscriptParser.CatchBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#pattern}.
	 * @param ctx the parse tree
	 */
	void enterPattern(VimscriptParser.PatternContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#pattern}.
	 * @param ctx the parse tree
	 */
	void exitPattern(VimscriptParser.PatternContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#patternBody}.
	 * @param ctx the parse tree
	 */
	void enterPatternBody(VimscriptParser.PatternBodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#patternBody}.
	 * @param ctx the parse tree
	 */
	void exitPatternBody(VimscriptParser.PatternBodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#finallyBlock}.
	 * @param ctx the parse tree
	 */
	void enterFinallyBlock(VimscriptParser.FinallyBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#finallyBlock}.
	 * @param ctx the parse tree
	 */
	void exitFinallyBlock(VimscriptParser.FinallyBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#functionDefinition}.
	 * @param ctx the parse tree
	 */
	void enterFunctionDefinition(VimscriptParser.FunctionDefinitionContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#functionDefinition}.
	 * @param ctx the parse tree
	 */
	void exitFunctionDefinition(VimscriptParser.FunctionDefinitionContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#functionFlag}.
	 * @param ctx the parse tree
	 */
	void enterFunctionFlag(VimscriptParser.FunctionFlagContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#functionFlag}.
	 * @param ctx the parse tree
	 */
	void exitFunctionFlag(VimscriptParser.FunctionFlagContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#argumentsDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterArgumentsDeclaration(VimscriptParser.ArgumentsDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#argumentsDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitArgumentsDeclaration(VimscriptParser.ArgumentsDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#defaultValue}.
	 * @param ctx the parse tree
	 */
	void enterDefaultValue(VimscriptParser.DefaultValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#defaultValue}.
	 * @param ctx the parse tree
	 */
	void exitDefaultValue(VimscriptParser.DefaultValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#autoCmd}.
	 * @param ctx the parse tree
	 */
	void enterAutoCmd(VimscriptParser.AutoCmdContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#autoCmd}.
	 * @param ctx the parse tree
	 */
	void exitAutoCmd(VimscriptParser.AutoCmdContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#auEvents}.
	 * @param ctx the parse tree
	 */
	void enterAuEvents(VimscriptParser.AuEventsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#auEvents}.
	 * @param ctx the parse tree
	 */
	void exitAuEvents(VimscriptParser.AuEventsContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#auEventName}.
	 * @param ctx the parse tree
	 */
	void enterAuEventName(VimscriptParser.AuEventNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#auEventName}.
	 * @param ctx the parse tree
	 */
	void exitAuEventName(VimscriptParser.AuEventNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#auPattern}.
	 * @param ctx the parse tree
	 */
	void enterAuPattern(VimscriptParser.AuPatternContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#auPattern}.
	 * @param ctx the parse tree
	 */
	void exitAuPattern(VimscriptParser.AuPatternContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#auCommand}.
	 * @param ctx the parse tree
	 */
	void enterAuCommand(VimscriptParser.AuCommandContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#auCommand}.
	 * @param ctx the parse tree
	 */
	void exitAuCommand(VimscriptParser.AuCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code GoToLineCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterGoToLineCommand(VimscriptParser.GoToLineCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code GoToLineCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitGoToLineCommand(VimscriptParser.GoToLineCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LetCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterLetCommand(VimscriptParser.LetCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LetCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitLetCommand(VimscriptParser.LetCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EchoCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterEchoCommand(VimscriptParser.EchoCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EchoCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitEchoCommand(VimscriptParser.EchoCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code DelfunctionCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterDelfunctionCommand(VimscriptParser.DelfunctionCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code DelfunctionCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitDelfunctionCommand(VimscriptParser.DelfunctionCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CallCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterCallCommand(VimscriptParser.CallCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CallCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitCallCommand(VimscriptParser.CallCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ExecuteCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterExecuteCommand(VimscriptParser.ExecuteCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ExecuteCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitExecuteCommand(VimscriptParser.ExecuteCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ShiftLeftCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterShiftLeftCommand(VimscriptParser.ShiftLeftCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ShiftLeftCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitShiftLeftCommand(VimscriptParser.ShiftLeftCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ShiftRightCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterShiftRightCommand(VimscriptParser.ShiftRightCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ShiftRightCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitShiftRightCommand(VimscriptParser.ShiftRightCommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CommandWithComment}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterCommandWithComment(VimscriptParser.CommandWithCommentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CommandWithComment}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitCommandWithComment(VimscriptParser.CommandWithCommentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CommandWithoutComments}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterCommandWithoutComments(VimscriptParser.CommandWithoutCommentsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CommandWithoutComments}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitCommandWithoutComments(VimscriptParser.CommandWithoutCommentsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CommandWithBars}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterCommandWithBars(VimscriptParser.CommandWithBarsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CommandWithBars}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitCommandWithBars(VimscriptParser.CommandWithBarsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code OtherCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void enterOtherCommand(VimscriptParser.OtherCommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code OtherCommand}
	 * labeled alternative in {@link VimscriptParser#command}.
	 * @param ctx the parse tree
	 */
	void exitOtherCommand(VimscriptParser.OtherCommandContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#commandArgumentWithBars}.
	 * @param ctx the parse tree
	 */
	void enterCommandArgumentWithBars(VimscriptParser.CommandArgumentWithBarsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#commandArgumentWithBars}.
	 * @param ctx the parse tree
	 */
	void exitCommandArgumentWithBars(VimscriptParser.CommandArgumentWithBarsContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#commandArgumentWithoutBars}.
	 * @param ctx the parse tree
	 */
	void enterCommandArgumentWithoutBars(VimscriptParser.CommandArgumentWithoutBarsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#commandArgumentWithoutBars}.
	 * @param ctx the parse tree
	 */
	void exitCommandArgumentWithoutBars(VimscriptParser.CommandArgumentWithoutBarsContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#lShift}.
	 * @param ctx the parse tree
	 */
	void enterLShift(VimscriptParser.LShiftContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#lShift}.
	 * @param ctx the parse tree
	 */
	void exitLShift(VimscriptParser.LShiftContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#rShift}.
	 * @param ctx the parse tree
	 */
	void enterRShift(VimscriptParser.RShiftContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#rShift}.
	 * @param ctx the parse tree
	 */
	void exitRShift(VimscriptParser.RShiftContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Let1Command}
	 * labeled alternative in {@link VimscriptParser#letCommands}.
	 * @param ctx the parse tree
	 */
	void enterLet1Command(VimscriptParser.Let1CommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Let1Command}
	 * labeled alternative in {@link VimscriptParser#letCommands}.
	 * @param ctx the parse tree
	 */
	void exitLet1Command(VimscriptParser.Let1CommandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Let2Command}
	 * labeled alternative in {@link VimscriptParser#letCommands}.
	 * @param ctx the parse tree
	 */
	void enterLet2Command(VimscriptParser.Let2CommandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Let2Command}
	 * labeled alternative in {@link VimscriptParser#letCommands}.
	 * @param ctx the parse tree
	 */
	void exitLet2Command(VimscriptParser.Let2CommandContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#unpackLValue}.
	 * @param ctx the parse tree
	 */
	void enterUnpackLValue(VimscriptParser.UnpackLValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#unpackLValue}.
	 * @param ctx the parse tree
	 */
	void exitUnpackLValue(VimscriptParser.UnpackLValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#assignmentOperator}.
	 * @param ctx the parse tree
	 */
	void enterAssignmentOperator(VimscriptParser.AssignmentOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#assignmentOperator}.
	 * @param ctx the parse tree
	 */
	void exitAssignmentOperator(VimscriptParser.AssignmentOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#plusAssign}.
	 * @param ctx the parse tree
	 */
	void enterPlusAssign(VimscriptParser.PlusAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#plusAssign}.
	 * @param ctx the parse tree
	 */
	void exitPlusAssign(VimscriptParser.PlusAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#minusAssign}.
	 * @param ctx the parse tree
	 */
	void enterMinusAssign(VimscriptParser.MinusAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#minusAssign}.
	 * @param ctx the parse tree
	 */
	void exitMinusAssign(VimscriptParser.MinusAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#startAssign}.
	 * @param ctx the parse tree
	 */
	void enterStartAssign(VimscriptParser.StartAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#startAssign}.
	 * @param ctx the parse tree
	 */
	void exitStartAssign(VimscriptParser.StartAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#divAssign}.
	 * @param ctx the parse tree
	 */
	void enterDivAssign(VimscriptParser.DivAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#divAssign}.
	 * @param ctx the parse tree
	 */
	void exitDivAssign(VimscriptParser.DivAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#modAssign}.
	 * @param ctx the parse tree
	 */
	void enterModAssign(VimscriptParser.ModAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#modAssign}.
	 * @param ctx the parse tree
	 */
	void exitModAssign(VimscriptParser.ModAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#dotAssign}.
	 * @param ctx the parse tree
	 */
	void enterDotAssign(VimscriptParser.DotAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#dotAssign}.
	 * @param ctx the parse tree
	 */
	void exitDotAssign(VimscriptParser.DotAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#dotDotAssign}.
	 * @param ctx the parse tree
	 */
	void enterDotDotAssign(VimscriptParser.DotDotAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#dotDotAssign}.
	 * @param ctx the parse tree
	 */
	void exitDotDotAssign(VimscriptParser.DotDotAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#shortRange}.
	 * @param ctx the parse tree
	 */
	void enterShortRange(VimscriptParser.ShortRangeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#shortRange}.
	 * @param ctx the parse tree
	 */
	void exitShortRange(VimscriptParser.ShortRangeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#range}.
	 * @param ctx the parse tree
	 */
	void enterRange(VimscriptParser.RangeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#range}.
	 * @param ctx the parse tree
	 */
	void exitRange(VimscriptParser.RangeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#rangeUnit}.
	 * @param ctx the parse tree
	 */
	void enterRangeUnit(VimscriptParser.RangeUnitContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#rangeUnit}.
	 * @param ctx the parse tree
	 */
	void exitRangeUnit(VimscriptParser.RangeUnitContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#rangeExpression}.
	 * @param ctx the parse tree
	 */
	void enterRangeExpression(VimscriptParser.RangeExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#rangeExpression}.
	 * @param ctx the parse tree
	 */
	void exitRangeExpression(VimscriptParser.RangeExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#rangeMember}.
	 * @param ctx the parse tree
	 */
	void enterRangeMember(VimscriptParser.RangeMemberContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#rangeMember}.
	 * @param ctx the parse tree
	 */
	void exitRangeMember(VimscriptParser.RangeMemberContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#rangeSeparator}.
	 * @param ctx the parse tree
	 */
	void enterRangeSeparator(VimscriptParser.RangeSeparatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#rangeSeparator}.
	 * @param ctx the parse tree
	 */
	void exitRangeSeparator(VimscriptParser.RangeSeparatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#search}.
	 * @param ctx the parse tree
	 */
	void enterSearch(VimscriptParser.SearchContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#search}.
	 * @param ctx the parse tree
	 */
	void exitSearch(VimscriptParser.SearchContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#rangeOffset}.
	 * @param ctx the parse tree
	 */
	void enterRangeOffset(VimscriptParser.RangeOffsetContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#rangeOffset}.
	 * @param ctx the parse tree
	 */
	void exitRangeOffset(VimscriptParser.RangeOffsetContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#numberInOffset}.
	 * @param ctx the parse tree
	 */
	void enterNumberInOffset(VimscriptParser.NumberInOffsetContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#numberInOffset}.
	 * @param ctx the parse tree
	 */
	void exitNumberInOffset(VimscriptParser.NumberInOffsetContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#plusOneOffset}.
	 * @param ctx the parse tree
	 */
	void enterPlusOneOffset(VimscriptParser.PlusOneOffsetContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#plusOneOffset}.
	 * @param ctx the parse tree
	 */
	void exitPlusOneOffset(VimscriptParser.PlusOneOffsetContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#minusOneOffset}.
	 * @param ctx the parse tree
	 */
	void enterMinusOneOffset(VimscriptParser.MinusOneOffsetContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#minusOneOffset}.
	 * @param ctx the parse tree
	 */
	void exitMinusOneOffset(VimscriptParser.MinusOneOffsetContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#commandName}.
	 * @param ctx the parse tree
	 */
	void enterCommandName(VimscriptParser.CommandNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#commandName}.
	 * @param ctx the parse tree
	 */
	void exitCommandName(VimscriptParser.CommandNameContext ctx);
	/**
	 * Enter a parse tree produced by the {@code TernaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterTernaryExpression(VimscriptParser.TernaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code TernaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitTernaryExpression(VimscriptParser.TernaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code DictionaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterDictionaryExpression(VimscriptParser.DictionaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code DictionaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitDictionaryExpression(VimscriptParser.DictionaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LogicalAndExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLogicalAndExpression(VimscriptParser.LogicalAndExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LogicalAndExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLogicalAndExpression(VimscriptParser.LogicalAndExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FunctionAsMethodCall1}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFunctionAsMethodCall1(VimscriptParser.FunctionAsMethodCall1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code FunctionAsMethodCall1}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFunctionAsMethodCall1(VimscriptParser.FunctionAsMethodCall1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code LambdaFunctionCallExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLambdaFunctionCallExpression(VimscriptParser.LambdaFunctionCallExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LambdaFunctionCallExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLambdaFunctionCallExpression(VimscriptParser.LambdaFunctionCallExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LogicalOrExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLogicalOrExpression(VimscriptParser.LogicalOrExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LogicalOrExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLogicalOrExpression(VimscriptParser.LogicalOrExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FunctionAsMethodCall2}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFunctionAsMethodCall2(VimscriptParser.FunctionAsMethodCall2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code FunctionAsMethodCall2}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFunctionAsMethodCall2(VimscriptParser.FunctionAsMethodCall2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code BitwiseShiftExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBitwiseShiftExpression(VimscriptParser.BitwiseShiftExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BitwiseShiftExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBitwiseShiftExpression(VimscriptParser.BitwiseShiftExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExpression(VimscriptParser.UnaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExpression(VimscriptParser.UnaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FalsyExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFalsyExpression(VimscriptParser.FalsyExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FalsyExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFalsyExpression(VimscriptParser.FalsyExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FunctionCallExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFunctionCallExpression(VimscriptParser.FunctionCallExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FunctionCallExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFunctionCallExpression(VimscriptParser.FunctionCallExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RegisterExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterRegisterExpression(VimscriptParser.RegisterExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RegisterExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitRegisterExpression(VimscriptParser.RegisterExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LiteralDictionaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLiteralDictionaryExpression(VimscriptParser.LiteralDictionaryExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LiteralDictionaryExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLiteralDictionaryExpression(VimscriptParser.LiteralDictionaryExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code OptionExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterOptionExpression(VimscriptParser.OptionExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code OptionExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitOptionExpression(VimscriptParser.OptionExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code MultiplicativeExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMultiplicativeExpression(VimscriptParser.MultiplicativeExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code MultiplicativeExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMultiplicativeExpression(VimscriptParser.MultiplicativeExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BlobExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBlobExpression(VimscriptParser.BlobExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BlobExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBlobExpression(VimscriptParser.BlobExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AdditiveExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAdditiveExpression(VimscriptParser.AdditiveExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AdditiveExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAdditiveExpression(VimscriptParser.AdditiveExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IntExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIntExpression(VimscriptParser.IntExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IntExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIntExpression(VimscriptParser.IntExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ListExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterListExpression(VimscriptParser.ListExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ListExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitListExpression(VimscriptParser.ListExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FloatExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFloatExpression(VimscriptParser.FloatExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FloatExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFloatExpression(VimscriptParser.FloatExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code VariableExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterVariableExpression(VimscriptParser.VariableExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code VariableExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitVariableExpression(VimscriptParser.VariableExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EnvVariableExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterEnvVariableExpression(VimscriptParser.EnvVariableExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EnvVariableExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitEnvVariableExpression(VimscriptParser.EnvVariableExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code SublistExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterSublistExpression(VimscriptParser.SublistExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SublistExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitSublistExpression(VimscriptParser.SublistExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ComparisonExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterComparisonExpression(VimscriptParser.ComparisonExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ComparisonExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitComparisonExpression(VimscriptParser.ComparisonExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IndexedExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIndexedExpression(VimscriptParser.IndexedExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IndexedExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIndexedExpression(VimscriptParser.IndexedExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StringExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterStringExpression(VimscriptParser.StringExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StringExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitStringExpression(VimscriptParser.StringExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code WrappedExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterWrappedExpression(VimscriptParser.WrappedExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code WrappedExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitWrappedExpression(VimscriptParser.WrappedExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LambdaExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLambdaExpression(VimscriptParser.LambdaExpressionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LambdaExpression}
	 * labeled alternative in {@link VimscriptParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLambdaExpression(VimscriptParser.LambdaExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#multiplicativeOperator}.
	 * @param ctx the parse tree
	 */
	void enterMultiplicativeOperator(VimscriptParser.MultiplicativeOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#multiplicativeOperator}.
	 * @param ctx the parse tree
	 */
	void exitMultiplicativeOperator(VimscriptParser.MultiplicativeOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#additiveOperator}.
	 * @param ctx the parse tree
	 */
	void enterAdditiveOperator(VimscriptParser.AdditiveOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#additiveOperator}.
	 * @param ctx the parse tree
	 */
	void exitAdditiveOperator(VimscriptParser.AdditiveOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#comparisonOperator}.
	 * @param ctx the parse tree
	 */
	void enterComparisonOperator(VimscriptParser.ComparisonOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#comparisonOperator}.
	 * @param ctx the parse tree
	 */
	void exitComparisonOperator(VimscriptParser.ComparisonOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#bitwiseShiftOperator}.
	 * @param ctx the parse tree
	 */
	void enterBitwiseShiftOperator(VimscriptParser.BitwiseShiftOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#bitwiseShiftOperator}.
	 * @param ctx the parse tree
	 */
	void exitBitwiseShiftOperator(VimscriptParser.BitwiseShiftOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#logicalAndOperator}.
	 * @param ctx the parse tree
	 */
	void enterLogicalAndOperator(VimscriptParser.LogicalAndOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#logicalAndOperator}.
	 * @param ctx the parse tree
	 */
	void exitLogicalAndOperator(VimscriptParser.LogicalAndOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#logicalOrOperator}.
	 * @param ctx the parse tree
	 */
	void enterLogicalOrOperator(VimscriptParser.LogicalOrOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#logicalOrOperator}.
	 * @param ctx the parse tree
	 */
	void exitLogicalOrOperator(VimscriptParser.LogicalOrOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#register}.
	 * @param ctx the parse tree
	 */
	void enterRegister(VimscriptParser.RegisterContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#register}.
	 * @param ctx the parse tree
	 */
	void exitRegister(VimscriptParser.RegisterContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#lambda}.
	 * @param ctx the parse tree
	 */
	void enterLambda(VimscriptParser.LambdaContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#lambda}.
	 * @param ctx the parse tree
	 */
	void exitLambda(VimscriptParser.LambdaContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#variable}.
	 * @param ctx the parse tree
	 */
	void enterVariable(VimscriptParser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#variable}.
	 * @param ctx the parse tree
	 */
	void exitVariable(VimscriptParser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#variableName}.
	 * @param ctx the parse tree
	 */
	void enterVariableName(VimscriptParser.VariableNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#variableName}.
	 * @param ctx the parse tree
	 */
	void exitVariableName(VimscriptParser.VariableNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#variableScope}.
	 * @param ctx the parse tree
	 */
	void enterVariableScope(VimscriptParser.VariableScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#variableScope}.
	 * @param ctx the parse tree
	 */
	void exitVariableScope(VimscriptParser.VariableScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#curlyBracesName}.
	 * @param ctx the parse tree
	 */
	void enterCurlyBracesName(VimscriptParser.CurlyBracesNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#curlyBracesName}.
	 * @param ctx the parse tree
	 */
	void exitCurlyBracesName(VimscriptParser.CurlyBracesNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#element}.
	 * @param ctx the parse tree
	 */
	void enterElement(VimscriptParser.ElementContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#element}.
	 * @param ctx the parse tree
	 */
	void exitElement(VimscriptParser.ElementContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#option}.
	 * @param ctx the parse tree
	 */
	void enterOption(VimscriptParser.OptionContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#option}.
	 * @param ctx the parse tree
	 */
	void exitOption(VimscriptParser.OptionContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#optionName}.
	 * @param ctx the parse tree
	 */
	void enterOptionName(VimscriptParser.OptionNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#optionName}.
	 * @param ctx the parse tree
	 */
	void exitOptionName(VimscriptParser.OptionNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#optionScope}.
	 * @param ctx the parse tree
	 */
	void enterOptionScope(VimscriptParser.OptionScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#optionScope}.
	 * @param ctx the parse tree
	 */
	void exitOptionScope(VimscriptParser.OptionScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#envVariable}.
	 * @param ctx the parse tree
	 */
	void enterEnvVariable(VimscriptParser.EnvVariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#envVariable}.
	 * @param ctx the parse tree
	 */
	void exitEnvVariable(VimscriptParser.EnvVariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#envVariableName}.
	 * @param ctx the parse tree
	 */
	void enterEnvVariableName(VimscriptParser.EnvVariableNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#envVariableName}.
	 * @param ctx the parse tree
	 */
	void exitEnvVariableName(VimscriptParser.EnvVariableNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void enterFunctionCall(VimscriptParser.FunctionCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#functionCall}.
	 * @param ctx the parse tree
	 */
	void exitFunctionCall(VimscriptParser.FunctionCallContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#functionName}.
	 * @param ctx the parse tree
	 */
	void enterFunctionName(VimscriptParser.FunctionNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#functionName}.
	 * @param ctx the parse tree
	 */
	void exitFunctionName(VimscriptParser.FunctionNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#functionScope}.
	 * @param ctx the parse tree
	 */
	void enterFunctionScope(VimscriptParser.FunctionScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#functionScope}.
	 * @param ctx the parse tree
	 */
	void exitFunctionScope(VimscriptParser.FunctionScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#functionArguments}.
	 * @param ctx the parse tree
	 */
	void enterFunctionArguments(VimscriptParser.FunctionArgumentsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#functionArguments}.
	 * @param ctx the parse tree
	 */
	void exitFunctionArguments(VimscriptParser.FunctionArgumentsContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#functionArgument}.
	 * @param ctx the parse tree
	 */
	void enterFunctionArgument(VimscriptParser.FunctionArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#functionArgument}.
	 * @param ctx the parse tree
	 */
	void exitFunctionArgument(VimscriptParser.FunctionArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#list}.
	 * @param ctx the parse tree
	 */
	void enterList(VimscriptParser.ListContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#list}.
	 * @param ctx the parse tree
	 */
	void exitList(VimscriptParser.ListContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#dictionary}.
	 * @param ctx the parse tree
	 */
	void enterDictionary(VimscriptParser.DictionaryContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#dictionary}.
	 * @param ctx the parse tree
	 */
	void exitDictionary(VimscriptParser.DictionaryContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#dictionaryEntry}.
	 * @param ctx the parse tree
	 */
	void enterDictionaryEntry(VimscriptParser.DictionaryEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#dictionaryEntry}.
	 * @param ctx the parse tree
	 */
	void exitDictionaryEntry(VimscriptParser.DictionaryEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#literalDictionary}.
	 * @param ctx the parse tree
	 */
	void enterLiteralDictionary(VimscriptParser.LiteralDictionaryContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#literalDictionary}.
	 * @param ctx the parse tree
	 */
	void exitLiteralDictionary(VimscriptParser.LiteralDictionaryContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#literalDictionaryEntry}.
	 * @param ctx the parse tree
	 */
	void enterLiteralDictionaryEntry(VimscriptParser.LiteralDictionaryEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#literalDictionaryEntry}.
	 * @param ctx the parse tree
	 */
	void exitLiteralDictionaryEntry(VimscriptParser.LiteralDictionaryEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#literalDictionaryKey}.
	 * @param ctx the parse tree
	 */
	void enterLiteralDictionaryKey(VimscriptParser.LiteralDictionaryKeyContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#literalDictionaryKey}.
	 * @param ctx the parse tree
	 */
	void exitLiteralDictionaryKey(VimscriptParser.LiteralDictionaryKeyContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#anyScope}.
	 * @param ctx the parse tree
	 */
	void enterAnyScope(VimscriptParser.AnyScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#anyScope}.
	 * @param ctx the parse tree
	 */
	void exitAnyScope(VimscriptParser.AnyScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#string}.
	 * @param ctx the parse tree
	 */
	void enterString(VimscriptParser.StringContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#string}.
	 * @param ctx the parse tree
	 */
	void exitString(VimscriptParser.StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#unsignedFloat}.
	 * @param ctx the parse tree
	 */
	void enterUnsignedFloat(VimscriptParser.UnsignedFloatContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#unsignedFloat}.
	 * @param ctx the parse tree
	 */
	void exitUnsignedFloat(VimscriptParser.UnsignedFloatContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#unsignedInt}.
	 * @param ctx the parse tree
	 */
	void enterUnsignedInt(VimscriptParser.UnsignedIntContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#unsignedInt}.
	 * @param ctx the parse tree
	 */
	void exitUnsignedInt(VimscriptParser.UnsignedIntContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#blob}.
	 * @param ctx the parse tree
	 */
	void enterBlob(VimscriptParser.BlobContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#blob}.
	 * @param ctx the parse tree
	 */
	void exitBlob(VimscriptParser.BlobContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#mark}.
	 * @param ctx the parse tree
	 */
	void enterMark(VimscriptParser.MarkContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#mark}.
	 * @param ctx the parse tree
	 */
	void exitMark(VimscriptParser.MarkContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#inline_comment}.
	 * @param ctx the parse tree
	 */
	void enterInline_comment(VimscriptParser.Inline_commentContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#inline_comment}.
	 * @param ctx the parse tree
	 */
	void exitInline_comment(VimscriptParser.Inline_commentContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#anyCaseNameWithDigitsAndUnderscores}.
	 * @param ctx the parse tree
	 */
	void enterAnyCaseNameWithDigitsAndUnderscores(VimscriptParser.AnyCaseNameWithDigitsAndUnderscoresContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#anyCaseNameWithDigitsAndUnderscores}.
	 * @param ctx the parse tree
	 */
	void exitAnyCaseNameWithDigitsAndUnderscores(VimscriptParser.AnyCaseNameWithDigitsAndUnderscoresContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#anyCaseNameWithDigitsAndUnderscoresExceptKeywords}.
	 * @param ctx the parse tree
	 */
	void enterAnyCaseNameWithDigitsAndUnderscoresExceptKeywords(VimscriptParser.AnyCaseNameWithDigitsAndUnderscoresExceptKeywordsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#anyCaseNameWithDigitsAndUnderscoresExceptKeywords}.
	 * @param ctx the parse tree
	 */
	void exitAnyCaseNameWithDigitsAndUnderscoresExceptKeywords(VimscriptParser.AnyCaseNameWithDigitsAndUnderscoresExceptKeywordsContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#uppercaseAlphabeticChar}.
	 * @param ctx the parse tree
	 */
	void enterUppercaseAlphabeticChar(VimscriptParser.UppercaseAlphabeticCharContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#uppercaseAlphabeticChar}.
	 * @param ctx the parse tree
	 */
	void exitUppercaseAlphabeticChar(VimscriptParser.UppercaseAlphabeticCharContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#lowercaseAlphabeticChar}.
	 * @param ctx the parse tree
	 */
	void enterLowercaseAlphabeticChar(VimscriptParser.LowercaseAlphabeticCharContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#lowercaseAlphabeticChar}.
	 * @param ctx the parse tree
	 */
	void exitLowercaseAlphabeticChar(VimscriptParser.LowercaseAlphabeticCharContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#keyword}.
	 * @param ctx the parse tree
	 */
	void enterKeyword(VimscriptParser.KeywordContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#keyword}.
	 * @param ctx the parse tree
	 */
	void exitKeyword(VimscriptParser.KeywordContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#operator}.
	 * @param ctx the parse tree
	 */
	void enterOperator(VimscriptParser.OperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#operator}.
	 * @param ctx the parse tree
	 */
	void exitOperator(VimscriptParser.OperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link VimscriptParser#existingCommands}.
	 * @param ctx the parse tree
	 */
	void enterExistingCommands(VimscriptParser.ExistingCommandsContext ctx);
	/**
	 * Exit a parse tree produced by {@link VimscriptParser#existingCommands}.
	 * @param ctx the parse tree
	 */
	void exitExistingCommands(VimscriptParser.ExistingCommandsContext ctx);
}