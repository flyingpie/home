// Generated from RegexParser.g4 by ANTLR 4.13.2
package com.maddyhome.idea.vim.parser.generated;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class RegexParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ALTERNATION=1, AND=2, LEFT_PAREN=3, RIGHT_PAREN=4, LITERAL_CHAR=5, DOT=6, 
		STAR=7, PLUS=8, OPTIONAL=9, RANGE_START=10, COLLECTION_START=11, CLASS_IDENTIFIER=12, 
		CLASS_IDENTIFIER_D=13, CLASS_KEYWORD=14, CLASS_KEYWORD_D=15, CLASS_FILENAME=16, 
		CLASS_FILENAME_D=17, CLASS_PRINTABLE=18, CLASS_PRINTABLE_D=19, CLASS_WS=20, 
		CLASS_NOT_WS=21, CLASS_DIGIT=22, CLASS_NOT_DIGIT=23, CLASS_HEX=24, CLASS_NOT_HEX=25, 
		CLASS_OCTAL=26, CLASS_NOT_OCTAL=27, CLASS_WORD=28, CLASS_NOT_WORD=29, 
		CLASS_HEADWORD=30, CLASS_NOT_HEADWORD=31, CLASS_ALPHA=32, CLASS_NOT_ALPHA=33, 
		CLASS_LCASE=34, CLASS_NOT_LCASE=35, CLASS_UCASE=36, CLASS_NOT_UCASE=37, 
		CLASS_ESC=38, CLASS_TAB=39, CLASS_CR=40, CLASS_BS=41, CLASS_NL=42, COLLECTION_LITERAL_CHAR=43, 
		CURSOR=44, LEFT_PAREN_NOCAPTURE=45, START_MATCH=46, END_MATCH=47, DOTNL=48, 
		RANGE_START_LAZY=49, BACKREFERENCE=50, CLASS_IDENTIFIER_NL=51, CLASS_IDENTIFIER_D_NL=52, 
		CLASS_KEYWORD_NL=53, CLASS_KEYWORD_D_NL=54, CLASS_FILENAME_NL=55, CLASS_FILENAME_D_NL=56, 
		CLASS_PRINTABLE_NL=57, CLASS_PRINTABLE_D_NL=58, CLASS_WS_NL=59, CLASS_NOT_WS_NL=60, 
		CLASS_DIGIT_NL=61, CLASS_NOT_DIGIT_NL=62, CLASS_HEX_NL=63, CLASS_NOT_HEX_NL=64, 
		CLASS_OCTAL_NL=65, CLASS_NOT_OCTAL_NL=66, CLASS_WORD_NL=67, CLASS_NOT_WORD_NL=68, 
		CLASS_HEADWORD_NL=69, CLASS_NOT_HEADWORD_NL=70, CLASS_ALPHA_NL=71, CLASS_NOT_ALPHA_NL=72, 
		CLASS_LCASE_NL=73, CLASS_NOT_LCASE_NL=74, CLASS_UCASE_NL=75, CLASS_NOT_UCASE_NL=76, 
		START_OF_FILE=77, END_OF_FILE=78, CARET=79, DOLLAR=80, START_OF_LINE=81, 
		END_OF_LINE=82, ATOMIC=83, START_OF_WORD=84, END_OF_WORD=85, POSITIVE_LOOKAHEAD=86, 
		NEGATIVE_LOOKAHEAD=87, POSITIVE_LOOKBEHIND=88, NEGATIVE_LOOKBEHIND=89, 
		POSITIVE_LIMITED_LOOKBEHIND=90, NEGATIVE_LIMITED_LOOKBEHIND=91, LAST_SUBSTITUTE=92, 
		VISUAL=93, DECIMAL_CODE=94, OCTAL_CODE=95, HEXADECIMAL_CODE=96, UNICODE_CODE=97, 
		WIDE_UNICODE_CODE=98, LINE=99, BEFORE_LINE=100, AFTER_LINE=101, COLUMN=102, 
		BEFORE_COLUMN=103, AFTER_COLUMN=104, LINE_CURSOR=105, BEFORE_LINE_CURSOR=106, 
		AFTER_LINE_CURSOR=107, COLUMN_CURSOR=108, BEFORE_COLUMN_CURSOR=109, AFTER_COLUMN_CURSOR=110, 
		OPTIONALLY_MATCHED_START=111, OPTIONALLY_MATCHED_END=112, MARK=113, BEFORE_MARK=114, 
		AFTER_MARK=115, IGNORE_CASE_MAGIC=116, NO_IGNORE_CASE_MAGIC=117, SETMAGIC_MAGIC=118, 
		SETNOMAGIC_MAGIC=119, SETVMAGIC_MAGIC=120, SETVNOMAGIC_MAGIC=121, IGNORE_CASE_NOMAGIC=122, 
		NO_IGNORE_CASE_NOMAGIC=123, SETMAGIC_NOMAGIC=124, SETNOMAGIC_NOMAGIC=125, 
		SETVMAGIC_NOMAGIC=126, SETVNOMAGIC_NOMAGIC=127, IGNORE_CASE_VMAGIC=128, 
		NO_IGNORE_CASE_VMAGIC=129, SETMAGIC_VMAGIC=130, SETNOMAGIC_VMAGIC=131, 
		SETVMAGIC_VMAGIC=132, SETVNOMAGIC_VMAGIC=133, IGNORE_CASE_VNOMAGIC=134, 
		OT_IGNORE_CASE_VNOMAGIC=135, SETMAGIC_VNOMAGIC=136, SETNOMAGIC_VNOMAGIC=137, 
		SETVMAGIC_VNOMAGIC=138, SETVNOMAGIC_VNOMAGIC=139, RANGE_END=140, INT=141, 
		COMMA=142, COLLECTION_END=143, DASH=144, ALNUM_CLASS=145, ALPHA_CLASS=146, 
		BLANK_CLASS=147, CNTRL_CLASS=148, DIGIT_CLASS=149, GRAPH_CLASS=150, LOWER_CLASS=151, 
		PRINT_CLASS=152, PUNCT_CLASS=153, SPACE_CLASS=154, UPPER_CLASS=155, XDIGIT_CLASS=156, 
		RETURN_CLASS=157, TAB_CLASS=158, ESCAPE_CLASS=159, BACKSPACE_CLASS=160, 
		IDENT_CLASS=161, KEYWORD_CLASS=162, FNAME_CLASS=163, ALTERNATION_MAGIC=164, 
		AND_MAGIC=165, LEFT_PAREN_MAGIC=166, LEFT_PAREN_NOCAPTURE_MAGIC=167, RIGHT_PAREN_MAGIC=168, 
		DOT_MAGIC=169, DOTNL_MAGIC=170, LAST_SUBSTITUTE_MAGIC=171, STAR_MAGIC=172, 
		PLUS_MAGIC=173, ATOMIC_MAGIC=174, POSITIVE_LOOKAHEAD_MAGIC=175, NEGATIVE_LOOKAHEAD_MAGIC=176, 
		POSITIVE_LOOKBEHIND_MAGIC=177, NEGATIVE_LOOKBEHIND_MAGIC=178, OPTIONALLY_MATCHED_START_MAGIC=179, 
		OPTIONALLY_MATCHED_END_MAGIC=180, CURSOR_MAGIC=181, START_MATCH_MAGIC=182, 
		END_MATCH_MAGIC=183, START_OF_FILE_MAGIC=184, END_OF_FILE_MAGIC=185, START_OF_LINE_MAGIC=186, 
		END_OF_LINE_MAGIC=187, CARET_MAGIC=188, DOLLAR_MAGIC=189, START_OF_WORD_MAGIC=190, 
		END_OF_WORD_MAGIC=191, VISUAL_MAGIC=192, LINE_CURSOR_MAGIC=193, BEFORE_LINE_CURSOR_MAGIC=194, 
		AFTER_LINE_CURSOR_MAGIC=195, CLASS_IDENTIFIER_MAGIC=196, CLASS_IDENTIFIER_D_MAGIC=197, 
		CLASS_KEYWORD_MAGIC=198, CLASS_KEYWORD_D_MAGIC=199, CLASS_FILENAME_MAGIC=200, 
		CLASS_FILENAME_D_MAGIC=201, CLASS_PRINTABLE_MAGIC=202, CLASS_PRINTABLE_D_MAGIC=203, 
		CLASS_WS_MAGIC=204, CLASS_NOT_WS_MAGIC=205, CLASS_DIGIT_MAGIC=206, CLASS_NOT_DIGIT_MAGIC=207, 
		CLASS_HEX_MAGIC=208, CLASS_NOT_HEX_MAGIC=209, CLASS_OCTAL_MAGIC=210, CLASS_NOT_OCTAL_MAGIC=211, 
		CLASS_WORD_MAGIC=212, CLASS_NOT_WORD_MAGIC=213, CLASS_HEADWORD_MAGIC=214, 
		CLASS_NOT_HEADWORD_MAGIC=215, CLASS_ALPHA_MAGIC=216, CLASS_NOT_ALPHA_MAGIC=217, 
		CLASS_LCASE_MAGIC=218, CLASS_NOT_LCASE_MAGIC=219, CLASS_UCASE_MAGIC=220, 
		CLASS_NOT_UCASE_MAGIC=221, CLASS_IDENTIFIER_NL_MAGIC=222, CLASS_IDENTIFIER_D_NL_MAGIC=223, 
		CLASS_KEYWORD_NL_MAGIC=224, CLASS_KEYWORD_D_NL_MAGIC=225, CLASS_FILENAME_NL_MAGIC=226, 
		CLASS_FILENAME_D_NL_MAGIC=227, CLASS_PRINTABLE_NL_MAGIC=228, CLASS_PRINTABLE_D_NL_MAGIC=229, 
		CLASS_WS_NL_MAGIC=230, CLASS_NOT_WS_NL_MAGIC=231, CLASS_DIGIT_NL_MAGIC=232, 
		CLASS_NOT_DIGIT_NL_MAGIC=233, CLASS_HEX_NL_MAGIC=234, CLASS_NOT_HEX_NL_MAGIC=235, 
		CLASS_OCTAL_NL_MAGIC=236, CLASS_NOT_OCTAL_NL_MAGIC=237, CLASS_WORD_NL_MAGIC=238, 
		CLASS_NOT_WORD_NL_MAGIC=239, CLASS_HEADWORD_NL_MAGIC=240, CLASS_NOT_HEADWORD_NL_MAGIC=241, 
		CLASS_ALPHA_NL_MAGIC=242, CLASS_NOT_ALPHA_NL_MAGIC=243, CLASS_LCASE_NL_MAGIC=244, 
		CLASS_NOT_LCASE_NL_MAGIC=245, CLASS_UCASE_NL_MAGIC=246, CLASS_NOT_UCASE_NL_MAGIC=247, 
		CLASS_ESC_MAGIC=248, CLASS_TAB_MAGIC=249, CLASS_CR_MAGIC=250, CLASS_BS_MAGIC=251, 
		CLASS_NL_MAGIC=252, DOT_NOMAGIC=253, LAST_SUBSTITUTE_NOMAGIC=254, STAR_NOMAGIC=255, 
		ALTERNATION_VMAGIC=256, AND_VMAGIC=257, LEFT_PAREN_VMAGIC=258, LEFT_PAREN_NOCAPTURE_VMAGIC=259, 
		RIGHT_PAREN_VMAGIC=260, PLUS_VMAGIC=261, ATOMIC_VMAGIC=262, POSITIVE_LOOKAHEAD_VMAGIC=263, 
		NEGATIVE_LOOKAHEAD_VMAGIC=264, POSITIVE_LOOKBEHIND_VMAGIC=265, NEGATIVE_LOOKBEHIND_VMAGIC=266, 
		OPTIONALLY_MATCHED_START_VMAGIC=267, CURSOR_VMAGIC=268, START_OF_FILE_VMAGIC=269, 
		END_OF_FILE_VMAGIC=270, START_OF_WORD_VMAGIC=271, END_OF_WORD_VMAGIC=272, 
		VISUAL_VMAGIC=273, LINE_CURSOR_VMAGIC=274, BEFORE_LINE_CURSOR_VMAGIC=275, 
		AFTER_LINE_CURSOR_VMAGIC=276, CARET_VNOMAGIC=277, DOLLAR_VNOMAGIC=278;
	public static final int
		RULE_pattern = 0, RULE_sub_pattern = 1, RULE_branch = 2, RULE_concat = 3, 
		RULE_piece = 4, RULE_atom = 5, RULE_multi = 6, RULE_range = 7, RULE_ordinary_atom = 8, 
		RULE_char_class = 9, RULE_collection = 10, RULE_collection_elem = 11, 
		RULE_collection_char_class_expression = 12, RULE_zero_width = 13, RULE_char_code = 14;
	private static String[] makeRuleNames() {
		return new String[] {
			"pattern", "sub_pattern", "branch", "concat", "piece", "atom", "multi", 
			"range", "ordinary_atom", "char_class", "collection", "collection_elem", 
			"collection_char_class_expression", "zero_width", "char_code"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, "','", null, 
			"'-'", "'[:alnum:]'", "'[:alpha:]'", "'[:blank:]'", "'[:cntrl:]'", "'[:digit:]'", 
			"'[:graph:]'", "'[:lower:]'", "'[:print:]'", "'[:punct:]'", "'[:space:]'", 
			"'[:upper:]'", "'[:xdigit:]'", "'[:return:]'", "'[:tab:]'", "'[:escape:]'", 
			"'[:backspace:]'", "'[:ident:]'", "'[:keyword:]'", "'[:fname:]'", null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, "'|'", "'&'", "'('", "'%('", 
			"')'", "'+'", "'@>'", "'@='", "'@!'", "'@<='", "'@<!'", "'%['", "'%#'", 
			"'%^'", "'%$'", "'<'", "'>'", "'%V'", "'%.l'", "'%<.l'", "'%>.l'", "'\\^'", 
			"'\\$'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "ALTERNATION", "AND", "LEFT_PAREN", "RIGHT_PAREN", "LITERAL_CHAR", 
			"DOT", "STAR", "PLUS", "OPTIONAL", "RANGE_START", "COLLECTION_START", 
			"CLASS_IDENTIFIER", "CLASS_IDENTIFIER_D", "CLASS_KEYWORD", "CLASS_KEYWORD_D", 
			"CLASS_FILENAME", "CLASS_FILENAME_D", "CLASS_PRINTABLE", "CLASS_PRINTABLE_D", 
			"CLASS_WS", "CLASS_NOT_WS", "CLASS_DIGIT", "CLASS_NOT_DIGIT", "CLASS_HEX", 
			"CLASS_NOT_HEX", "CLASS_OCTAL", "CLASS_NOT_OCTAL", "CLASS_WORD", "CLASS_NOT_WORD", 
			"CLASS_HEADWORD", "CLASS_NOT_HEADWORD", "CLASS_ALPHA", "CLASS_NOT_ALPHA", 
			"CLASS_LCASE", "CLASS_NOT_LCASE", "CLASS_UCASE", "CLASS_NOT_UCASE", "CLASS_ESC", 
			"CLASS_TAB", "CLASS_CR", "CLASS_BS", "CLASS_NL", "COLLECTION_LITERAL_CHAR", 
			"CURSOR", "LEFT_PAREN_NOCAPTURE", "START_MATCH", "END_MATCH", "DOTNL", 
			"RANGE_START_LAZY", "BACKREFERENCE", "CLASS_IDENTIFIER_NL", "CLASS_IDENTIFIER_D_NL", 
			"CLASS_KEYWORD_NL", "CLASS_KEYWORD_D_NL", "CLASS_FILENAME_NL", "CLASS_FILENAME_D_NL", 
			"CLASS_PRINTABLE_NL", "CLASS_PRINTABLE_D_NL", "CLASS_WS_NL", "CLASS_NOT_WS_NL", 
			"CLASS_DIGIT_NL", "CLASS_NOT_DIGIT_NL", "CLASS_HEX_NL", "CLASS_NOT_HEX_NL", 
			"CLASS_OCTAL_NL", "CLASS_NOT_OCTAL_NL", "CLASS_WORD_NL", "CLASS_NOT_WORD_NL", 
			"CLASS_HEADWORD_NL", "CLASS_NOT_HEADWORD_NL", "CLASS_ALPHA_NL", "CLASS_NOT_ALPHA_NL", 
			"CLASS_LCASE_NL", "CLASS_NOT_LCASE_NL", "CLASS_UCASE_NL", "CLASS_NOT_UCASE_NL", 
			"START_OF_FILE", "END_OF_FILE", "CARET", "DOLLAR", "START_OF_LINE", "END_OF_LINE", 
			"ATOMIC", "START_OF_WORD", "END_OF_WORD", "POSITIVE_LOOKAHEAD", "NEGATIVE_LOOKAHEAD", 
			"POSITIVE_LOOKBEHIND", "NEGATIVE_LOOKBEHIND", "POSITIVE_LIMITED_LOOKBEHIND", 
			"NEGATIVE_LIMITED_LOOKBEHIND", "LAST_SUBSTITUTE", "VISUAL", "DECIMAL_CODE", 
			"OCTAL_CODE", "HEXADECIMAL_CODE", "UNICODE_CODE", "WIDE_UNICODE_CODE", 
			"LINE", "BEFORE_LINE", "AFTER_LINE", "COLUMN", "BEFORE_COLUMN", "AFTER_COLUMN", 
			"LINE_CURSOR", "BEFORE_LINE_CURSOR", "AFTER_LINE_CURSOR", "COLUMN_CURSOR", 
			"BEFORE_COLUMN_CURSOR", "AFTER_COLUMN_CURSOR", "OPTIONALLY_MATCHED_START", 
			"OPTIONALLY_MATCHED_END", "MARK", "BEFORE_MARK", "AFTER_MARK", "IGNORE_CASE_MAGIC", 
			"NO_IGNORE_CASE_MAGIC", "SETMAGIC_MAGIC", "SETNOMAGIC_MAGIC", "SETVMAGIC_MAGIC", 
			"SETVNOMAGIC_MAGIC", "IGNORE_CASE_NOMAGIC", "NO_IGNORE_CASE_NOMAGIC", 
			"SETMAGIC_NOMAGIC", "SETNOMAGIC_NOMAGIC", "SETVMAGIC_NOMAGIC", "SETVNOMAGIC_NOMAGIC", 
			"IGNORE_CASE_VMAGIC", "NO_IGNORE_CASE_VMAGIC", "SETMAGIC_VMAGIC", "SETNOMAGIC_VMAGIC", 
			"SETVMAGIC_VMAGIC", "SETVNOMAGIC_VMAGIC", "IGNORE_CASE_VNOMAGIC", "OT_IGNORE_CASE_VNOMAGIC", 
			"SETMAGIC_VNOMAGIC", "SETNOMAGIC_VNOMAGIC", "SETVMAGIC_VNOMAGIC", "SETVNOMAGIC_VNOMAGIC", 
			"RANGE_END", "INT", "COMMA", "COLLECTION_END", "DASH", "ALNUM_CLASS", 
			"ALPHA_CLASS", "BLANK_CLASS", "CNTRL_CLASS", "DIGIT_CLASS", "GRAPH_CLASS", 
			"LOWER_CLASS", "PRINT_CLASS", "PUNCT_CLASS", "SPACE_CLASS", "UPPER_CLASS", 
			"XDIGIT_CLASS", "RETURN_CLASS", "TAB_CLASS", "ESCAPE_CLASS", "BACKSPACE_CLASS", 
			"IDENT_CLASS", "KEYWORD_CLASS", "FNAME_CLASS", "ALTERNATION_MAGIC", "AND_MAGIC", 
			"LEFT_PAREN_MAGIC", "LEFT_PAREN_NOCAPTURE_MAGIC", "RIGHT_PAREN_MAGIC", 
			"DOT_MAGIC", "DOTNL_MAGIC", "LAST_SUBSTITUTE_MAGIC", "STAR_MAGIC", "PLUS_MAGIC", 
			"ATOMIC_MAGIC", "POSITIVE_LOOKAHEAD_MAGIC", "NEGATIVE_LOOKAHEAD_MAGIC", 
			"POSITIVE_LOOKBEHIND_MAGIC", "NEGATIVE_LOOKBEHIND_MAGIC", "OPTIONALLY_MATCHED_START_MAGIC", 
			"OPTIONALLY_MATCHED_END_MAGIC", "CURSOR_MAGIC", "START_MATCH_MAGIC", 
			"END_MATCH_MAGIC", "START_OF_FILE_MAGIC", "END_OF_FILE_MAGIC", "START_OF_LINE_MAGIC", 
			"END_OF_LINE_MAGIC", "CARET_MAGIC", "DOLLAR_MAGIC", "START_OF_WORD_MAGIC", 
			"END_OF_WORD_MAGIC", "VISUAL_MAGIC", "LINE_CURSOR_MAGIC", "BEFORE_LINE_CURSOR_MAGIC", 
			"AFTER_LINE_CURSOR_MAGIC", "CLASS_IDENTIFIER_MAGIC", "CLASS_IDENTIFIER_D_MAGIC", 
			"CLASS_KEYWORD_MAGIC", "CLASS_KEYWORD_D_MAGIC", "CLASS_FILENAME_MAGIC", 
			"CLASS_FILENAME_D_MAGIC", "CLASS_PRINTABLE_MAGIC", "CLASS_PRINTABLE_D_MAGIC", 
			"CLASS_WS_MAGIC", "CLASS_NOT_WS_MAGIC", "CLASS_DIGIT_MAGIC", "CLASS_NOT_DIGIT_MAGIC", 
			"CLASS_HEX_MAGIC", "CLASS_NOT_HEX_MAGIC", "CLASS_OCTAL_MAGIC", "CLASS_NOT_OCTAL_MAGIC", 
			"CLASS_WORD_MAGIC", "CLASS_NOT_WORD_MAGIC", "CLASS_HEADWORD_MAGIC", "CLASS_NOT_HEADWORD_MAGIC", 
			"CLASS_ALPHA_MAGIC", "CLASS_NOT_ALPHA_MAGIC", "CLASS_LCASE_MAGIC", "CLASS_NOT_LCASE_MAGIC", 
			"CLASS_UCASE_MAGIC", "CLASS_NOT_UCASE_MAGIC", "CLASS_IDENTIFIER_NL_MAGIC", 
			"CLASS_IDENTIFIER_D_NL_MAGIC", "CLASS_KEYWORD_NL_MAGIC", "CLASS_KEYWORD_D_NL_MAGIC", 
			"CLASS_FILENAME_NL_MAGIC", "CLASS_FILENAME_D_NL_MAGIC", "CLASS_PRINTABLE_NL_MAGIC", 
			"CLASS_PRINTABLE_D_NL_MAGIC", "CLASS_WS_NL_MAGIC", "CLASS_NOT_WS_NL_MAGIC", 
			"CLASS_DIGIT_NL_MAGIC", "CLASS_NOT_DIGIT_NL_MAGIC", "CLASS_HEX_NL_MAGIC", 
			"CLASS_NOT_HEX_NL_MAGIC", "CLASS_OCTAL_NL_MAGIC", "CLASS_NOT_OCTAL_NL_MAGIC", 
			"CLASS_WORD_NL_MAGIC", "CLASS_NOT_WORD_NL_MAGIC", "CLASS_HEADWORD_NL_MAGIC", 
			"CLASS_NOT_HEADWORD_NL_MAGIC", "CLASS_ALPHA_NL_MAGIC", "CLASS_NOT_ALPHA_NL_MAGIC", 
			"CLASS_LCASE_NL_MAGIC", "CLASS_NOT_LCASE_NL_MAGIC", "CLASS_UCASE_NL_MAGIC", 
			"CLASS_NOT_UCASE_NL_MAGIC", "CLASS_ESC_MAGIC", "CLASS_TAB_MAGIC", "CLASS_CR_MAGIC", 
			"CLASS_BS_MAGIC", "CLASS_NL_MAGIC", "DOT_NOMAGIC", "LAST_SUBSTITUTE_NOMAGIC", 
			"STAR_NOMAGIC", "ALTERNATION_VMAGIC", "AND_VMAGIC", "LEFT_PAREN_VMAGIC", 
			"LEFT_PAREN_NOCAPTURE_VMAGIC", "RIGHT_PAREN_VMAGIC", "PLUS_VMAGIC", "ATOMIC_VMAGIC", 
			"POSITIVE_LOOKAHEAD_VMAGIC", "NEGATIVE_LOOKAHEAD_VMAGIC", "POSITIVE_LOOKBEHIND_VMAGIC", 
			"NEGATIVE_LOOKBEHIND_VMAGIC", "OPTIONALLY_MATCHED_START_VMAGIC", "CURSOR_VMAGIC", 
			"START_OF_FILE_VMAGIC", "END_OF_FILE_VMAGIC", "START_OF_WORD_VMAGIC", 
			"END_OF_WORD_VMAGIC", "VISUAL_VMAGIC", "LINE_CURSOR_VMAGIC", "BEFORE_LINE_CURSOR_VMAGIC", 
			"AFTER_LINE_CURSOR_VMAGIC", "CARET_VNOMAGIC", "DOLLAR_VNOMAGIC"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "RegexParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public RegexParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PatternContext extends ParserRuleContext {
		public Sub_patternContext sub_pattern() {
			return getRuleContext(Sub_patternContext.class,0);
		}
		public TerminalNode EOF() { return getToken(RegexParser.EOF, 0); }
		public PatternContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pattern; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPattern(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPattern(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPattern(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PatternContext pattern() throws RecognitionException {
		PatternContext _localctx = new PatternContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_pattern);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(30);
			sub_pattern();
			setState(31);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Sub_patternContext extends ParserRuleContext {
		public BranchContext branch;
		public List<BranchContext> branches = new ArrayList<BranchContext>();
		public List<BranchContext> branch() {
			return getRuleContexts(BranchContext.class);
		}
		public BranchContext branch(int i) {
			return getRuleContext(BranchContext.class,i);
		}
		public List<TerminalNode> ALTERNATION() { return getTokens(RegexParser.ALTERNATION); }
		public TerminalNode ALTERNATION(int i) {
			return getToken(RegexParser.ALTERNATION, i);
		}
		public Sub_patternContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sub_pattern; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterSub_pattern(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitSub_pattern(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitSub_pattern(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Sub_patternContext sub_pattern() throws RecognitionException {
		Sub_patternContext _localctx = new Sub_patternContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_sub_pattern);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(38);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(33);
					((Sub_patternContext)_localctx).branch = branch();
					((Sub_patternContext)_localctx).branches.add(((Sub_patternContext)_localctx).branch);
					setState(34);
					match(ALTERNATION);
					}
					} 
				}
				setState(40);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			}
			setState(41);
			((Sub_patternContext)_localctx).branch = branch();
			((Sub_patternContext)_localctx).branches.add(((Sub_patternContext)_localctx).branch);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class BranchContext extends ParserRuleContext {
		public ConcatContext concat;
		public List<ConcatContext> concats = new ArrayList<ConcatContext>();
		public TerminalNode CARET() { return getToken(RegexParser.CARET, 0); }
		public TerminalNode DOLLAR() { return getToken(RegexParser.DOLLAR, 0); }
		public List<TerminalNode> AND() { return getTokens(RegexParser.AND); }
		public TerminalNode AND(int i) {
			return getToken(RegexParser.AND, i);
		}
		public List<ConcatContext> concat() {
			return getRuleContexts(ConcatContext.class);
		}
		public ConcatContext concat(int i) {
			return getRuleContext(ConcatContext.class,i);
		}
		public BranchContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_branch; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBranch(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBranch(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBranch(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BranchContext branch() throws RecognitionException {
		BranchContext _localctx = new BranchContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_branch);
		try {
			int _alt;
			setState(72);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(43);
				match(CARET);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(44);
				match(DOLLAR);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(45);
				match(AND);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(47);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
				case 1:
					{
					setState(46);
					match(CARET);
					}
					break;
				}
				setState(54);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,2,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(49);
						((BranchContext)_localctx).concat = concat();
						((BranchContext)_localctx).concats.add(((BranchContext)_localctx).concat);
						setState(50);
						match(AND);
						}
						} 
					}
					setState(56);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,2,_ctx);
				}
				setState(57);
				((BranchContext)_localctx).concat = concat();
				((BranchContext)_localctx).concats.add(((BranchContext)_localctx).concat);
				setState(58);
				match(DOLLAR);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(61);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
				case 1:
					{
					setState(60);
					match(CARET);
					}
					break;
				}
				setState(68);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(63);
						((BranchContext)_localctx).concat = concat();
						((BranchContext)_localctx).concats.add(((BranchContext)_localctx).concat);
						setState(64);
						match(AND);
						}
						} 
					}
					setState(70);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
				}
				setState(71);
				((BranchContext)_localctx).concat = concat();
				((BranchContext)_localctx).concats.add(((BranchContext)_localctx).concat);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ConcatContext extends ParserRuleContext {
		public PieceContext piece;
		public List<PieceContext> pieces = new ArrayList<PieceContext>();
		public List<PieceContext> piece() {
			return getRuleContexts(PieceContext.class);
		}
		public PieceContext piece(int i) {
			return getRuleContext(PieceContext.class,i);
		}
		public ConcatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_concat; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterConcat(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitConcat(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitConcat(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConcatContext concat() throws RecognitionException {
		ConcatContext _localctx = new ConcatContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_concat);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(75); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(74);
					((ConcatContext)_localctx).piece = piece();
					((ConcatContext)_localctx).pieces.add(((ConcatContext)_localctx).piece);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(77); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class PieceContext extends ParserRuleContext {
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public MultiContext multi() {
			return getRuleContext(MultiContext.class,0);
		}
		public PieceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_piece; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPiece(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPiece(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPiece(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PieceContext piece() throws RecognitionException {
		PieceContext _localctx = new PieceContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_piece);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(79);
			atom();
			setState(81);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 562949953423232L) != 0) || ((((_la - 83)) & ~0x3f) == 0 && ((1L << (_la - 83)) & 505L) != 0)) {
				{
				setState(80);
				multi();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AtomContext extends ParserRuleContext {
		public AtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atom; }
	 
		public AtomContext() { }
		public void copyFrom(AtomContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupingNoCaptureContext extends AtomContext {
		public TerminalNode LEFT_PAREN_NOCAPTURE() { return getToken(RegexParser.LEFT_PAREN_NOCAPTURE, 0); }
		public TerminalNode RIGHT_PAREN() { return getToken(RegexParser.RIGHT_PAREN, 0); }
		public Sub_patternContext sub_pattern() {
			return getRuleContext(Sub_patternContext.class,0);
		}
		public GroupingNoCaptureContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterGroupingNoCapture(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitGroupingNoCapture(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitGroupingNoCapture(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GroupingCaptureContext extends AtomContext {
		public TerminalNode LEFT_PAREN() { return getToken(RegexParser.LEFT_PAREN, 0); }
		public TerminalNode RIGHT_PAREN() { return getToken(RegexParser.RIGHT_PAREN, 0); }
		public Sub_patternContext sub_pattern() {
			return getRuleContext(Sub_patternContext.class,0);
		}
		public GroupingCaptureContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterGroupingCapture(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitGroupingCapture(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitGroupingCapture(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OrdinaryAtomContext extends AtomContext {
		public Ordinary_atomContext ordinary_atom() {
			return getRuleContext(Ordinary_atomContext.class,0);
		}
		public OrdinaryAtomContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterOrdinaryAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitOrdinaryAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitOrdinaryAtom(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OptionallyMatchedContext extends AtomContext {
		public AtomContext atom;
		public List<AtomContext> atoms = new ArrayList<AtomContext>();
		public TerminalNode OPTIONALLY_MATCHED_START() { return getToken(RegexParser.OPTIONALLY_MATCHED_START, 0); }
		public TerminalNode OPTIONALLY_MATCHED_END() { return getToken(RegexParser.OPTIONALLY_MATCHED_END, 0); }
		public List<AtomContext> atom() {
			return getRuleContexts(AtomContext.class);
		}
		public AtomContext atom(int i) {
			return getRuleContext(AtomContext.class,i);
		}
		public OptionallyMatchedContext(AtomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterOptionallyMatched(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitOptionallyMatched(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitOptionallyMatched(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomContext atom() throws RecognitionException {
		AtomContext _localctx = new AtomContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_atom);
		int _la;
		try {
			int _alt;
			setState(102);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LITERAL_CHAR:
			case DOT:
			case COLLECTION_START:
			case CLASS_IDENTIFIER:
			case CLASS_IDENTIFIER_D:
			case CLASS_KEYWORD:
			case CLASS_KEYWORD_D:
			case CLASS_FILENAME:
			case CLASS_FILENAME_D:
			case CLASS_PRINTABLE:
			case CLASS_PRINTABLE_D:
			case CLASS_WS:
			case CLASS_NOT_WS:
			case CLASS_DIGIT:
			case CLASS_NOT_DIGIT:
			case CLASS_HEX:
			case CLASS_NOT_HEX:
			case CLASS_OCTAL:
			case CLASS_NOT_OCTAL:
			case CLASS_WORD:
			case CLASS_NOT_WORD:
			case CLASS_HEADWORD:
			case CLASS_NOT_HEADWORD:
			case CLASS_ALPHA:
			case CLASS_NOT_ALPHA:
			case CLASS_LCASE:
			case CLASS_NOT_LCASE:
			case CLASS_UCASE:
			case CLASS_NOT_UCASE:
			case CLASS_ESC:
			case CLASS_TAB:
			case CLASS_CR:
			case CLASS_BS:
			case CLASS_NL:
			case CURSOR:
			case START_MATCH:
			case END_MATCH:
			case DOTNL:
			case BACKREFERENCE:
			case CLASS_IDENTIFIER_NL:
			case CLASS_IDENTIFIER_D_NL:
			case CLASS_KEYWORD_NL:
			case CLASS_KEYWORD_D_NL:
			case CLASS_FILENAME_NL:
			case CLASS_FILENAME_D_NL:
			case CLASS_PRINTABLE_NL:
			case CLASS_PRINTABLE_D_NL:
			case CLASS_WS_NL:
			case CLASS_NOT_WS_NL:
			case CLASS_DIGIT_NL:
			case CLASS_NOT_DIGIT_NL:
			case CLASS_HEX_NL:
			case CLASS_NOT_HEX_NL:
			case CLASS_OCTAL_NL:
			case CLASS_NOT_OCTAL_NL:
			case CLASS_WORD_NL:
			case CLASS_NOT_WORD_NL:
			case CLASS_HEADWORD_NL:
			case CLASS_NOT_HEADWORD_NL:
			case CLASS_ALPHA_NL:
			case CLASS_NOT_ALPHA_NL:
			case CLASS_LCASE_NL:
			case CLASS_NOT_LCASE_NL:
			case CLASS_UCASE_NL:
			case CLASS_NOT_UCASE_NL:
			case START_OF_FILE:
			case END_OF_FILE:
			case CARET:
			case DOLLAR:
			case START_OF_LINE:
			case END_OF_LINE:
			case START_OF_WORD:
			case END_OF_WORD:
			case LAST_SUBSTITUTE:
			case VISUAL:
			case DECIMAL_CODE:
			case OCTAL_CODE:
			case HEXADECIMAL_CODE:
			case UNICODE_CODE:
			case WIDE_UNICODE_CODE:
			case LINE:
			case BEFORE_LINE:
			case AFTER_LINE:
			case COLUMN:
			case BEFORE_COLUMN:
			case AFTER_COLUMN:
			case LINE_CURSOR:
			case BEFORE_LINE_CURSOR:
			case AFTER_LINE_CURSOR:
			case COLUMN_CURSOR:
			case BEFORE_COLUMN_CURSOR:
			case AFTER_COLUMN_CURSOR:
			case OPTIONALLY_MATCHED_END:
			case MARK:
			case BEFORE_MARK:
			case AFTER_MARK:
				_localctx = new OrdinaryAtomContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(83);
				ordinary_atom();
				}
				break;
			case LEFT_PAREN:
				_localctx = new GroupingCaptureContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(84);
				match(LEFT_PAREN);
				setState(86);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -571746046445460L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & 4503599362605055L) != 0)) {
					{
					setState(85);
					sub_pattern();
					}
				}

				setState(88);
				match(RIGHT_PAREN);
				}
				break;
			case LEFT_PAREN_NOCAPTURE:
				_localctx = new GroupingNoCaptureContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(89);
				match(LEFT_PAREN_NOCAPTURE);
				setState(91);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & -571746046445460L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & 4503599362605055L) != 0)) {
					{
					setState(90);
					sub_pattern();
					}
				}

				setState(93);
				match(RIGHT_PAREN);
				}
				break;
			case OPTIONALLY_MATCHED_START:
				_localctx = new OptionallyMatchedContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(94);
				match(OPTIONALLY_MATCHED_START);
				setState(98);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,10,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(95);
						((OptionallyMatchedContext)_localctx).atom = atom();
						((OptionallyMatchedContext)_localctx).atoms.add(((OptionallyMatchedContext)_localctx).atom);
						}
						} 
					}
					setState(100);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,10,_ctx);
				}
				setState(101);
				match(OPTIONALLY_MATCHED_END);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MultiContext extends ParserRuleContext {
		public MultiContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_multi; }
	 
		public MultiContext() { }
		public void copyFrom(MultiContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OneOrMoreContext extends MultiContext {
		public TerminalNode PLUS() { return getToken(RegexParser.PLUS, 0); }
		public OneOrMoreContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterOneOrMore(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitOneOrMore(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitOneOrMore(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NegativeLimitedLookbehindContext extends MultiContext {
		public TerminalNode NEGATIVE_LIMITED_LOOKBEHIND() { return getToken(RegexParser.NEGATIVE_LIMITED_LOOKBEHIND, 0); }
		public NegativeLimitedLookbehindContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNegativeLimitedLookbehind(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNegativeLimitedLookbehind(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNegativeLimitedLookbehind(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ZeroOrMoreContext extends MultiContext {
		public TerminalNode STAR() { return getToken(RegexParser.STAR, 0); }
		public ZeroOrMoreContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterZeroOrMore(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitZeroOrMore(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitZeroOrMore(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NegativeLookbehindContext extends MultiContext {
		public TerminalNode NEGATIVE_LOOKBEHIND() { return getToken(RegexParser.NEGATIVE_LOOKBEHIND, 0); }
		public NegativeLookbehindContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNegativeLookbehind(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNegativeLookbehind(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNegativeLookbehind(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NegativeLookaheadContext extends MultiContext {
		public TerminalNode NEGATIVE_LOOKAHEAD() { return getToken(RegexParser.NEGATIVE_LOOKAHEAD, 0); }
		public NegativeLookaheadContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNegativeLookahead(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNegativeLookahead(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNegativeLookahead(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AtomicContext extends MultiContext {
		public TerminalNode ATOMIC() { return getToken(RegexParser.ATOMIC, 0); }
		public AtomicContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAtomic(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAtomic(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAtomic(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PositiveLimitedLookbehindContext extends MultiContext {
		public TerminalNode POSITIVE_LIMITED_LOOKBEHIND() { return getToken(RegexParser.POSITIVE_LIMITED_LOOKBEHIND, 0); }
		public PositiveLimitedLookbehindContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPositiveLimitedLookbehind(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPositiveLimitedLookbehind(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPositiveLimitedLookbehind(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PositiveLookaheadContext extends MultiContext {
		public TerminalNode POSITIVE_LOOKAHEAD() { return getToken(RegexParser.POSITIVE_LOOKAHEAD, 0); }
		public PositiveLookaheadContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPositiveLookahead(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPositiveLookahead(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPositiveLookahead(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RangeQuantifierContext extends MultiContext {
		public RangeContext range() {
			return getRuleContext(RangeContext.class,0);
		}
		public RangeQuantifierContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterRangeQuantifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitRangeQuantifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitRangeQuantifier(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PositiveLookbehindContext extends MultiContext {
		public TerminalNode POSITIVE_LOOKBEHIND() { return getToken(RegexParser.POSITIVE_LOOKBEHIND, 0); }
		public PositiveLookbehindContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPositiveLookbehind(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPositiveLookbehind(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPositiveLookbehind(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ZeroOrOneContext extends MultiContext {
		public TerminalNode OPTIONAL() { return getToken(RegexParser.OPTIONAL, 0); }
		public ZeroOrOneContext(MultiContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterZeroOrOne(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitZeroOrOne(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitZeroOrOne(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MultiContext multi() throws RecognitionException {
		MultiContext _localctx = new MultiContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_multi);
		try {
			setState(115);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STAR:
				_localctx = new ZeroOrMoreContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(104);
				match(STAR);
				}
				break;
			case PLUS:
				_localctx = new OneOrMoreContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(105);
				match(PLUS);
				}
				break;
			case OPTIONAL:
				_localctx = new ZeroOrOneContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(106);
				match(OPTIONAL);
				}
				break;
			case RANGE_START:
			case RANGE_START_LAZY:
				_localctx = new RangeQuantifierContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(107);
				range();
				}
				break;
			case ATOMIC:
				_localctx = new AtomicContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(108);
				match(ATOMIC);
				}
				break;
			case POSITIVE_LOOKAHEAD:
				_localctx = new PositiveLookaheadContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(109);
				match(POSITIVE_LOOKAHEAD);
				}
				break;
			case NEGATIVE_LOOKAHEAD:
				_localctx = new NegativeLookaheadContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(110);
				match(NEGATIVE_LOOKAHEAD);
				}
				break;
			case POSITIVE_LOOKBEHIND:
				_localctx = new PositiveLookbehindContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(111);
				match(POSITIVE_LOOKBEHIND);
				}
				break;
			case NEGATIVE_LOOKBEHIND:
				_localctx = new NegativeLookbehindContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(112);
				match(NEGATIVE_LOOKBEHIND);
				}
				break;
			case POSITIVE_LIMITED_LOOKBEHIND:
				_localctx = new PositiveLimitedLookbehindContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(113);
				match(POSITIVE_LIMITED_LOOKBEHIND);
				}
				break;
			case NEGATIVE_LIMITED_LOOKBEHIND:
				_localctx = new NegativeLimitedLookbehindContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(114);
				match(NEGATIVE_LIMITED_LOOKBEHIND);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class RangeContext extends ParserRuleContext {
		public RangeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_range; }
	 
		public RangeContext() { }
		public void copyFrom(RangeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RangeLazyContext extends RangeContext {
		public Token lower_bound;
		public Token upper_bound;
		public TerminalNode RANGE_START_LAZY() { return getToken(RegexParser.RANGE_START_LAZY, 0); }
		public TerminalNode RANGE_END() { return getToken(RegexParser.RANGE_END, 0); }
		public TerminalNode COMMA() { return getToken(RegexParser.COMMA, 0); }
		public List<TerminalNode> INT() { return getTokens(RegexParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(RegexParser.INT, i);
		}
		public RangeLazyContext(RangeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterRangeLazy(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitRangeLazy(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitRangeLazy(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RangeGreedyContext extends RangeContext {
		public Token lower_bound;
		public Token upper_bound;
		public TerminalNode RANGE_START() { return getToken(RegexParser.RANGE_START, 0); }
		public TerminalNode RANGE_END() { return getToken(RegexParser.RANGE_END, 0); }
		public TerminalNode COMMA() { return getToken(RegexParser.COMMA, 0); }
		public List<TerminalNode> INT() { return getTokens(RegexParser.INT); }
		public TerminalNode INT(int i) {
			return getToken(RegexParser.INT, i);
		}
		public RangeGreedyContext(RangeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterRangeGreedy(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitRangeGreedy(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitRangeGreedy(this);
			else return visitor.visitChildren(this);
		}
	}

	public final RangeContext range() throws RecognitionException {
		RangeContext _localctx = new RangeContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_range);
		int _la;
		try {
			setState(139);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case RANGE_START:
				_localctx = new RangeGreedyContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(117);
				match(RANGE_START);
				setState(119);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==INT) {
					{
					setState(118);
					((RangeGreedyContext)_localctx).lower_bound = match(INT);
					}
				}

				setState(125);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(121);
					match(COMMA);
					setState(123);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==INT) {
						{
						setState(122);
						((RangeGreedyContext)_localctx).upper_bound = match(INT);
						}
					}

					}
				}

				setState(127);
				match(RANGE_END);
				}
				break;
			case RANGE_START_LAZY:
				_localctx = new RangeLazyContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(128);
				match(RANGE_START_LAZY);
				setState(130);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==INT) {
					{
					setState(129);
					((RangeLazyContext)_localctx).lower_bound = match(INT);
					}
				}

				setState(136);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==COMMA) {
					{
					setState(132);
					match(COMMA);
					setState(134);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==INT) {
						{
						setState(133);
						((RangeLazyContext)_localctx).upper_bound = match(INT);
						}
					}

					}
				}

				setState(138);
				match(RANGE_END);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Ordinary_atomContext extends ParserRuleContext {
		public Ordinary_atomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ordinary_atom; }
	 
		public Ordinary_atomContext() { }
		public void copyFrom(Ordinary_atomContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CharCodeContext extends Ordinary_atomContext {
		public Char_codeContext char_code() {
			return getRuleContext(Char_codeContext.class,0);
		}
		public CharCodeContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCharCode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCharCode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCharCode(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AnyCharContext extends Ordinary_atomContext {
		public TerminalNode DOT() { return getToken(RegexParser.DOT, 0); }
		public AnyCharContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAnyChar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAnyChar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAnyChar(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BackreferenceContext extends Ordinary_atomContext {
		public TerminalNode BACKREFERENCE() { return getToken(RegexParser.BACKREFERENCE, 0); }
		public BackreferenceContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBackreference(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBackreference(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBackreference(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LastSubstituteContext extends Ordinary_atomContext {
		public TerminalNode LAST_SUBSTITUTE() { return getToken(RegexParser.LAST_SUBSTITUTE, 0); }
		public LastSubstituteContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterLastSubstitute(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitLastSubstitute(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitLastSubstitute(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CharClassContext extends Ordinary_atomContext {
		public Char_classContext char_class() {
			return getRuleContext(Char_classContext.class,0);
		}
		public CharClassContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCharClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCharClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCharClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollecContext extends Ordinary_atomContext {
		public CollectionContext collection() {
			return getRuleContext(CollectionContext.class,0);
		}
		public CollecContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCollec(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCollec(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCollec(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LiteralCharContext extends Ordinary_atomContext {
		public TerminalNode LITERAL_CHAR() { return getToken(RegexParser.LITERAL_CHAR, 0); }
		public TerminalNode CARET() { return getToken(RegexParser.CARET, 0); }
		public TerminalNode DOLLAR() { return getToken(RegexParser.DOLLAR, 0); }
		public TerminalNode OPTIONALLY_MATCHED_END() { return getToken(RegexParser.OPTIONALLY_MATCHED_END, 0); }
		public LiteralCharContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterLiteralChar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitLiteralChar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitLiteralChar(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AnyCharNLContext extends Ordinary_atomContext {
		public TerminalNode DOTNL() { return getToken(RegexParser.DOTNL, 0); }
		public AnyCharNLContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAnyCharNL(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAnyCharNL(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAnyCharNL(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ZeroWidthContext extends Ordinary_atomContext {
		public Zero_widthContext zero_width() {
			return getRuleContext(Zero_widthContext.class,0);
		}
		public ZeroWidthContext(Ordinary_atomContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterZeroWidth(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitZeroWidth(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitZeroWidth(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ordinary_atomContext ordinary_atom() throws RecognitionException {
		Ordinary_atomContext _localctx = new Ordinary_atomContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_ordinary_atom);
		int _la;
		try {
			setState(150);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LITERAL_CHAR:
			case CARET:
			case DOLLAR:
			case OPTIONALLY_MATCHED_END:
				_localctx = new LiteralCharContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(141);
				_la = _input.LA(1);
				if ( !(_la==LITERAL_CHAR || ((((_la - 79)) & ~0x3f) == 0 && ((1L << (_la - 79)) & 8589934595L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case DOT:
				_localctx = new AnyCharContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(142);
				match(DOT);
				}
				break;
			case DOTNL:
				_localctx = new AnyCharNLContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(143);
				match(DOTNL);
				}
				break;
			case BACKREFERENCE:
				_localctx = new BackreferenceContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(144);
				match(BACKREFERENCE);
				}
				break;
			case LAST_SUBSTITUTE:
				_localctx = new LastSubstituteContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(145);
				match(LAST_SUBSTITUTE);
				}
				break;
			case CURSOR:
			case START_MATCH:
			case END_MATCH:
			case START_OF_FILE:
			case END_OF_FILE:
			case START_OF_LINE:
			case END_OF_LINE:
			case START_OF_WORD:
			case END_OF_WORD:
			case VISUAL:
			case LINE:
			case BEFORE_LINE:
			case AFTER_LINE:
			case COLUMN:
			case BEFORE_COLUMN:
			case AFTER_COLUMN:
			case LINE_CURSOR:
			case BEFORE_LINE_CURSOR:
			case AFTER_LINE_CURSOR:
			case COLUMN_CURSOR:
			case BEFORE_COLUMN_CURSOR:
			case AFTER_COLUMN_CURSOR:
			case MARK:
			case BEFORE_MARK:
			case AFTER_MARK:
				_localctx = new ZeroWidthContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(146);
				zero_width();
				}
				break;
			case CLASS_IDENTIFIER:
			case CLASS_IDENTIFIER_D:
			case CLASS_KEYWORD:
			case CLASS_KEYWORD_D:
			case CLASS_FILENAME:
			case CLASS_FILENAME_D:
			case CLASS_PRINTABLE:
			case CLASS_PRINTABLE_D:
			case CLASS_WS:
			case CLASS_NOT_WS:
			case CLASS_DIGIT:
			case CLASS_NOT_DIGIT:
			case CLASS_HEX:
			case CLASS_NOT_HEX:
			case CLASS_OCTAL:
			case CLASS_NOT_OCTAL:
			case CLASS_WORD:
			case CLASS_NOT_WORD:
			case CLASS_HEADWORD:
			case CLASS_NOT_HEADWORD:
			case CLASS_ALPHA:
			case CLASS_NOT_ALPHA:
			case CLASS_LCASE:
			case CLASS_NOT_LCASE:
			case CLASS_UCASE:
			case CLASS_NOT_UCASE:
			case CLASS_ESC:
			case CLASS_TAB:
			case CLASS_CR:
			case CLASS_BS:
			case CLASS_NL:
			case CLASS_IDENTIFIER_NL:
			case CLASS_IDENTIFIER_D_NL:
			case CLASS_KEYWORD_NL:
			case CLASS_KEYWORD_D_NL:
			case CLASS_FILENAME_NL:
			case CLASS_FILENAME_D_NL:
			case CLASS_PRINTABLE_NL:
			case CLASS_PRINTABLE_D_NL:
			case CLASS_WS_NL:
			case CLASS_NOT_WS_NL:
			case CLASS_DIGIT_NL:
			case CLASS_NOT_DIGIT_NL:
			case CLASS_HEX_NL:
			case CLASS_NOT_HEX_NL:
			case CLASS_OCTAL_NL:
			case CLASS_NOT_OCTAL_NL:
			case CLASS_WORD_NL:
			case CLASS_NOT_WORD_NL:
			case CLASS_HEADWORD_NL:
			case CLASS_NOT_HEADWORD_NL:
			case CLASS_ALPHA_NL:
			case CLASS_NOT_ALPHA_NL:
			case CLASS_LCASE_NL:
			case CLASS_NOT_LCASE_NL:
			case CLASS_UCASE_NL:
			case CLASS_NOT_UCASE_NL:
				_localctx = new CharClassContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(147);
				char_class();
				}
				break;
			case COLLECTION_START:
				_localctx = new CollecContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(148);
				collection();
				}
				break;
			case DECIMAL_CODE:
			case OCTAL_CODE:
			case HEXADECIMAL_CODE:
			case UNICODE_CODE:
			case WIDE_UNICODE_CODE:
				_localctx = new CharCodeContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(149);
				char_code();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Char_classContext extends ParserRuleContext {
		public Char_classContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_char_class; }
	 
		public Char_classContext() { }
		public void copyFrom(Char_classContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotAlphaContext extends Char_classContext {
		public TerminalNode CLASS_NOT_ALPHA() { return getToken(RegexParser.CLASS_NOT_ALPHA, 0); }
		public TerminalNode CLASS_NOT_ALPHA_NL() { return getToken(RegexParser.CLASS_NOT_ALPHA_NL, 0); }
		public NotAlphaContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotAlpha(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotAlpha(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotAlpha(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotHexContext extends Char_classContext {
		public TerminalNode CLASS_NOT_HEX() { return getToken(RegexParser.CLASS_NOT_HEX, 0); }
		public TerminalNode CLASS_NOT_HEX_NL() { return getToken(RegexParser.CLASS_NOT_HEX_NL, 0); }
		public NotHexContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotHex(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotHex(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotHex(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotHeadOfWordContext extends Char_classContext {
		public TerminalNode CLASS_NOT_HEADWORD() { return getToken(RegexParser.CLASS_NOT_HEADWORD, 0); }
		public TerminalNode CLASS_NOT_HEADWORD_NL() { return getToken(RegexParser.CLASS_NOT_HEADWORD_NL, 0); }
		public NotHeadOfWordContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotHeadOfWord(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotHeadOfWord(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotHeadOfWord(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HeadofwordContext extends Char_classContext {
		public TerminalNode CLASS_HEADWORD() { return getToken(RegexParser.CLASS_HEADWORD, 0); }
		public TerminalNode CLASS_HEADWORD_NL() { return getToken(RegexParser.CLASS_HEADWORD_NL, 0); }
		public HeadofwordContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterHeadofword(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitHeadofword(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitHeadofword(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class WhitespaceContext extends Char_classContext {
		public TerminalNode CLASS_WS() { return getToken(RegexParser.CLASS_WS, 0); }
		public TerminalNode CLASS_WS_NL() { return getToken(RegexParser.CLASS_WS_NL, 0); }
		public WhitespaceContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterWhitespace(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitWhitespace(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitWhitespace(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotUcaseContext extends Char_classContext {
		public TerminalNode CLASS_NOT_UCASE() { return getToken(RegexParser.CLASS_NOT_UCASE, 0); }
		public TerminalNode CLASS_NOT_UCASE_NL() { return getToken(RegexParser.CLASS_NOT_UCASE_NL, 0); }
		public NotUcaseContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotUcase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotUcase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotUcase(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BSContext extends Char_classContext {
		public TerminalNode CLASS_BS() { return getToken(RegexParser.CLASS_BS, 0); }
		public BSContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBS(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBS(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBS(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class WordcharContext extends Char_classContext {
		public TerminalNode CLASS_WORD() { return getToken(RegexParser.CLASS_WORD, 0); }
		public TerminalNode CLASS_WORD_NL() { return getToken(RegexParser.CLASS_WORD_NL, 0); }
		public WordcharContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterWordchar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitWordchar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitWordchar(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierContext extends Char_classContext {
		public TerminalNode CLASS_IDENTIFIER() { return getToken(RegexParser.CLASS_IDENTIFIER, 0); }
		public TerminalNode CLASS_IDENTIFIER_NL() { return getToken(RegexParser.CLASS_IDENTIFIER_NL, 0); }
		public IdentifierContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterIdentifier(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitIdentifier(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitIdentifier(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotwordcharContext extends Char_classContext {
		public TerminalNode CLASS_NOT_WORD() { return getToken(RegexParser.CLASS_NOT_WORD, 0); }
		public TerminalNode CLASS_NOT_WORD_NL() { return getToken(RegexParser.CLASS_NOT_WORD_NL, 0); }
		public NotwordcharContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotwordchar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotwordchar(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotwordchar(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EscContext extends Char_classContext {
		public TerminalNode CLASS_ESC() { return getToken(RegexParser.CLASS_ESC, 0); }
		public EscContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterEsc(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitEsc(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitEsc(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FilenameNotDigitContext extends Char_classContext {
		public TerminalNode CLASS_FILENAME_D() { return getToken(RegexParser.CLASS_FILENAME_D, 0); }
		public TerminalNode CLASS_FILENAME_D_NL() { return getToken(RegexParser.CLASS_FILENAME_D_NL, 0); }
		public FilenameNotDigitContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterFilenameNotDigit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitFilenameNotDigit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitFilenameNotDigit(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotLcaseContext extends Char_classContext {
		public TerminalNode CLASS_NOT_LCASE() { return getToken(RegexParser.CLASS_NOT_LCASE, 0); }
		public TerminalNode CLASS_NOT_LCASE_NL() { return getToken(RegexParser.CLASS_NOT_LCASE_NL, 0); }
		public NotLcaseContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotLcase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotLcase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotLcase(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UcaseContext extends Char_classContext {
		public TerminalNode CLASS_UCASE() { return getToken(RegexParser.CLASS_UCASE, 0); }
		public TerminalNode CLASS_UCASE_NL() { return getToken(RegexParser.CLASS_UCASE_NL, 0); }
		public UcaseContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterUcase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitUcase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitUcase(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IdentifierNotDigitContext extends Char_classContext {
		public TerminalNode CLASS_IDENTIFIER_D() { return getToken(RegexParser.CLASS_IDENTIFIER_D, 0); }
		public TerminalNode CLASS_IDENTIFIER_D_NL() { return getToken(RegexParser.CLASS_IDENTIFIER_D_NL, 0); }
		public IdentifierNotDigitContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterIdentifierNotDigit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitIdentifierNotDigit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitIdentifierNotDigit(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LcaseContext extends Char_classContext {
		public TerminalNode CLASS_LCASE() { return getToken(RegexParser.CLASS_LCASE, 0); }
		public TerminalNode CLASS_LCASE_NL() { return getToken(RegexParser.CLASS_LCASE_NL, 0); }
		public LcaseContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterLcase(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitLcase(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitLcase(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DigitContext extends Char_classContext {
		public TerminalNode CLASS_DIGIT() { return getToken(RegexParser.CLASS_DIGIT, 0); }
		public TerminalNode CLASS_DIGIT_NL() { return getToken(RegexParser.CLASS_DIGIT_NL, 0); }
		public DigitContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterDigit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitDigit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitDigit(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OctalContext extends Char_classContext {
		public TerminalNode CLASS_OCTAL() { return getToken(RegexParser.CLASS_OCTAL, 0); }
		public TerminalNode CLASS_OCTAL_NL() { return getToken(RegexParser.CLASS_OCTAL_NL, 0); }
		public OctalContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterOctal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitOctal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitOctal(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class KeywordContext extends Char_classContext {
		public TerminalNode CLASS_KEYWORD() { return getToken(RegexParser.CLASS_KEYWORD, 0); }
		public TerminalNode CLASS_KEYWORD_NL() { return getToken(RegexParser.CLASS_KEYWORD_NL, 0); }
		public KeywordContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterKeyword(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitKeyword(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitKeyword(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FilenameContext extends Char_classContext {
		public TerminalNode CLASS_FILENAME() { return getToken(RegexParser.CLASS_FILENAME, 0); }
		public TerminalNode CLASS_FILENAME_NL() { return getToken(RegexParser.CLASS_FILENAME_NL, 0); }
		public FilenameContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterFilename(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitFilename(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitFilename(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotDigitContext extends Char_classContext {
		public TerminalNode CLASS_NOT_DIGIT() { return getToken(RegexParser.CLASS_NOT_DIGIT, 0); }
		public TerminalNode CLASS_NOT_DIGIT_NL() { return getToken(RegexParser.CLASS_NOT_DIGIT_NL, 0); }
		public NotDigitContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotDigit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotDigit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotDigit(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CRContext extends Char_classContext {
		public TerminalNode CLASS_CR() { return getToken(RegexParser.CLASS_CR, 0); }
		public CRContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCR(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCR(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCR(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotOctalContext extends Char_classContext {
		public TerminalNode CLASS_NOT_OCTAL() { return getToken(RegexParser.CLASS_NOT_OCTAL, 0); }
		public TerminalNode CLASS_NOT_OCTAL_NL() { return getToken(RegexParser.CLASS_NOT_OCTAL_NL, 0); }
		public NotOctalContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotOctal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotOctal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotOctal(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TabContext extends Char_classContext {
		public TerminalNode CLASS_TAB() { return getToken(RegexParser.CLASS_TAB, 0); }
		public TabContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterTab(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitTab(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitTab(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NotWhitespaceContext extends Char_classContext {
		public TerminalNode CLASS_NOT_WS() { return getToken(RegexParser.CLASS_NOT_WS, 0); }
		public TerminalNode CLASS_NOT_WS_NL() { return getToken(RegexParser.CLASS_NOT_WS_NL, 0); }
		public NotWhitespaceContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNotWhitespace(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNotWhitespace(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNotWhitespace(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class KeywordNotDigitContext extends Char_classContext {
		public TerminalNode CLASS_KEYWORD_D() { return getToken(RegexParser.CLASS_KEYWORD_D, 0); }
		public TerminalNode CLASS_KEYWORD_D_NL() { return getToken(RegexParser.CLASS_KEYWORD_D_NL, 0); }
		public KeywordNotDigitContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterKeywordNotDigit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitKeywordNotDigit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitKeywordNotDigit(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AlphaContext extends Char_classContext {
		public TerminalNode CLASS_ALPHA() { return getToken(RegexParser.CLASS_ALPHA, 0); }
		public TerminalNode CLASS_ALPHA_NL() { return getToken(RegexParser.CLASS_ALPHA_NL, 0); }
		public AlphaContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAlpha(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAlpha(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAlpha(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HexContext extends Char_classContext {
		public TerminalNode CLASS_HEX() { return getToken(RegexParser.CLASS_HEX, 0); }
		public TerminalNode CLASS_HEX_NL() { return getToken(RegexParser.CLASS_HEX_NL, 0); }
		public HexContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterHex(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitHex(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitHex(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PrintableContext extends Char_classContext {
		public TerminalNode CLASS_PRINTABLE() { return getToken(RegexParser.CLASS_PRINTABLE, 0); }
		public TerminalNode CLASS_PRINTABLE_NL() { return getToken(RegexParser.CLASS_PRINTABLE_NL, 0); }
		public PrintableContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPrintable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPrintable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPrintable(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PrintableNotDigitContext extends Char_classContext {
		public TerminalNode CLASS_PRINTABLE_D() { return getToken(RegexParser.CLASS_PRINTABLE_D, 0); }
		public TerminalNode CLASS_PRINTABLE_D_NL() { return getToken(RegexParser.CLASS_PRINTABLE_D_NL, 0); }
		public PrintableNotDigitContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPrintableNotDigit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPrintableNotDigit(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPrintableNotDigit(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class NLContext extends Char_classContext {
		public TerminalNode CLASS_NL() { return getToken(RegexParser.CLASS_NL, 0); }
		public NLContext(Char_classContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterNL(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitNL(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitNL(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Char_classContext char_class() throws RecognitionException {
		Char_classContext _localctx = new Char_classContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_char_class);
		int _la;
		try {
			setState(183);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CLASS_IDENTIFIER:
			case CLASS_IDENTIFIER_NL:
				_localctx = new IdentifierContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(152);
				_la = _input.LA(1);
				if ( !(_la==CLASS_IDENTIFIER || _la==CLASS_IDENTIFIER_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_IDENTIFIER_D:
			case CLASS_IDENTIFIER_D_NL:
				_localctx = new IdentifierNotDigitContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(153);
				_la = _input.LA(1);
				if ( !(_la==CLASS_IDENTIFIER_D || _la==CLASS_IDENTIFIER_D_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_KEYWORD:
			case CLASS_KEYWORD_NL:
				_localctx = new KeywordContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(154);
				_la = _input.LA(1);
				if ( !(_la==CLASS_KEYWORD || _la==CLASS_KEYWORD_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_KEYWORD_D:
			case CLASS_KEYWORD_D_NL:
				_localctx = new KeywordNotDigitContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(155);
				_la = _input.LA(1);
				if ( !(_la==CLASS_KEYWORD_D || _la==CLASS_KEYWORD_D_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_FILENAME:
			case CLASS_FILENAME_NL:
				_localctx = new FilenameContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(156);
				_la = _input.LA(1);
				if ( !(_la==CLASS_FILENAME || _la==CLASS_FILENAME_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_FILENAME_D:
			case CLASS_FILENAME_D_NL:
				_localctx = new FilenameNotDigitContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(157);
				_la = _input.LA(1);
				if ( !(_la==CLASS_FILENAME_D || _la==CLASS_FILENAME_D_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_PRINTABLE:
			case CLASS_PRINTABLE_NL:
				_localctx = new PrintableContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(158);
				_la = _input.LA(1);
				if ( !(_la==CLASS_PRINTABLE || _la==CLASS_PRINTABLE_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_PRINTABLE_D:
			case CLASS_PRINTABLE_D_NL:
				_localctx = new PrintableNotDigitContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(159);
				_la = _input.LA(1);
				if ( !(_la==CLASS_PRINTABLE_D || _la==CLASS_PRINTABLE_D_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_WS:
			case CLASS_WS_NL:
				_localctx = new WhitespaceContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(160);
				_la = _input.LA(1);
				if ( !(_la==CLASS_WS || _la==CLASS_WS_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_WS:
			case CLASS_NOT_WS_NL:
				_localctx = new NotWhitespaceContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(161);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_WS || _la==CLASS_NOT_WS_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_DIGIT:
			case CLASS_DIGIT_NL:
				_localctx = new DigitContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(162);
				_la = _input.LA(1);
				if ( !(_la==CLASS_DIGIT || _la==CLASS_DIGIT_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_DIGIT:
			case CLASS_NOT_DIGIT_NL:
				_localctx = new NotDigitContext(_localctx);
				enterOuterAlt(_localctx, 12);
				{
				setState(163);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_DIGIT || _la==CLASS_NOT_DIGIT_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_HEX:
			case CLASS_HEX_NL:
				_localctx = new HexContext(_localctx);
				enterOuterAlt(_localctx, 13);
				{
				setState(164);
				_la = _input.LA(1);
				if ( !(_la==CLASS_HEX || _la==CLASS_HEX_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_HEX:
			case CLASS_NOT_HEX_NL:
				_localctx = new NotHexContext(_localctx);
				enterOuterAlt(_localctx, 14);
				{
				setState(165);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_HEX || _la==CLASS_NOT_HEX_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_OCTAL:
			case CLASS_OCTAL_NL:
				_localctx = new OctalContext(_localctx);
				enterOuterAlt(_localctx, 15);
				{
				setState(166);
				_la = _input.LA(1);
				if ( !(_la==CLASS_OCTAL || _la==CLASS_OCTAL_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_OCTAL:
			case CLASS_NOT_OCTAL_NL:
				_localctx = new NotOctalContext(_localctx);
				enterOuterAlt(_localctx, 16);
				{
				setState(167);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_OCTAL || _la==CLASS_NOT_OCTAL_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_WORD:
			case CLASS_WORD_NL:
				_localctx = new WordcharContext(_localctx);
				enterOuterAlt(_localctx, 17);
				{
				setState(168);
				_la = _input.LA(1);
				if ( !(_la==CLASS_WORD || _la==CLASS_WORD_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_WORD:
			case CLASS_NOT_WORD_NL:
				_localctx = new NotwordcharContext(_localctx);
				enterOuterAlt(_localctx, 18);
				{
				setState(169);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_WORD || _la==CLASS_NOT_WORD_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_HEADWORD:
			case CLASS_HEADWORD_NL:
				_localctx = new HeadofwordContext(_localctx);
				enterOuterAlt(_localctx, 19);
				{
				setState(170);
				_la = _input.LA(1);
				if ( !(_la==CLASS_HEADWORD || _la==CLASS_HEADWORD_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_HEADWORD:
			case CLASS_NOT_HEADWORD_NL:
				_localctx = new NotHeadOfWordContext(_localctx);
				enterOuterAlt(_localctx, 20);
				{
				setState(171);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_HEADWORD || _la==CLASS_NOT_HEADWORD_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_ALPHA:
			case CLASS_ALPHA_NL:
				_localctx = new AlphaContext(_localctx);
				enterOuterAlt(_localctx, 21);
				{
				setState(172);
				_la = _input.LA(1);
				if ( !(_la==CLASS_ALPHA || _la==CLASS_ALPHA_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_ALPHA:
			case CLASS_NOT_ALPHA_NL:
				_localctx = new NotAlphaContext(_localctx);
				enterOuterAlt(_localctx, 22);
				{
				setState(173);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_ALPHA || _la==CLASS_NOT_ALPHA_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_LCASE:
			case CLASS_LCASE_NL:
				_localctx = new LcaseContext(_localctx);
				enterOuterAlt(_localctx, 23);
				{
				setState(174);
				_la = _input.LA(1);
				if ( !(_la==CLASS_LCASE || _la==CLASS_LCASE_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_LCASE:
			case CLASS_NOT_LCASE_NL:
				_localctx = new NotLcaseContext(_localctx);
				enterOuterAlt(_localctx, 24);
				{
				setState(175);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_LCASE || _la==CLASS_NOT_LCASE_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_UCASE:
			case CLASS_UCASE_NL:
				_localctx = new UcaseContext(_localctx);
				enterOuterAlt(_localctx, 25);
				{
				setState(176);
				_la = _input.LA(1);
				if ( !(_la==CLASS_UCASE || _la==CLASS_UCASE_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_NOT_UCASE:
			case CLASS_NOT_UCASE_NL:
				_localctx = new NotUcaseContext(_localctx);
				enterOuterAlt(_localctx, 26);
				{
				setState(177);
				_la = _input.LA(1);
				if ( !(_la==CLASS_NOT_UCASE || _la==CLASS_NOT_UCASE_NL) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case CLASS_ESC:
				_localctx = new EscContext(_localctx);
				enterOuterAlt(_localctx, 27);
				{
				setState(178);
				match(CLASS_ESC);
				}
				break;
			case CLASS_TAB:
				_localctx = new TabContext(_localctx);
				enterOuterAlt(_localctx, 28);
				{
				setState(179);
				match(CLASS_TAB);
				}
				break;
			case CLASS_CR:
				_localctx = new CRContext(_localctx);
				enterOuterAlt(_localctx, 29);
				{
				setState(180);
				match(CLASS_CR);
				}
				break;
			case CLASS_BS:
				_localctx = new BSContext(_localctx);
				enterOuterAlt(_localctx, 30);
				{
				setState(181);
				match(CLASS_BS);
				}
				break;
			case CLASS_NL:
				_localctx = new NLContext(_localctx);
				enterOuterAlt(_localctx, 31);
				{
				setState(182);
				match(CLASS_NL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class CollectionContext extends ParserRuleContext {
		public CollectionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection; }
	 
		public CollectionContext() { }
		public void copyFrom(CollectionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionNegContext extends CollectionContext {
		public Collection_elemContext collection_elem;
		public List<Collection_elemContext> collection_elems = new ArrayList<Collection_elemContext>();
		public TerminalNode COLLECTION_START() { return getToken(RegexParser.COLLECTION_START, 0); }
		public TerminalNode CARET() { return getToken(RegexParser.CARET, 0); }
		public TerminalNode COLLECTION_END() { return getToken(RegexParser.COLLECTION_END, 0); }
		public List<Collection_elemContext> collection_elem() {
			return getRuleContexts(Collection_elemContext.class);
		}
		public Collection_elemContext collection_elem(int i) {
			return getRuleContext(Collection_elemContext.class,i);
		}
		public CollectionNegContext(CollectionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCollectionNeg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCollectionNeg(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCollectionNeg(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CollectionPosContext extends CollectionContext {
		public Collection_elemContext collection_elem;
		public List<Collection_elemContext> collection_elems = new ArrayList<Collection_elemContext>();
		public TerminalNode COLLECTION_START() { return getToken(RegexParser.COLLECTION_START, 0); }
		public TerminalNode COLLECTION_END() { return getToken(RegexParser.COLLECTION_END, 0); }
		public List<Collection_elemContext> collection_elem() {
			return getRuleContexts(Collection_elemContext.class);
		}
		public Collection_elemContext collection_elem(int i) {
			return getRuleContext(Collection_elemContext.class,i);
		}
		public CollectionPosContext(CollectionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCollectionPos(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCollectionPos(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCollectionPos(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CollectionContext collection() throws RecognitionException {
		CollectionContext _localctx = new CollectionContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_collection);
		int _la;
		try {
			setState(202);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
			case 1:
				_localctx = new CollectionNegContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(185);
				match(COLLECTION_START);
				setState(186);
				match(CARET);
				setState(190);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COLLECTION_LITERAL_CHAR || _la==CARET || ((((_la - 144)) & ~0x3f) == 0 && ((1L << (_la - 144)) & 1048575L) != 0)) {
					{
					{
					setState(187);
					((CollectionNegContext)_localctx).collection_elem = collection_elem();
					((CollectionNegContext)_localctx).collection_elems.add(((CollectionNegContext)_localctx).collection_elem);
					}
					}
					setState(192);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(193);
				match(COLLECTION_END);
				}
				break;
			case 2:
				_localctx = new CollectionPosContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(194);
				match(COLLECTION_START);
				setState(198);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COLLECTION_LITERAL_CHAR || _la==CARET || ((((_la - 144)) & ~0x3f) == 0 && ((1L << (_la - 144)) & 1048575L) != 0)) {
					{
					{
					setState(195);
					((CollectionPosContext)_localctx).collection_elem = collection_elem();
					((CollectionPosContext)_localctx).collection_elems.add(((CollectionPosContext)_localctx).collection_elem);
					}
					}
					setState(200);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(201);
				match(COLLECTION_END);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_elemContext extends ParserRuleContext {
		public Collection_elemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_elem; }
	 
		public Collection_elemContext() { }
		public void copyFrom(Collection_elemContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RangeColElemContext extends Collection_elemContext {
		public Token start;
		public Token end;
		public List<TerminalNode> DASH() { return getTokens(RegexParser.DASH); }
		public TerminalNode DASH(int i) {
			return getToken(RegexParser.DASH, i);
		}
		public List<TerminalNode> COLLECTION_LITERAL_CHAR() { return getTokens(RegexParser.COLLECTION_LITERAL_CHAR); }
		public TerminalNode COLLECTION_LITERAL_CHAR(int i) {
			return getToken(RegexParser.COLLECTION_LITERAL_CHAR, i);
		}
		public List<TerminalNode> CARET() { return getTokens(RegexParser.CARET); }
		public TerminalNode CARET(int i) {
			return getToken(RegexParser.CARET, i);
		}
		public RangeColElemContext(Collection_elemContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterRangeColElem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitRangeColElem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitRangeColElem(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SingleColElemContext extends Collection_elemContext {
		public TerminalNode COLLECTION_LITERAL_CHAR() { return getToken(RegexParser.COLLECTION_LITERAL_CHAR, 0); }
		public TerminalNode DASH() { return getToken(RegexParser.DASH, 0); }
		public TerminalNode CARET() { return getToken(RegexParser.CARET, 0); }
		public SingleColElemContext(Collection_elemContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterSingleColElem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitSingleColElem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitSingleColElem(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CharClassColElemContext extends Collection_elemContext {
		public Collection_char_class_expressionContext collection_char_class_expression() {
			return getRuleContext(Collection_char_class_expressionContext.class,0);
		}
		public CharClassColElemContext(Collection_elemContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCharClassColElem(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCharClassColElem(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCharClassColElem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_elemContext collection_elem() throws RecognitionException {
		Collection_elemContext _localctx = new Collection_elemContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_collection_elem);
		int _la;
		try {
			setState(209);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
			case 1:
				_localctx = new CharClassColElemContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(204);
				collection_char_class_expression();
				}
				break;
			case 2:
				_localctx = new RangeColElemContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(205);
				((RangeColElemContext)_localctx).start = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==COLLECTION_LITERAL_CHAR || _la==CARET || _la==DASH) ) {
					((RangeColElemContext)_localctx).start = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(206);
				match(DASH);
				setState(207);
				((RangeColElemContext)_localctx).end = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==COLLECTION_LITERAL_CHAR || _la==CARET || _la==DASH) ) {
					((RangeColElemContext)_localctx).end = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case 3:
				_localctx = new SingleColElemContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(208);
				_la = _input.LA(1);
				if ( !(_la==COLLECTION_LITERAL_CHAR || _la==CARET || _la==DASH) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_char_class_expressionContext extends ParserRuleContext {
		public Collection_char_class_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_char_class_expression; }
	 
		public Collection_char_class_expressionContext() { }
		public void copyFrom(Collection_char_class_expressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PrintClassContext extends Collection_char_class_expressionContext {
		public TerminalNode PRINT_CLASS() { return getToken(RegexParser.PRINT_CLASS, 0); }
		public PrintClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPrintClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPrintClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPrintClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class UpperClassContext extends Collection_char_class_expressionContext {
		public TerminalNode UPPER_CLASS() { return getToken(RegexParser.UPPER_CLASS, 0); }
		public UpperClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterUpperClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitUpperClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitUpperClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BlankClassContext extends Collection_char_class_expressionContext {
		public TerminalNode BLANK_CLASS() { return getToken(RegexParser.BLANK_CLASS, 0); }
		public BlankClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBlankClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBlankClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBlankClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AlphaClassContext extends Collection_char_class_expressionContext {
		public TerminalNode ALPHA_CLASS() { return getToken(RegexParser.ALPHA_CLASS, 0); }
		public AlphaClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAlphaClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAlphaClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAlphaClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DigitClassContext extends Collection_char_class_expressionContext {
		public TerminalNode DIGIT_CLASS() { return getToken(RegexParser.DIGIT_CLASS, 0); }
		public DigitClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterDigitClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitDigitClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitDigitClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SpaceClassContext extends Collection_char_class_expressionContext {
		public TerminalNode SPACE_CLASS() { return getToken(RegexParser.SPACE_CLASS, 0); }
		public SpaceClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterSpaceClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitSpaceClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitSpaceClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class PunctClassContext extends Collection_char_class_expressionContext {
		public TerminalNode PUNCT_CLASS() { return getToken(RegexParser.PUNCT_CLASS, 0); }
		public PunctClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterPunctClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitPunctClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitPunctClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CntrlClassContext extends Collection_char_class_expressionContext {
		public TerminalNode CNTRL_CLASS() { return getToken(RegexParser.CNTRL_CLASS, 0); }
		public CntrlClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCntrlClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCntrlClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCntrlClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ReturnClassContext extends Collection_char_class_expressionContext {
		public TerminalNode RETURN_CLASS() { return getToken(RegexParser.RETURN_CLASS, 0); }
		public ReturnClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterReturnClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitReturnClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitReturnClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class IdentClassContext extends Collection_char_class_expressionContext {
		public TerminalNode IDENT_CLASS() { return getToken(RegexParser.IDENT_CLASS, 0); }
		public IdentClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterIdentClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitIdentClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitIdentClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LowerClassContext extends Collection_char_class_expressionContext {
		public TerminalNode LOWER_CLASS() { return getToken(RegexParser.LOWER_CLASS, 0); }
		public LowerClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterLowerClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitLowerClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitLowerClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class KeywordClassContext extends Collection_char_class_expressionContext {
		public TerminalNode KEYWORD_CLASS() { return getToken(RegexParser.KEYWORD_CLASS, 0); }
		public KeywordClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterKeywordClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitKeywordClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitKeywordClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class GraphClassContext extends Collection_char_class_expressionContext {
		public TerminalNode GRAPH_CLASS() { return getToken(RegexParser.GRAPH_CLASS, 0); }
		public GraphClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterGraphClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitGraphClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitGraphClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FnameClassContext extends Collection_char_class_expressionContext {
		public TerminalNode FNAME_CLASS() { return getToken(RegexParser.FNAME_CLASS, 0); }
		public FnameClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterFnameClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitFnameClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitFnameClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EscapeClassContext extends Collection_char_class_expressionContext {
		public TerminalNode ESCAPE_CLASS() { return getToken(RegexParser.ESCAPE_CLASS, 0); }
		public EscapeClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterEscapeClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitEscapeClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitEscapeClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class XdigitClassContext extends Collection_char_class_expressionContext {
		public TerminalNode XDIGIT_CLASS() { return getToken(RegexParser.XDIGIT_CLASS, 0); }
		public XdigitClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterXdigitClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitXdigitClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitXdigitClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BackspaceClassContext extends Collection_char_class_expressionContext {
		public TerminalNode BACKSPACE_CLASS() { return getToken(RegexParser.BACKSPACE_CLASS, 0); }
		public BackspaceClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBackspaceClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBackspaceClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBackspaceClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AlnumClassContext extends Collection_char_class_expressionContext {
		public TerminalNode ALNUM_CLASS() { return getToken(RegexParser.ALNUM_CLASS, 0); }
		public AlnumClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAlnumClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAlnumClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAlnumClass(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class TabClassContext extends Collection_char_class_expressionContext {
		public TerminalNode TAB_CLASS() { return getToken(RegexParser.TAB_CLASS, 0); }
		public TabClassContext(Collection_char_class_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterTabClass(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitTabClass(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitTabClass(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_char_class_expressionContext collection_char_class_expression() throws RecognitionException {
		Collection_char_class_expressionContext _localctx = new Collection_char_class_expressionContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_collection_char_class_expression);
		try {
			setState(230);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ALPHA_CLASS:
				_localctx = new AlphaClassContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(211);
				match(ALPHA_CLASS);
				}
				break;
			case ALNUM_CLASS:
				_localctx = new AlnumClassContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(212);
				match(ALNUM_CLASS);
				}
				break;
			case BLANK_CLASS:
				_localctx = new BlankClassContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(213);
				match(BLANK_CLASS);
				}
				break;
			case CNTRL_CLASS:
				_localctx = new CntrlClassContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(214);
				match(CNTRL_CLASS);
				}
				break;
			case DIGIT_CLASS:
				_localctx = new DigitClassContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(215);
				match(DIGIT_CLASS);
				}
				break;
			case GRAPH_CLASS:
				_localctx = new GraphClassContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(216);
				match(GRAPH_CLASS);
				}
				break;
			case LOWER_CLASS:
				_localctx = new LowerClassContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(217);
				match(LOWER_CLASS);
				}
				break;
			case PRINT_CLASS:
				_localctx = new PrintClassContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(218);
				match(PRINT_CLASS);
				}
				break;
			case PUNCT_CLASS:
				_localctx = new PunctClassContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(219);
				match(PUNCT_CLASS);
				}
				break;
			case SPACE_CLASS:
				_localctx = new SpaceClassContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(220);
				match(SPACE_CLASS);
				}
				break;
			case UPPER_CLASS:
				_localctx = new UpperClassContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(221);
				match(UPPER_CLASS);
				}
				break;
			case XDIGIT_CLASS:
				_localctx = new XdigitClassContext(_localctx);
				enterOuterAlt(_localctx, 12);
				{
				setState(222);
				match(XDIGIT_CLASS);
				}
				break;
			case RETURN_CLASS:
				_localctx = new ReturnClassContext(_localctx);
				enterOuterAlt(_localctx, 13);
				{
				setState(223);
				match(RETURN_CLASS);
				}
				break;
			case TAB_CLASS:
				_localctx = new TabClassContext(_localctx);
				enterOuterAlt(_localctx, 14);
				{
				setState(224);
				match(TAB_CLASS);
				}
				break;
			case ESCAPE_CLASS:
				_localctx = new EscapeClassContext(_localctx);
				enterOuterAlt(_localctx, 15);
				{
				setState(225);
				match(ESCAPE_CLASS);
				}
				break;
			case BACKSPACE_CLASS:
				_localctx = new BackspaceClassContext(_localctx);
				enterOuterAlt(_localctx, 16);
				{
				setState(226);
				match(BACKSPACE_CLASS);
				}
				break;
			case IDENT_CLASS:
				_localctx = new IdentClassContext(_localctx);
				enterOuterAlt(_localctx, 17);
				{
				setState(227);
				match(IDENT_CLASS);
				}
				break;
			case KEYWORD_CLASS:
				_localctx = new KeywordClassContext(_localctx);
				enterOuterAlt(_localctx, 18);
				{
				setState(228);
				match(KEYWORD_CLASS);
				}
				break;
			case FNAME_CLASS:
				_localctx = new FnameClassContext(_localctx);
				enterOuterAlt(_localctx, 19);
				{
				setState(229);
				match(FNAME_CLASS);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Zero_widthContext extends ParserRuleContext {
		public Zero_widthContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_zero_width; }
	 
		public Zero_widthContext() { }
		public void copyFrom(Zero_widthContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BeforeColumnCursorContext extends Zero_widthContext {
		public TerminalNode BEFORE_COLUMN_CURSOR() { return getToken(RegexParser.BEFORE_COLUMN_CURSOR, 0); }
		public BeforeColumnCursorContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBeforeColumnCursor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBeforeColumnCursor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBeforeColumnCursor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BeforeLineContext extends Zero_widthContext {
		public TerminalNode BEFORE_LINE() { return getToken(RegexParser.BEFORE_LINE, 0); }
		public BeforeLineContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBeforeLine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBeforeLine(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBeforeLine(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AfterMarkContext extends Zero_widthContext {
		public TerminalNode AFTER_MARK() { return getToken(RegexParser.AFTER_MARK, 0); }
		public AfterMarkContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAfterMark(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAfterMark(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAfterMark(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BeforeLineCursorContext extends Zero_widthContext {
		public TerminalNode BEFORE_LINE_CURSOR() { return getToken(RegexParser.BEFORE_LINE_CURSOR, 0); }
		public BeforeLineCursorContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBeforeLineCursor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBeforeLineCursor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBeforeLineCursor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StartOfLineContext extends Zero_widthContext {
		public TerminalNode START_OF_LINE() { return getToken(RegexParser.START_OF_LINE, 0); }
		public StartOfLineContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterStartOfLine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitStartOfLine(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitStartOfLine(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class MarkContext extends Zero_widthContext {
		public TerminalNode MARK() { return getToken(RegexParser.MARK, 0); }
		public MarkContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterMark(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitMark(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitMark(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class CursorContext extends Zero_widthContext {
		public TerminalNode CURSOR() { return getToken(RegexParser.CURSOR, 0); }
		public CursorContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterCursor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitCursor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitCursor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AfterColumnCursorContext extends Zero_widthContext {
		public TerminalNode AFTER_COLUMN_CURSOR() { return getToken(RegexParser.AFTER_COLUMN_CURSOR, 0); }
		public AfterColumnCursorContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAfterColumnCursor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAfterColumnCursor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAfterColumnCursor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StartOfFileContext extends Zero_widthContext {
		public TerminalNode START_OF_FILE() { return getToken(RegexParser.START_OF_FILE, 0); }
		public StartOfFileContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterStartOfFile(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitStartOfFile(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitStartOfFile(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ColumnContext extends Zero_widthContext {
		public TerminalNode COLUMN() { return getToken(RegexParser.COLUMN, 0); }
		public ColumnContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AfterLineCursorContext extends Zero_widthContext {
		public TerminalNode AFTER_LINE_CURSOR() { return getToken(RegexParser.AFTER_LINE_CURSOR, 0); }
		public AfterLineCursorContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAfterLineCursor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAfterLineCursor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAfterLineCursor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class VisualContext extends Zero_widthContext {
		public TerminalNode VISUAL() { return getToken(RegexParser.VISUAL, 0); }
		public VisualContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterVisual(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitVisual(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitVisual(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ColumnCursorContext extends Zero_widthContext {
		public TerminalNode COLUMN_CURSOR() { return getToken(RegexParser.COLUMN_CURSOR, 0); }
		public ColumnCursorContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterColumnCursor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitColumnCursor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitColumnCursor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BeforeColumnContext extends Zero_widthContext {
		public TerminalNode BEFORE_COLUMN() { return getToken(RegexParser.BEFORE_COLUMN, 0); }
		public BeforeColumnContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBeforeColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBeforeColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBeforeColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EndOfFileContext extends Zero_widthContext {
		public TerminalNode END_OF_FILE() { return getToken(RegexParser.END_OF_FILE, 0); }
		public EndOfFileContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterEndOfFile(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitEndOfFile(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitEndOfFile(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StartMatchContext extends Zero_widthContext {
		public TerminalNode START_MATCH() { return getToken(RegexParser.START_MATCH, 0); }
		public StartMatchContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterStartMatch(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitStartMatch(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitStartMatch(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EndMatchContext extends Zero_widthContext {
		public TerminalNode END_MATCH() { return getToken(RegexParser.END_MATCH, 0); }
		public EndMatchContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterEndMatch(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitEndMatch(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitEndMatch(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AfterColumnContext extends Zero_widthContext {
		public TerminalNode AFTER_COLUMN() { return getToken(RegexParser.AFTER_COLUMN, 0); }
		public AfterColumnContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAfterColumn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAfterColumn(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAfterColumn(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StartOfWordContext extends Zero_widthContext {
		public TerminalNode START_OF_WORD() { return getToken(RegexParser.START_OF_WORD, 0); }
		public StartOfWordContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterStartOfWord(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitStartOfWord(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitStartOfWord(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EndOfWordContext extends Zero_widthContext {
		public TerminalNode END_OF_WORD() { return getToken(RegexParser.END_OF_WORD, 0); }
		public EndOfWordContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterEndOfWord(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitEndOfWord(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitEndOfWord(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LineContext extends Zero_widthContext {
		public TerminalNode LINE() { return getToken(RegexParser.LINE, 0); }
		public LineContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterLine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitLine(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitLine(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EndOfLineContext extends Zero_widthContext {
		public TerminalNode END_OF_LINE() { return getToken(RegexParser.END_OF_LINE, 0); }
		public EndOfLineContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterEndOfLine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitEndOfLine(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitEndOfLine(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class LineCursorContext extends Zero_widthContext {
		public TerminalNode LINE_CURSOR() { return getToken(RegexParser.LINE_CURSOR, 0); }
		public LineCursorContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterLineCursor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitLineCursor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitLineCursor(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BeforeMarkContext extends Zero_widthContext {
		public TerminalNode BEFORE_MARK() { return getToken(RegexParser.BEFORE_MARK, 0); }
		public BeforeMarkContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterBeforeMark(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitBeforeMark(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitBeforeMark(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class AfterLineContext extends Zero_widthContext {
		public TerminalNode AFTER_LINE() { return getToken(RegexParser.AFTER_LINE, 0); }
		public AfterLineContext(Zero_widthContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterAfterLine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitAfterLine(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitAfterLine(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Zero_widthContext zero_width() throws RecognitionException {
		Zero_widthContext _localctx = new Zero_widthContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_zero_width);
		try {
			setState(257);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CURSOR:
				_localctx = new CursorContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(232);
				match(CURSOR);
				}
				break;
			case VISUAL:
				_localctx = new VisualContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(233);
				match(VISUAL);
				}
				break;
			case START_MATCH:
				_localctx = new StartMatchContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(234);
				match(START_MATCH);
				}
				break;
			case END_MATCH:
				_localctx = new EndMatchContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(235);
				match(END_MATCH);
				}
				break;
			case START_OF_FILE:
				_localctx = new StartOfFileContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(236);
				match(START_OF_FILE);
				}
				break;
			case END_OF_FILE:
				_localctx = new EndOfFileContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(237);
				match(END_OF_FILE);
				}
				break;
			case START_OF_LINE:
				_localctx = new StartOfLineContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(238);
				match(START_OF_LINE);
				}
				break;
			case END_OF_LINE:
				_localctx = new EndOfLineContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(239);
				match(END_OF_LINE);
				}
				break;
			case START_OF_WORD:
				_localctx = new StartOfWordContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(240);
				match(START_OF_WORD);
				}
				break;
			case END_OF_WORD:
				_localctx = new EndOfWordContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(241);
				match(END_OF_WORD);
				}
				break;
			case LINE:
				_localctx = new LineContext(_localctx);
				enterOuterAlt(_localctx, 11);
				{
				setState(242);
				match(LINE);
				}
				break;
			case BEFORE_LINE:
				_localctx = new BeforeLineContext(_localctx);
				enterOuterAlt(_localctx, 12);
				{
				setState(243);
				match(BEFORE_LINE);
				}
				break;
			case AFTER_LINE:
				_localctx = new AfterLineContext(_localctx);
				enterOuterAlt(_localctx, 13);
				{
				setState(244);
				match(AFTER_LINE);
				}
				break;
			case LINE_CURSOR:
				_localctx = new LineCursorContext(_localctx);
				enterOuterAlt(_localctx, 14);
				{
				setState(245);
				match(LINE_CURSOR);
				}
				break;
			case BEFORE_LINE_CURSOR:
				_localctx = new BeforeLineCursorContext(_localctx);
				enterOuterAlt(_localctx, 15);
				{
				setState(246);
				match(BEFORE_LINE_CURSOR);
				}
				break;
			case AFTER_LINE_CURSOR:
				_localctx = new AfterLineCursorContext(_localctx);
				enterOuterAlt(_localctx, 16);
				{
				setState(247);
				match(AFTER_LINE_CURSOR);
				}
				break;
			case COLUMN:
				_localctx = new ColumnContext(_localctx);
				enterOuterAlt(_localctx, 17);
				{
				setState(248);
				match(COLUMN);
				}
				break;
			case BEFORE_COLUMN:
				_localctx = new BeforeColumnContext(_localctx);
				enterOuterAlt(_localctx, 18);
				{
				setState(249);
				match(BEFORE_COLUMN);
				}
				break;
			case AFTER_COLUMN:
				_localctx = new AfterColumnContext(_localctx);
				enterOuterAlt(_localctx, 19);
				{
				setState(250);
				match(AFTER_COLUMN);
				}
				break;
			case COLUMN_CURSOR:
				_localctx = new ColumnCursorContext(_localctx);
				enterOuterAlt(_localctx, 20);
				{
				setState(251);
				match(COLUMN_CURSOR);
				}
				break;
			case BEFORE_COLUMN_CURSOR:
				_localctx = new BeforeColumnCursorContext(_localctx);
				enterOuterAlt(_localctx, 21);
				{
				setState(252);
				match(BEFORE_COLUMN_CURSOR);
				}
				break;
			case AFTER_COLUMN_CURSOR:
				_localctx = new AfterColumnCursorContext(_localctx);
				enterOuterAlt(_localctx, 22);
				{
				setState(253);
				match(AFTER_COLUMN_CURSOR);
				}
				break;
			case MARK:
				_localctx = new MarkContext(_localctx);
				enterOuterAlt(_localctx, 23);
				{
				setState(254);
				match(MARK);
				}
				break;
			case BEFORE_MARK:
				_localctx = new BeforeMarkContext(_localctx);
				enterOuterAlt(_localctx, 24);
				{
				setState(255);
				match(BEFORE_MARK);
				}
				break;
			case AFTER_MARK:
				_localctx = new AfterMarkContext(_localctx);
				enterOuterAlt(_localctx, 25);
				{
				setState(256);
				match(AFTER_MARK);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Char_codeContext extends ParserRuleContext {
		public Char_codeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_char_code; }
	 
		public Char_codeContext() { }
		public void copyFrom(Char_codeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DecimalCodeContext extends Char_codeContext {
		public TerminalNode DECIMAL_CODE() { return getToken(RegexParser.DECIMAL_CODE, 0); }
		public DecimalCodeContext(Char_codeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterDecimalCode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitDecimalCode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitDecimalCode(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class OctalCodeContext extends Char_codeContext {
		public TerminalNode OCTAL_CODE() { return getToken(RegexParser.OCTAL_CODE, 0); }
		public OctalCodeContext(Char_codeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterOctalCode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitOctalCode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitOctalCode(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class HexCodeContext extends Char_codeContext {
		public TerminalNode HEXADECIMAL_CODE() { return getToken(RegexParser.HEXADECIMAL_CODE, 0); }
		public TerminalNode UNICODE_CODE() { return getToken(RegexParser.UNICODE_CODE, 0); }
		public TerminalNode WIDE_UNICODE_CODE() { return getToken(RegexParser.WIDE_UNICODE_CODE, 0); }
		public HexCodeContext(Char_codeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).enterHexCode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof RegexParserListener ) ((RegexParserListener)listener).exitHexCode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof RegexParserVisitor ) return ((RegexParserVisitor<? extends T>)visitor).visitHexCode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Char_codeContext char_code() throws RecognitionException {
		Char_codeContext _localctx = new Char_codeContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_char_code);
		try {
			setState(264);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case DECIMAL_CODE:
				_localctx = new DecimalCodeContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(259);
				match(DECIMAL_CODE);
				}
				break;
			case OCTAL_CODE:
				_localctx = new OctalCodeContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(260);
				match(OCTAL_CODE);
				}
				break;
			case HEXADECIMAL_CODE:
				_localctx = new HexCodeContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(261);
				match(HEXADECIMAL_CODE);
				}
				break;
			case UNICODE_CODE:
				_localctx = new HexCodeContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(262);
				match(UNICODE_CODE);
				}
				break;
			case WIDE_UNICODE_CODE:
				_localctx = new HexCodeContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(263);
				match(WIDE_UNICODE_CODE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0116\u010b\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0001\u0000\u0001"+
		"\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0005\u0001%\b"+
		"\u0001\n\u0001\f\u0001(\t\u0001\u0001\u0001\u0001\u0001\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0003\u00020\b\u0002\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0005\u00025\b\u0002\n\u0002\f\u00028\t\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0003\u0002>\b\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0005\u0002C\b\u0002\n\u0002\f\u0002F\t"+
		"\u0002\u0001\u0002\u0003\u0002I\b\u0002\u0001\u0003\u0004\u0003L\b\u0003"+
		"\u000b\u0003\f\u0003M\u0001\u0004\u0001\u0004\u0003\u0004R\b\u0004\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0003\u0005W\b\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0003\u0005\\\b\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0005\u0005a\b\u0005\n\u0005\f\u0005d\t\u0005\u0001\u0005\u0003"+
		"\u0005g\b\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001"+
		"\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001"+
		"\u0006\u0003\u0006t\b\u0006\u0001\u0007\u0001\u0007\u0003\u0007x\b\u0007"+
		"\u0001\u0007\u0001\u0007\u0003\u0007|\b\u0007\u0003\u0007~\b\u0007\u0001"+
		"\u0007\u0001\u0007\u0001\u0007\u0003\u0007\u0083\b\u0007\u0001\u0007\u0001"+
		"\u0007\u0003\u0007\u0087\b\u0007\u0003\u0007\u0089\b\u0007\u0001\u0007"+
		"\u0003\u0007\u008c\b\u0007\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b\u0001"+
		"\b\u0001\b\u0001\b\u0001\b\u0003\b\u0097\b\b\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001\t\u0001"+
		"\t\u0003\t\u00b8\b\t\u0001\n\u0001\n\u0001\n\u0005\n\u00bd\b\n\n\n\f\n"+
		"\u00c0\t\n\u0001\n\u0001\n\u0001\n\u0005\n\u00c5\b\n\n\n\f\n\u00c8\t\n"+
		"\u0001\n\u0003\n\u00cb\b\n\u0001\u000b\u0001\u000b\u0001\u000b\u0001\u000b"+
		"\u0001\u000b\u0003\u000b\u00d2\b\u000b\u0001\f\u0001\f\u0001\f\u0001\f"+
		"\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001"+
		"\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0003\f\u00e7\b\f\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0003\r\u0102\b\r\u0001"+
		"\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000e\u0003\u000e\u0109"+
		"\b\u000e\u0001\u000e\u0000\u0000\u000f\u0000\u0002\u0004\u0006\b\n\f\u000e"+
		"\u0010\u0012\u0014\u0016\u0018\u001a\u001c\u0000\u001c\u0003\u0000\u0005"+
		"\u0005OPpp\u0002\u0000\f\f33\u0002\u0000\r\r44\u0002\u0000\u000e\u000e"+
		"55\u0002\u0000\u000f\u000f66\u0002\u0000\u0010\u001077\u0002\u0000\u0011"+
		"\u001188\u0002\u0000\u0012\u001299\u0002\u0000\u0013\u0013::\u0002\u0000"+
		"\u0014\u0014;;\u0002\u0000\u0015\u0015<<\u0002\u0000\u0016\u0016==\u0002"+
		"\u0000\u0017\u0017>>\u0002\u0000\u0018\u0018??\u0002\u0000\u0019\u0019"+
		"@@\u0002\u0000\u001a\u001aAA\u0002\u0000\u001b\u001bBB\u0002\u0000\u001c"+
		"\u001cCC\u0002\u0000\u001d\u001dDD\u0002\u0000\u001e\u001eEE\u0002\u0000"+
		"\u001f\u001fFF\u0002\u0000  GG\u0002\u0000!!HH\u0002\u0000\"\"II\u0002"+
		"\u0000##JJ\u0002\u0000$$KK\u0002\u0000%%LL\u0003\u0000++OO\u0090\u0090"+
		"\u0176\u0000\u001e\u0001\u0000\u0000\u0000\u0002&\u0001\u0000\u0000\u0000"+
		"\u0004H\u0001\u0000\u0000\u0000\u0006K\u0001\u0000\u0000\u0000\bO\u0001"+
		"\u0000\u0000\u0000\nf\u0001\u0000\u0000\u0000\fs\u0001\u0000\u0000\u0000"+
		"\u000e\u008b\u0001\u0000\u0000\u0000\u0010\u0096\u0001\u0000\u0000\u0000"+
		"\u0012\u00b7\u0001\u0000\u0000\u0000\u0014\u00ca\u0001\u0000\u0000\u0000"+
		"\u0016\u00d1\u0001\u0000\u0000\u0000\u0018\u00e6\u0001\u0000\u0000\u0000"+
		"\u001a\u0101\u0001\u0000\u0000\u0000\u001c\u0108\u0001\u0000\u0000\u0000"+
		"\u001e\u001f\u0003\u0002\u0001\u0000\u001f \u0005\u0000\u0000\u0001 \u0001"+
		"\u0001\u0000\u0000\u0000!\"\u0003\u0004\u0002\u0000\"#\u0005\u0001\u0000"+
		"\u0000#%\u0001\u0000\u0000\u0000$!\u0001\u0000\u0000\u0000%(\u0001\u0000"+
		"\u0000\u0000&$\u0001\u0000\u0000\u0000&\'\u0001\u0000\u0000\u0000\')\u0001"+
		"\u0000\u0000\u0000(&\u0001\u0000\u0000\u0000)*\u0003\u0004\u0002\u0000"+
		"*\u0003\u0001\u0000\u0000\u0000+I\u0005O\u0000\u0000,I\u0005P\u0000\u0000"+
		"-I\u0005\u0002\u0000\u0000.0\u0005O\u0000\u0000/.\u0001\u0000\u0000\u0000"+
		"/0\u0001\u0000\u0000\u000006\u0001\u0000\u0000\u000012\u0003\u0006\u0003"+
		"\u000023\u0005\u0002\u0000\u000035\u0001\u0000\u0000\u000041\u0001\u0000"+
		"\u0000\u000058\u0001\u0000\u0000\u000064\u0001\u0000\u0000\u000067\u0001"+
		"\u0000\u0000\u000079\u0001\u0000\u0000\u000086\u0001\u0000\u0000\u0000"+
		"9:\u0003\u0006\u0003\u0000:;\u0005P\u0000\u0000;I\u0001\u0000\u0000\u0000"+
		"<>\u0005O\u0000\u0000=<\u0001\u0000\u0000\u0000=>\u0001\u0000\u0000\u0000"+
		">D\u0001\u0000\u0000\u0000?@\u0003\u0006\u0003\u0000@A\u0005\u0002\u0000"+
		"\u0000AC\u0001\u0000\u0000\u0000B?\u0001\u0000\u0000\u0000CF\u0001\u0000"+
		"\u0000\u0000DB\u0001\u0000\u0000\u0000DE\u0001\u0000\u0000\u0000EG\u0001"+
		"\u0000\u0000\u0000FD\u0001\u0000\u0000\u0000GI\u0003\u0006\u0003\u0000"+
		"H+\u0001\u0000\u0000\u0000H,\u0001\u0000\u0000\u0000H-\u0001\u0000\u0000"+
		"\u0000H/\u0001\u0000\u0000\u0000H=\u0001\u0000\u0000\u0000I\u0005\u0001"+
		"\u0000\u0000\u0000JL\u0003\b\u0004\u0000KJ\u0001\u0000\u0000\u0000LM\u0001"+
		"\u0000\u0000\u0000MK\u0001\u0000\u0000\u0000MN\u0001\u0000\u0000\u0000"+
		"N\u0007\u0001\u0000\u0000\u0000OQ\u0003\n\u0005\u0000PR\u0003\f\u0006"+
		"\u0000QP\u0001\u0000\u0000\u0000QR\u0001\u0000\u0000\u0000R\t\u0001\u0000"+
		"\u0000\u0000Sg\u0003\u0010\b\u0000TV\u0005\u0003\u0000\u0000UW\u0003\u0002"+
		"\u0001\u0000VU\u0001\u0000\u0000\u0000VW\u0001\u0000\u0000\u0000WX\u0001"+
		"\u0000\u0000\u0000Xg\u0005\u0004\u0000\u0000Y[\u0005-\u0000\u0000Z\\\u0003"+
		"\u0002\u0001\u0000[Z\u0001\u0000\u0000\u0000[\\\u0001\u0000\u0000\u0000"+
		"\\]\u0001\u0000\u0000\u0000]g\u0005\u0004\u0000\u0000^b\u0005o\u0000\u0000"+
		"_a\u0003\n\u0005\u0000`_\u0001\u0000\u0000\u0000ad\u0001\u0000\u0000\u0000"+
		"b`\u0001\u0000\u0000\u0000bc\u0001\u0000\u0000\u0000ce\u0001\u0000\u0000"+
		"\u0000db\u0001\u0000\u0000\u0000eg\u0005p\u0000\u0000fS\u0001\u0000\u0000"+
		"\u0000fT\u0001\u0000\u0000\u0000fY\u0001\u0000\u0000\u0000f^\u0001\u0000"+
		"\u0000\u0000g\u000b\u0001\u0000\u0000\u0000ht\u0005\u0007\u0000\u0000"+
		"it\u0005\b\u0000\u0000jt\u0005\t\u0000\u0000kt\u0003\u000e\u0007\u0000"+
		"lt\u0005S\u0000\u0000mt\u0005V\u0000\u0000nt\u0005W\u0000\u0000ot\u0005"+
		"X\u0000\u0000pt\u0005Y\u0000\u0000qt\u0005Z\u0000\u0000rt\u0005[\u0000"+
		"\u0000sh\u0001\u0000\u0000\u0000si\u0001\u0000\u0000\u0000sj\u0001\u0000"+
		"\u0000\u0000sk\u0001\u0000\u0000\u0000sl\u0001\u0000\u0000\u0000sm\u0001"+
		"\u0000\u0000\u0000sn\u0001\u0000\u0000\u0000so\u0001\u0000\u0000\u0000"+
		"sp\u0001\u0000\u0000\u0000sq\u0001\u0000\u0000\u0000sr\u0001\u0000\u0000"+
		"\u0000t\r\u0001\u0000\u0000\u0000uw\u0005\n\u0000\u0000vx\u0005\u008d"+
		"\u0000\u0000wv\u0001\u0000\u0000\u0000wx\u0001\u0000\u0000\u0000x}\u0001"+
		"\u0000\u0000\u0000y{\u0005\u008e\u0000\u0000z|\u0005\u008d\u0000\u0000"+
		"{z\u0001\u0000\u0000\u0000{|\u0001\u0000\u0000\u0000|~\u0001\u0000\u0000"+
		"\u0000}y\u0001\u0000\u0000\u0000}~\u0001\u0000\u0000\u0000~\u007f\u0001"+
		"\u0000\u0000\u0000\u007f\u008c\u0005\u008c\u0000\u0000\u0080\u0082\u0005"+
		"1\u0000\u0000\u0081\u0083\u0005\u008d\u0000\u0000\u0082\u0081\u0001\u0000"+
		"\u0000\u0000\u0082\u0083\u0001\u0000\u0000\u0000\u0083\u0088\u0001\u0000"+
		"\u0000\u0000\u0084\u0086\u0005\u008e\u0000\u0000\u0085\u0087\u0005\u008d"+
		"\u0000\u0000\u0086\u0085\u0001\u0000\u0000\u0000\u0086\u0087\u0001\u0000"+
		"\u0000\u0000\u0087\u0089\u0001\u0000\u0000\u0000\u0088\u0084\u0001\u0000"+
		"\u0000\u0000\u0088\u0089\u0001\u0000\u0000\u0000\u0089\u008a\u0001\u0000"+
		"\u0000\u0000\u008a\u008c\u0005\u008c\u0000\u0000\u008bu\u0001\u0000\u0000"+
		"\u0000\u008b\u0080\u0001\u0000\u0000\u0000\u008c\u000f\u0001\u0000\u0000"+
		"\u0000\u008d\u0097\u0007\u0000\u0000\u0000\u008e\u0097\u0005\u0006\u0000"+
		"\u0000\u008f\u0097\u00050\u0000\u0000\u0090\u0097\u00052\u0000\u0000\u0091"+
		"\u0097\u0005\\\u0000\u0000\u0092\u0097\u0003\u001a\r\u0000\u0093\u0097"+
		"\u0003\u0012\t\u0000\u0094\u0097\u0003\u0014\n\u0000\u0095\u0097\u0003"+
		"\u001c\u000e\u0000\u0096\u008d\u0001\u0000\u0000\u0000\u0096\u008e\u0001"+
		"\u0000\u0000\u0000\u0096\u008f\u0001\u0000\u0000\u0000\u0096\u0090\u0001"+
		"\u0000\u0000\u0000\u0096\u0091\u0001\u0000\u0000\u0000\u0096\u0092\u0001"+
		"\u0000\u0000\u0000\u0096\u0093\u0001\u0000\u0000\u0000\u0096\u0094\u0001"+
		"\u0000\u0000\u0000\u0096\u0095\u0001\u0000\u0000\u0000\u0097\u0011\u0001"+
		"\u0000\u0000\u0000\u0098\u00b8\u0007\u0001\u0000\u0000\u0099\u00b8\u0007"+
		"\u0002\u0000\u0000\u009a\u00b8\u0007\u0003\u0000\u0000\u009b\u00b8\u0007"+
		"\u0004\u0000\u0000\u009c\u00b8\u0007\u0005\u0000\u0000\u009d\u00b8\u0007"+
		"\u0006\u0000\u0000\u009e\u00b8\u0007\u0007\u0000\u0000\u009f\u00b8\u0007"+
		"\b\u0000\u0000\u00a0\u00b8\u0007\t\u0000\u0000\u00a1\u00b8\u0007\n\u0000"+
		"\u0000\u00a2\u00b8\u0007\u000b\u0000\u0000\u00a3\u00b8\u0007\f\u0000\u0000"+
		"\u00a4\u00b8\u0007\r\u0000\u0000\u00a5\u00b8\u0007\u000e\u0000\u0000\u00a6"+
		"\u00b8\u0007\u000f\u0000\u0000\u00a7\u00b8\u0007\u0010\u0000\u0000\u00a8"+
		"\u00b8\u0007\u0011\u0000\u0000\u00a9\u00b8\u0007\u0012\u0000\u0000\u00aa"+
		"\u00b8\u0007\u0013\u0000\u0000\u00ab\u00b8\u0007\u0014\u0000\u0000\u00ac"+
		"\u00b8\u0007\u0015\u0000\u0000\u00ad\u00b8\u0007\u0016\u0000\u0000\u00ae"+
		"\u00b8\u0007\u0017\u0000\u0000\u00af\u00b8\u0007\u0018\u0000\u0000\u00b0"+
		"\u00b8\u0007\u0019\u0000\u0000\u00b1\u00b8\u0007\u001a\u0000\u0000\u00b2"+
		"\u00b8\u0005&\u0000\u0000\u00b3\u00b8\u0005\'\u0000\u0000\u00b4\u00b8"+
		"\u0005(\u0000\u0000\u00b5\u00b8\u0005)\u0000\u0000\u00b6\u00b8\u0005*"+
		"\u0000\u0000\u00b7\u0098\u0001\u0000\u0000\u0000\u00b7\u0099\u0001\u0000"+
		"\u0000\u0000\u00b7\u009a\u0001\u0000\u0000\u0000\u00b7\u009b\u0001\u0000"+
		"\u0000\u0000\u00b7\u009c\u0001\u0000\u0000\u0000\u00b7\u009d\u0001\u0000"+
		"\u0000\u0000\u00b7\u009e\u0001\u0000\u0000\u0000\u00b7\u009f\u0001\u0000"+
		"\u0000\u0000\u00b7\u00a0\u0001\u0000\u0000\u0000\u00b7\u00a1\u0001\u0000"+
		"\u0000\u0000\u00b7\u00a2\u0001\u0000\u0000\u0000\u00b7\u00a3\u0001\u0000"+
		"\u0000\u0000\u00b7\u00a4\u0001\u0000\u0000\u0000\u00b7\u00a5\u0001\u0000"+
		"\u0000\u0000\u00b7\u00a6\u0001\u0000\u0000\u0000\u00b7\u00a7\u0001\u0000"+
		"\u0000\u0000\u00b7\u00a8\u0001\u0000\u0000\u0000\u00b7\u00a9\u0001\u0000"+
		"\u0000\u0000\u00b7\u00aa\u0001\u0000\u0000\u0000\u00b7\u00ab\u0001\u0000"+
		"\u0000\u0000\u00b7\u00ac\u0001\u0000\u0000\u0000\u00b7\u00ad\u0001\u0000"+
		"\u0000\u0000\u00b7\u00ae\u0001\u0000\u0000\u0000\u00b7\u00af\u0001\u0000"+
		"\u0000\u0000\u00b7\u00b0\u0001\u0000\u0000\u0000\u00b7\u00b1\u0001\u0000"+
		"\u0000\u0000\u00b7\u00b2\u0001\u0000\u0000\u0000\u00b7\u00b3\u0001\u0000"+
		"\u0000\u0000\u00b7\u00b4\u0001\u0000\u0000\u0000\u00b7\u00b5\u0001\u0000"+
		"\u0000\u0000\u00b7\u00b6\u0001\u0000\u0000\u0000\u00b8\u0013\u0001\u0000"+
		"\u0000\u0000\u00b9\u00ba\u0005\u000b\u0000\u0000\u00ba\u00be\u0005O\u0000"+
		"\u0000\u00bb\u00bd\u0003\u0016\u000b\u0000\u00bc\u00bb\u0001\u0000\u0000"+
		"\u0000\u00bd\u00c0\u0001\u0000\u0000\u0000\u00be\u00bc\u0001\u0000\u0000"+
		"\u0000\u00be\u00bf\u0001\u0000\u0000\u0000\u00bf\u00c1\u0001\u0000\u0000"+
		"\u0000\u00c0\u00be\u0001\u0000\u0000\u0000\u00c1\u00cb\u0005\u008f\u0000"+
		"\u0000\u00c2\u00c6\u0005\u000b\u0000\u0000\u00c3\u00c5\u0003\u0016\u000b"+
		"\u0000\u00c4\u00c3\u0001\u0000\u0000\u0000\u00c5\u00c8\u0001\u0000\u0000"+
		"\u0000\u00c6\u00c4\u0001\u0000\u0000\u0000\u00c6\u00c7\u0001\u0000\u0000"+
		"\u0000\u00c7\u00c9\u0001\u0000\u0000\u0000\u00c8\u00c6\u0001\u0000\u0000"+
		"\u0000\u00c9\u00cb\u0005\u008f\u0000\u0000\u00ca\u00b9\u0001\u0000\u0000"+
		"\u0000\u00ca\u00c2\u0001\u0000\u0000\u0000\u00cb\u0015\u0001\u0000\u0000"+
		"\u0000\u00cc\u00d2\u0003\u0018\f\u0000\u00cd\u00ce\u0007\u001b\u0000\u0000"+
		"\u00ce\u00cf\u0005\u0090\u0000\u0000\u00cf\u00d2\u0007\u001b\u0000\u0000"+
		"\u00d0\u00d2\u0007\u001b\u0000\u0000\u00d1\u00cc\u0001\u0000\u0000\u0000"+
		"\u00d1\u00cd\u0001\u0000\u0000\u0000\u00d1\u00d0\u0001\u0000\u0000\u0000"+
		"\u00d2\u0017\u0001\u0000\u0000\u0000\u00d3\u00e7\u0005\u0092\u0000\u0000"+
		"\u00d4\u00e7\u0005\u0091\u0000\u0000\u00d5\u00e7\u0005\u0093\u0000\u0000"+
		"\u00d6\u00e7\u0005\u0094\u0000\u0000\u00d7\u00e7\u0005\u0095\u0000\u0000"+
		"\u00d8\u00e7\u0005\u0096\u0000\u0000\u00d9\u00e7\u0005\u0097\u0000\u0000"+
		"\u00da\u00e7\u0005\u0098\u0000\u0000\u00db\u00e7\u0005\u0099\u0000\u0000"+
		"\u00dc\u00e7\u0005\u009a\u0000\u0000\u00dd\u00e7\u0005\u009b\u0000\u0000"+
		"\u00de\u00e7\u0005\u009c\u0000\u0000\u00df\u00e7\u0005\u009d\u0000\u0000"+
		"\u00e0\u00e7\u0005\u009e\u0000\u0000\u00e1\u00e7\u0005\u009f\u0000\u0000"+
		"\u00e2\u00e7\u0005\u00a0\u0000\u0000\u00e3\u00e7\u0005\u00a1\u0000\u0000"+
		"\u00e4\u00e7\u0005\u00a2\u0000\u0000\u00e5\u00e7\u0005\u00a3\u0000\u0000"+
		"\u00e6\u00d3\u0001\u0000\u0000\u0000\u00e6\u00d4\u0001\u0000\u0000\u0000"+
		"\u00e6\u00d5\u0001\u0000\u0000\u0000\u00e6\u00d6\u0001\u0000\u0000\u0000"+
		"\u00e6\u00d7\u0001\u0000\u0000\u0000\u00e6\u00d8\u0001\u0000\u0000\u0000"+
		"\u00e6\u00d9\u0001\u0000\u0000\u0000\u00e6\u00da\u0001\u0000\u0000\u0000"+
		"\u00e6\u00db\u0001\u0000\u0000\u0000\u00e6\u00dc\u0001\u0000\u0000\u0000"+
		"\u00e6\u00dd\u0001\u0000\u0000\u0000\u00e6\u00de\u0001\u0000\u0000\u0000"+
		"\u00e6\u00df\u0001\u0000\u0000\u0000\u00e6\u00e0\u0001\u0000\u0000\u0000"+
		"\u00e6\u00e1\u0001\u0000\u0000\u0000\u00e6\u00e2\u0001\u0000\u0000\u0000"+
		"\u00e6\u00e3\u0001\u0000\u0000\u0000\u00e6\u00e4\u0001\u0000\u0000\u0000"+
		"\u00e6\u00e5\u0001\u0000\u0000\u0000\u00e7\u0019\u0001\u0000\u0000\u0000"+
		"\u00e8\u0102\u0005,\u0000\u0000\u00e9\u0102\u0005]\u0000\u0000\u00ea\u0102"+
		"\u0005.\u0000\u0000\u00eb\u0102\u0005/\u0000\u0000\u00ec\u0102\u0005M"+
		"\u0000\u0000\u00ed\u0102\u0005N\u0000\u0000\u00ee\u0102\u0005Q\u0000\u0000"+
		"\u00ef\u0102\u0005R\u0000\u0000\u00f0\u0102\u0005T\u0000\u0000\u00f1\u0102"+
		"\u0005U\u0000\u0000\u00f2\u0102\u0005c\u0000\u0000\u00f3\u0102\u0005d"+
		"\u0000\u0000\u00f4\u0102\u0005e\u0000\u0000\u00f5\u0102\u0005i\u0000\u0000"+
		"\u00f6\u0102\u0005j\u0000\u0000\u00f7\u0102\u0005k\u0000\u0000\u00f8\u0102"+
		"\u0005f\u0000\u0000\u00f9\u0102\u0005g\u0000\u0000\u00fa\u0102\u0005h"+
		"\u0000\u0000\u00fb\u0102\u0005l\u0000\u0000\u00fc\u0102\u0005m\u0000\u0000"+
		"\u00fd\u0102\u0005n\u0000\u0000\u00fe\u0102\u0005q\u0000\u0000\u00ff\u0102"+
		"\u0005r\u0000\u0000\u0100\u0102\u0005s\u0000\u0000\u0101\u00e8\u0001\u0000"+
		"\u0000\u0000\u0101\u00e9\u0001\u0000\u0000\u0000\u0101\u00ea\u0001\u0000"+
		"\u0000\u0000\u0101\u00eb\u0001\u0000\u0000\u0000\u0101\u00ec\u0001\u0000"+
		"\u0000\u0000\u0101\u00ed\u0001\u0000\u0000\u0000\u0101\u00ee\u0001\u0000"+
		"\u0000\u0000\u0101\u00ef\u0001\u0000\u0000\u0000\u0101\u00f0\u0001\u0000"+
		"\u0000\u0000\u0101\u00f1\u0001\u0000\u0000\u0000\u0101\u00f2\u0001\u0000"+
		"\u0000\u0000\u0101\u00f3\u0001\u0000\u0000\u0000\u0101\u00f4\u0001\u0000"+
		"\u0000\u0000\u0101\u00f5\u0001\u0000\u0000\u0000\u0101\u00f6\u0001\u0000"+
		"\u0000\u0000\u0101\u00f7\u0001\u0000\u0000\u0000\u0101\u00f8\u0001\u0000"+
		"\u0000\u0000\u0101\u00f9\u0001\u0000\u0000\u0000\u0101\u00fa\u0001\u0000"+
		"\u0000\u0000\u0101\u00fb\u0001\u0000\u0000\u0000\u0101\u00fc\u0001\u0000"+
		"\u0000\u0000\u0101\u00fd\u0001\u0000\u0000\u0000\u0101\u00fe\u0001\u0000"+
		"\u0000\u0000\u0101\u00ff\u0001\u0000\u0000\u0000\u0101\u0100\u0001\u0000"+
		"\u0000\u0000\u0102\u001b\u0001\u0000\u0000\u0000\u0103\u0109\u0005^\u0000"+
		"\u0000\u0104\u0109\u0005_\u0000\u0000\u0105\u0109\u0005`\u0000\u0000\u0106"+
		"\u0109\u0005a\u0000\u0000\u0107\u0109\u0005b\u0000\u0000\u0108\u0103\u0001"+
		"\u0000\u0000\u0000\u0108\u0104\u0001\u0000\u0000\u0000\u0108\u0105\u0001"+
		"\u0000\u0000\u0000\u0108\u0106\u0001\u0000\u0000\u0000\u0108\u0107\u0001"+
		"\u0000\u0000\u0000\u0109\u001d\u0001\u0000\u0000\u0000\u001d&/6=DHMQV"+
		"[bfsw{}\u0082\u0086\u0088\u008b\u0096\u00b7\u00be\u00c6\u00ca\u00d1\u00e6"+
		"\u0101\u0108";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}