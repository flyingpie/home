// Generated from RegexParser.g4 by ANTLR 4.13.2
package com.maddyhome.idea.vim.parser.generated;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link RegexParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface RegexParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link RegexParser#pattern}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPattern(RegexParser.PatternContext ctx);
	/**
	 * Visit a parse tree produced by {@link RegexParser#sub_pattern}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSub_pattern(RegexParser.Sub_patternContext ctx);
	/**
	 * Visit a parse tree produced by {@link RegexParser#branch}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBranch(RegexParser.BranchContext ctx);
	/**
	 * Visit a parse tree produced by {@link RegexParser#concat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConcat(RegexParser.ConcatContext ctx);
	/**
	 * Visit a parse tree produced by {@link RegexParser#piece}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPiece(RegexParser.PieceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code OrdinaryAtom}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOrdinaryAtom(RegexParser.OrdinaryAtomContext ctx);
	/**
	 * Visit a parse tree produced by the {@code GroupingCapture}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroupingCapture(RegexParser.GroupingCaptureContext ctx);
	/**
	 * Visit a parse tree produced by the {@code GroupingNoCapture}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGroupingNoCapture(RegexParser.GroupingNoCaptureContext ctx);
	/**
	 * Visit a parse tree produced by the {@code OptionallyMatched}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOptionallyMatched(RegexParser.OptionallyMatchedContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ZeroOrMore}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitZeroOrMore(RegexParser.ZeroOrMoreContext ctx);
	/**
	 * Visit a parse tree produced by the {@code OneOrMore}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOneOrMore(RegexParser.OneOrMoreContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ZeroOrOne}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitZeroOrOne(RegexParser.ZeroOrOneContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RangeQuantifier}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeQuantifier(RegexParser.RangeQuantifierContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Atomic}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAtomic(RegexParser.AtomicContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PositiveLookahead}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveLookahead(RegexParser.PositiveLookaheadContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NegativeLookahead}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegativeLookahead(RegexParser.NegativeLookaheadContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PositiveLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveLookbehind(RegexParser.PositiveLookbehindContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NegativeLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegativeLookbehind(RegexParser.NegativeLookbehindContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PositiveLimitedLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPositiveLimitedLookbehind(RegexParser.PositiveLimitedLookbehindContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NegativeLimitedLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegativeLimitedLookbehind(RegexParser.NegativeLimitedLookbehindContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RangeGreedy}
	 * labeled alternative in {@link RegexParser#range}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeGreedy(RegexParser.RangeGreedyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RangeLazy}
	 * labeled alternative in {@link RegexParser#range}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeLazy(RegexParser.RangeLazyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LiteralChar}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLiteralChar(RegexParser.LiteralCharContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AnyChar}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyChar(RegexParser.AnyCharContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AnyCharNL}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAnyCharNL(RegexParser.AnyCharNLContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Backreference}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBackreference(RegexParser.BackreferenceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LastSubstitute}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLastSubstitute(RegexParser.LastSubstituteContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ZeroWidth}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitZeroWidth(RegexParser.ZeroWidthContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CharClass}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharClass(RegexParser.CharClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Collec}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollec(RegexParser.CollecContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CharCode}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharCode(RegexParser.CharCodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier(RegexParser.IdentifierContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IdentifierNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierNotDigit(RegexParser.IdentifierNotDigitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Keyword}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeyword(RegexParser.KeywordContext ctx);
	/**
	 * Visit a parse tree produced by the {@code KeywordNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeywordNotDigit(RegexParser.KeywordNotDigitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Filename}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilename(RegexParser.FilenameContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FilenameNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilenameNotDigit(RegexParser.FilenameNotDigitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Printable}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintable(RegexParser.PrintableContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PrintableNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintableNotDigit(RegexParser.PrintableNotDigitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Whitespace}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhitespace(RegexParser.WhitespaceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotWhitespace}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotWhitespace(RegexParser.NotWhitespaceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Digit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDigit(RegexParser.DigitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotDigit(RegexParser.NotDigitContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Hex}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHex(RegexParser.HexContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotHex}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotHex(RegexParser.NotHexContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Octal}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOctal(RegexParser.OctalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotOctal}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotOctal(RegexParser.NotOctalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Wordchar}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWordchar(RegexParser.WordcharContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Notwordchar}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotwordchar(RegexParser.NotwordcharContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Headofword}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHeadofword(RegexParser.HeadofwordContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotHeadOfWord}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotHeadOfWord(RegexParser.NotHeadOfWordContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Alpha}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlpha(RegexParser.AlphaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotAlpha}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotAlpha(RegexParser.NotAlphaContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Lcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLcase(RegexParser.LcaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotLcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotLcase(RegexParser.NotLcaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Ucase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUcase(RegexParser.UcaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NotUcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNotUcase(RegexParser.NotUcaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Esc}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEsc(RegexParser.EscContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Tab}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTab(RegexParser.TabContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CR}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCR(RegexParser.CRContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BS}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBS(RegexParser.BSContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NL}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNL(RegexParser.NLContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CollectionNeg}
	 * labeled alternative in {@link RegexParser#collection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollectionNeg(RegexParser.CollectionNegContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CollectionPos}
	 * labeled alternative in {@link RegexParser#collection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCollectionPos(RegexParser.CollectionPosContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CharClassColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharClassColElem(RegexParser.CharClassColElemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RangeColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRangeColElem(RegexParser.RangeColElemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code SingleColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSingleColElem(RegexParser.SingleColElemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AlphaClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlphaClass(RegexParser.AlphaClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AlnumClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlnumClass(RegexParser.AlnumClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BlankClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlankClass(RegexParser.BlankClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CntrlClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCntrlClass(RegexParser.CntrlClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code DigitClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDigitClass(RegexParser.DigitClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code GraphClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGraphClass(RegexParser.GraphClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LowerClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLowerClass(RegexParser.LowerClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PrintClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintClass(RegexParser.PrintClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PunctClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPunctClass(RegexParser.PunctClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code SpaceClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSpaceClass(RegexParser.SpaceClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UpperClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUpperClass(RegexParser.UpperClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code XdigitClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitXdigitClass(RegexParser.XdigitClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ReturnClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnClass(RegexParser.ReturnClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code TabClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTabClass(RegexParser.TabClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EscapeClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEscapeClass(RegexParser.EscapeClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BackspaceClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBackspaceClass(RegexParser.BackspaceClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IdentClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentClass(RegexParser.IdentClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code KeywordClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeywordClass(RegexParser.KeywordClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FnameClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFnameClass(RegexParser.FnameClassContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Cursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCursor(RegexParser.CursorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Visual}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVisual(RegexParser.VisualContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StartMatch}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStartMatch(RegexParser.StartMatchContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EndMatch}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndMatch(RegexParser.EndMatchContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StartOfFile}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStartOfFile(RegexParser.StartOfFileContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EndOfFile}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndOfFile(RegexParser.EndOfFileContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StartOfLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStartOfLine(RegexParser.StartOfLineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EndOfLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndOfLine(RegexParser.EndOfLineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StartOfWord}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStartOfWord(RegexParser.StartOfWordContext ctx);
	/**
	 * Visit a parse tree produced by the {@code EndOfWord}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndOfWord(RegexParser.EndOfWordContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Line}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLine(RegexParser.LineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BeforeLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBeforeLine(RegexParser.BeforeLineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AfterLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAfterLine(RegexParser.AfterLineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLineCursor(RegexParser.LineCursorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BeforeLineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBeforeLineCursor(RegexParser.BeforeLineCursorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AfterLineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAfterLineCursor(RegexParser.AfterLineCursorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Column}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumn(RegexParser.ColumnContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BeforeColumn}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBeforeColumn(RegexParser.BeforeColumnContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AfterColumn}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAfterColumn(RegexParser.AfterColumnContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitColumnCursor(RegexParser.ColumnCursorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BeforeColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBeforeColumnCursor(RegexParser.BeforeColumnCursorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AfterColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAfterColumnCursor(RegexParser.AfterColumnCursorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Mark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMark(RegexParser.MarkContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BeforeMark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBeforeMark(RegexParser.BeforeMarkContext ctx);
	/**
	 * Visit a parse tree produced by the {@code AfterMark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAfterMark(RegexParser.AfterMarkContext ctx);
	/**
	 * Visit a parse tree produced by the {@code DecimalCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDecimalCode(RegexParser.DecimalCodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code OctalCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOctalCode(RegexParser.OctalCodeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code HexCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitHexCode(RegexParser.HexCodeContext ctx);
}