// Generated from RegexParser.g4 by ANTLR 4.13.2
package com.maddyhome.idea.vim.parser.generated;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link RegexParser}.
 */
public interface RegexParserListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link RegexParser#pattern}.
	 * @param ctx the parse tree
	 */
	void enterPattern(RegexParser.PatternContext ctx);
	/**
	 * Exit a parse tree produced by {@link RegexParser#pattern}.
	 * @param ctx the parse tree
	 */
	void exitPattern(RegexParser.PatternContext ctx);
	/**
	 * Enter a parse tree produced by {@link RegexParser#sub_pattern}.
	 * @param ctx the parse tree
	 */
	void enterSub_pattern(RegexParser.Sub_patternContext ctx);
	/**
	 * Exit a parse tree produced by {@link RegexParser#sub_pattern}.
	 * @param ctx the parse tree
	 */
	void exitSub_pattern(RegexParser.Sub_patternContext ctx);
	/**
	 * Enter a parse tree produced by {@link RegexParser#branch}.
	 * @param ctx the parse tree
	 */
	void enterBranch(RegexParser.BranchContext ctx);
	/**
	 * Exit a parse tree produced by {@link RegexParser#branch}.
	 * @param ctx the parse tree
	 */
	void exitBranch(RegexParser.BranchContext ctx);
	/**
	 * Enter a parse tree produced by {@link RegexParser#concat}.
	 * @param ctx the parse tree
	 */
	void enterConcat(RegexParser.ConcatContext ctx);
	/**
	 * Exit a parse tree produced by {@link RegexParser#concat}.
	 * @param ctx the parse tree
	 */
	void exitConcat(RegexParser.ConcatContext ctx);
	/**
	 * Enter a parse tree produced by {@link RegexParser#piece}.
	 * @param ctx the parse tree
	 */
	void enterPiece(RegexParser.PieceContext ctx);
	/**
	 * Exit a parse tree produced by {@link RegexParser#piece}.
	 * @param ctx the parse tree
	 */
	void exitPiece(RegexParser.PieceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code OrdinaryAtom}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterOrdinaryAtom(RegexParser.OrdinaryAtomContext ctx);
	/**
	 * Exit a parse tree produced by the {@code OrdinaryAtom}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitOrdinaryAtom(RegexParser.OrdinaryAtomContext ctx);
	/**
	 * Enter a parse tree produced by the {@code GroupingCapture}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterGroupingCapture(RegexParser.GroupingCaptureContext ctx);
	/**
	 * Exit a parse tree produced by the {@code GroupingCapture}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitGroupingCapture(RegexParser.GroupingCaptureContext ctx);
	/**
	 * Enter a parse tree produced by the {@code GroupingNoCapture}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterGroupingNoCapture(RegexParser.GroupingNoCaptureContext ctx);
	/**
	 * Exit a parse tree produced by the {@code GroupingNoCapture}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitGroupingNoCapture(RegexParser.GroupingNoCaptureContext ctx);
	/**
	 * Enter a parse tree produced by the {@code OptionallyMatched}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void enterOptionallyMatched(RegexParser.OptionallyMatchedContext ctx);
	/**
	 * Exit a parse tree produced by the {@code OptionallyMatched}
	 * labeled alternative in {@link RegexParser#atom}.
	 * @param ctx the parse tree
	 */
	void exitOptionallyMatched(RegexParser.OptionallyMatchedContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ZeroOrMore}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterZeroOrMore(RegexParser.ZeroOrMoreContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ZeroOrMore}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitZeroOrMore(RegexParser.ZeroOrMoreContext ctx);
	/**
	 * Enter a parse tree produced by the {@code OneOrMore}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterOneOrMore(RegexParser.OneOrMoreContext ctx);
	/**
	 * Exit a parse tree produced by the {@code OneOrMore}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitOneOrMore(RegexParser.OneOrMoreContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ZeroOrOne}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterZeroOrOne(RegexParser.ZeroOrOneContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ZeroOrOne}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitZeroOrOne(RegexParser.ZeroOrOneContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RangeQuantifier}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterRangeQuantifier(RegexParser.RangeQuantifierContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RangeQuantifier}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitRangeQuantifier(RegexParser.RangeQuantifierContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Atomic}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterAtomic(RegexParser.AtomicContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Atomic}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitAtomic(RegexParser.AtomicContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PositiveLookahead}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterPositiveLookahead(RegexParser.PositiveLookaheadContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PositiveLookahead}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitPositiveLookahead(RegexParser.PositiveLookaheadContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NegativeLookahead}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterNegativeLookahead(RegexParser.NegativeLookaheadContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NegativeLookahead}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitNegativeLookahead(RegexParser.NegativeLookaheadContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PositiveLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterPositiveLookbehind(RegexParser.PositiveLookbehindContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PositiveLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitPositiveLookbehind(RegexParser.PositiveLookbehindContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NegativeLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterNegativeLookbehind(RegexParser.NegativeLookbehindContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NegativeLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitNegativeLookbehind(RegexParser.NegativeLookbehindContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PositiveLimitedLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterPositiveLimitedLookbehind(RegexParser.PositiveLimitedLookbehindContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PositiveLimitedLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitPositiveLimitedLookbehind(RegexParser.PositiveLimitedLookbehindContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NegativeLimitedLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void enterNegativeLimitedLookbehind(RegexParser.NegativeLimitedLookbehindContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NegativeLimitedLookbehind}
	 * labeled alternative in {@link RegexParser#multi}.
	 * @param ctx the parse tree
	 */
	void exitNegativeLimitedLookbehind(RegexParser.NegativeLimitedLookbehindContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RangeGreedy}
	 * labeled alternative in {@link RegexParser#range}.
	 * @param ctx the parse tree
	 */
	void enterRangeGreedy(RegexParser.RangeGreedyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RangeGreedy}
	 * labeled alternative in {@link RegexParser#range}.
	 * @param ctx the parse tree
	 */
	void exitRangeGreedy(RegexParser.RangeGreedyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RangeLazy}
	 * labeled alternative in {@link RegexParser#range}.
	 * @param ctx the parse tree
	 */
	void enterRangeLazy(RegexParser.RangeLazyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RangeLazy}
	 * labeled alternative in {@link RegexParser#range}.
	 * @param ctx the parse tree
	 */
	void exitRangeLazy(RegexParser.RangeLazyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LiteralChar}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterLiteralChar(RegexParser.LiteralCharContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LiteralChar}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitLiteralChar(RegexParser.LiteralCharContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AnyChar}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterAnyChar(RegexParser.AnyCharContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AnyChar}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitAnyChar(RegexParser.AnyCharContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AnyCharNL}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterAnyCharNL(RegexParser.AnyCharNLContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AnyCharNL}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitAnyCharNL(RegexParser.AnyCharNLContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Backreference}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterBackreference(RegexParser.BackreferenceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Backreference}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitBackreference(RegexParser.BackreferenceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LastSubstitute}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterLastSubstitute(RegexParser.LastSubstituteContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LastSubstitute}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitLastSubstitute(RegexParser.LastSubstituteContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ZeroWidth}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterZeroWidth(RegexParser.ZeroWidthContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ZeroWidth}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitZeroWidth(RegexParser.ZeroWidthContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CharClass}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterCharClass(RegexParser.CharClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CharClass}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitCharClass(RegexParser.CharClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Collec}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterCollec(RegexParser.CollecContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Collec}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitCollec(RegexParser.CollecContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CharCode}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void enterCharCode(RegexParser.CharCodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CharCode}
	 * labeled alternative in {@link RegexParser#ordinary_atom}.
	 * @param ctx the parse tree
	 */
	void exitCharCode(RegexParser.CharCodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(RegexParser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(RegexParser.IdentifierContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IdentifierNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierNotDigit(RegexParser.IdentifierNotDigitContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IdentifierNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierNotDigit(RegexParser.IdentifierNotDigitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Keyword}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterKeyword(RegexParser.KeywordContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Keyword}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitKeyword(RegexParser.KeywordContext ctx);
	/**
	 * Enter a parse tree produced by the {@code KeywordNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterKeywordNotDigit(RegexParser.KeywordNotDigitContext ctx);
	/**
	 * Exit a parse tree produced by the {@code KeywordNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitKeywordNotDigit(RegexParser.KeywordNotDigitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Filename}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterFilename(RegexParser.FilenameContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Filename}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitFilename(RegexParser.FilenameContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FilenameNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterFilenameNotDigit(RegexParser.FilenameNotDigitContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FilenameNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitFilenameNotDigit(RegexParser.FilenameNotDigitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Printable}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterPrintable(RegexParser.PrintableContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Printable}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitPrintable(RegexParser.PrintableContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PrintableNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterPrintableNotDigit(RegexParser.PrintableNotDigitContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PrintableNotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitPrintableNotDigit(RegexParser.PrintableNotDigitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Whitespace}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterWhitespace(RegexParser.WhitespaceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Whitespace}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitWhitespace(RegexParser.WhitespaceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotWhitespace}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotWhitespace(RegexParser.NotWhitespaceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotWhitespace}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotWhitespace(RegexParser.NotWhitespaceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Digit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterDigit(RegexParser.DigitContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Digit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitDigit(RegexParser.DigitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotDigit(RegexParser.NotDigitContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotDigit}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotDigit(RegexParser.NotDigitContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Hex}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterHex(RegexParser.HexContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Hex}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitHex(RegexParser.HexContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotHex}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotHex(RegexParser.NotHexContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotHex}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotHex(RegexParser.NotHexContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Octal}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterOctal(RegexParser.OctalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Octal}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitOctal(RegexParser.OctalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotOctal}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotOctal(RegexParser.NotOctalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotOctal}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotOctal(RegexParser.NotOctalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Wordchar}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterWordchar(RegexParser.WordcharContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Wordchar}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitWordchar(RegexParser.WordcharContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Notwordchar}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotwordchar(RegexParser.NotwordcharContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Notwordchar}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotwordchar(RegexParser.NotwordcharContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Headofword}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterHeadofword(RegexParser.HeadofwordContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Headofword}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitHeadofword(RegexParser.HeadofwordContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotHeadOfWord}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotHeadOfWord(RegexParser.NotHeadOfWordContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotHeadOfWord}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotHeadOfWord(RegexParser.NotHeadOfWordContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Alpha}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterAlpha(RegexParser.AlphaContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Alpha}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitAlpha(RegexParser.AlphaContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotAlpha}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotAlpha(RegexParser.NotAlphaContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotAlpha}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotAlpha(RegexParser.NotAlphaContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Lcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterLcase(RegexParser.LcaseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Lcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitLcase(RegexParser.LcaseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotLcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotLcase(RegexParser.NotLcaseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotLcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotLcase(RegexParser.NotLcaseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Ucase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterUcase(RegexParser.UcaseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Ucase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitUcase(RegexParser.UcaseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NotUcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNotUcase(RegexParser.NotUcaseContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NotUcase}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNotUcase(RegexParser.NotUcaseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Esc}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterEsc(RegexParser.EscContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Esc}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitEsc(RegexParser.EscContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Tab}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterTab(RegexParser.TabContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Tab}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitTab(RegexParser.TabContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CR}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterCR(RegexParser.CRContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CR}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitCR(RegexParser.CRContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BS}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterBS(RegexParser.BSContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BS}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitBS(RegexParser.BSContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NL}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void enterNL(RegexParser.NLContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NL}
	 * labeled alternative in {@link RegexParser#char_class}.
	 * @param ctx the parse tree
	 */
	void exitNL(RegexParser.NLContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CollectionNeg}
	 * labeled alternative in {@link RegexParser#collection}.
	 * @param ctx the parse tree
	 */
	void enterCollectionNeg(RegexParser.CollectionNegContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CollectionNeg}
	 * labeled alternative in {@link RegexParser#collection}.
	 * @param ctx the parse tree
	 */
	void exitCollectionNeg(RegexParser.CollectionNegContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CollectionPos}
	 * labeled alternative in {@link RegexParser#collection}.
	 * @param ctx the parse tree
	 */
	void enterCollectionPos(RegexParser.CollectionPosContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CollectionPos}
	 * labeled alternative in {@link RegexParser#collection}.
	 * @param ctx the parse tree
	 */
	void exitCollectionPos(RegexParser.CollectionPosContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CharClassColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 */
	void enterCharClassColElem(RegexParser.CharClassColElemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CharClassColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 */
	void exitCharClassColElem(RegexParser.CharClassColElemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RangeColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 */
	void enterRangeColElem(RegexParser.RangeColElemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RangeColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 */
	void exitRangeColElem(RegexParser.RangeColElemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code SingleColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 */
	void enterSingleColElem(RegexParser.SingleColElemContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SingleColElem}
	 * labeled alternative in {@link RegexParser#collection_elem}.
	 * @param ctx the parse tree
	 */
	void exitSingleColElem(RegexParser.SingleColElemContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AlphaClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterAlphaClass(RegexParser.AlphaClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AlphaClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitAlphaClass(RegexParser.AlphaClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AlnumClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterAlnumClass(RegexParser.AlnumClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AlnumClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitAlnumClass(RegexParser.AlnumClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BlankClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterBlankClass(RegexParser.BlankClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BlankClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitBlankClass(RegexParser.BlankClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CntrlClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterCntrlClass(RegexParser.CntrlClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CntrlClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitCntrlClass(RegexParser.CntrlClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code DigitClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterDigitClass(RegexParser.DigitClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code DigitClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitDigitClass(RegexParser.DigitClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code GraphClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterGraphClass(RegexParser.GraphClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code GraphClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitGraphClass(RegexParser.GraphClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LowerClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterLowerClass(RegexParser.LowerClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LowerClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitLowerClass(RegexParser.LowerClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PrintClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterPrintClass(RegexParser.PrintClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PrintClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitPrintClass(RegexParser.PrintClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PunctClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterPunctClass(RegexParser.PunctClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PunctClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitPunctClass(RegexParser.PunctClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code SpaceClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterSpaceClass(RegexParser.SpaceClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SpaceClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitSpaceClass(RegexParser.SpaceClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UpperClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterUpperClass(RegexParser.UpperClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code UpperClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitUpperClass(RegexParser.UpperClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code XdigitClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterXdigitClass(RegexParser.XdigitClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code XdigitClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitXdigitClass(RegexParser.XdigitClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ReturnClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterReturnClass(RegexParser.ReturnClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ReturnClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitReturnClass(RegexParser.ReturnClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code TabClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterTabClass(RegexParser.TabClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code TabClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitTabClass(RegexParser.TabClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EscapeClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterEscapeClass(RegexParser.EscapeClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EscapeClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitEscapeClass(RegexParser.EscapeClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BackspaceClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterBackspaceClass(RegexParser.BackspaceClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BackspaceClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitBackspaceClass(RegexParser.BackspaceClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IdentClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterIdentClass(RegexParser.IdentClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IdentClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitIdentClass(RegexParser.IdentClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code KeywordClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterKeywordClass(RegexParser.KeywordClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code KeywordClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitKeywordClass(RegexParser.KeywordClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FnameClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void enterFnameClass(RegexParser.FnameClassContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FnameClass}
	 * labeled alternative in {@link RegexParser#collection_char_class_expression}.
	 * @param ctx the parse tree
	 */
	void exitFnameClass(RegexParser.FnameClassContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Cursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterCursor(RegexParser.CursorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Cursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitCursor(RegexParser.CursorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Visual}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterVisual(RegexParser.VisualContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Visual}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitVisual(RegexParser.VisualContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StartMatch}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterStartMatch(RegexParser.StartMatchContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StartMatch}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitStartMatch(RegexParser.StartMatchContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EndMatch}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterEndMatch(RegexParser.EndMatchContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EndMatch}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitEndMatch(RegexParser.EndMatchContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StartOfFile}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterStartOfFile(RegexParser.StartOfFileContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StartOfFile}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitStartOfFile(RegexParser.StartOfFileContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EndOfFile}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterEndOfFile(RegexParser.EndOfFileContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EndOfFile}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitEndOfFile(RegexParser.EndOfFileContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StartOfLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterStartOfLine(RegexParser.StartOfLineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StartOfLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitStartOfLine(RegexParser.StartOfLineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EndOfLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterEndOfLine(RegexParser.EndOfLineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EndOfLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitEndOfLine(RegexParser.EndOfLineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StartOfWord}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterStartOfWord(RegexParser.StartOfWordContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StartOfWord}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitStartOfWord(RegexParser.StartOfWordContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EndOfWord}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterEndOfWord(RegexParser.EndOfWordContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EndOfWord}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitEndOfWord(RegexParser.EndOfWordContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Line}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterLine(RegexParser.LineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Line}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitLine(RegexParser.LineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BeforeLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterBeforeLine(RegexParser.BeforeLineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BeforeLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitBeforeLine(RegexParser.BeforeLineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AfterLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterAfterLine(RegexParser.AfterLineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AfterLine}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitAfterLine(RegexParser.AfterLineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterLineCursor(RegexParser.LineCursorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitLineCursor(RegexParser.LineCursorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BeforeLineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterBeforeLineCursor(RegexParser.BeforeLineCursorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BeforeLineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitBeforeLineCursor(RegexParser.BeforeLineCursorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AfterLineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterAfterLineCursor(RegexParser.AfterLineCursorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AfterLineCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitAfterLineCursor(RegexParser.AfterLineCursorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Column}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterColumn(RegexParser.ColumnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Column}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitColumn(RegexParser.ColumnContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BeforeColumn}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterBeforeColumn(RegexParser.BeforeColumnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BeforeColumn}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitBeforeColumn(RegexParser.BeforeColumnContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AfterColumn}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterAfterColumn(RegexParser.AfterColumnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AfterColumn}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitAfterColumn(RegexParser.AfterColumnContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterColumnCursor(RegexParser.ColumnCursorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitColumnCursor(RegexParser.ColumnCursorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BeforeColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterBeforeColumnCursor(RegexParser.BeforeColumnCursorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BeforeColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitBeforeColumnCursor(RegexParser.BeforeColumnCursorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AfterColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterAfterColumnCursor(RegexParser.AfterColumnCursorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AfterColumnCursor}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitAfterColumnCursor(RegexParser.AfterColumnCursorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Mark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterMark(RegexParser.MarkContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Mark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitMark(RegexParser.MarkContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BeforeMark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterBeforeMark(RegexParser.BeforeMarkContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BeforeMark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitBeforeMark(RegexParser.BeforeMarkContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AfterMark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void enterAfterMark(RegexParser.AfterMarkContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AfterMark}
	 * labeled alternative in {@link RegexParser#zero_width}.
	 * @param ctx the parse tree
	 */
	void exitAfterMark(RegexParser.AfterMarkContext ctx);
	/**
	 * Enter a parse tree produced by the {@code DecimalCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 */
	void enterDecimalCode(RegexParser.DecimalCodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code DecimalCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 */
	void exitDecimalCode(RegexParser.DecimalCodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code OctalCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 */
	void enterOctalCode(RegexParser.OctalCodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code OctalCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 */
	void exitOctalCode(RegexParser.OctalCodeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code HexCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 */
	void enterHexCode(RegexParser.HexCodeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code HexCode}
	 * labeled alternative in {@link RegexParser#char_code}.
	 * @param ctx the parse tree
	 */
	void exitHexCode(RegexParser.HexCodeContext ctx);
}