/*
 * Copyright 2003-2026 The IdeaVim authors
 *
 * Use of this source code is governed by an MIT-style
 * license that can be found in the LICENSE.txt file or at
 * https://opensource.org/licenses/MIT.
 */

package com.maddyhome.idea.vim.vimscript.model.functions

object IntellijFunctionProvider : VimscriptFunctionProvider {
  override val functionListFileName: String = "frontend_vimscript_functions.json"
}