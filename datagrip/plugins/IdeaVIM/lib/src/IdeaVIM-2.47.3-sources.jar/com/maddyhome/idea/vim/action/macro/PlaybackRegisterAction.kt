/*
 * Copyright 2003-2023 The IdeaVim authors
 *
 * Use of this source code is governed by an MIT-style
 * license that can be found in the LICENSE.txt file or at
 * https://opensource.org/licenses/MIT.
 */
package com.maddyhome.idea.vim.action.macro

import com.intellij.vim.annotations.CommandOrMotion
import com.intellij.vim.annotations.Mode
import com.maddyhome.idea.vim.api.ExecutionContext
import com.maddyhome.idea.vim.api.VimEditor
import com.maddyhome.idea.vim.api.injector
import com.maddyhome.idea.vim.command.Argument
import com.maddyhome.idea.vim.command.Command
import com.maddyhome.idea.vim.command.OperatorArguments
import com.maddyhome.idea.vim.ex.ExException
import com.maddyhome.idea.vim.handler.VimActionHandler
import com.maddyhome.idea.vim.register.RegisterConstants.LAST_COMMAND_REGISTER

@CommandOrMotion(keys = ["@"], modes = [Mode.NORMAL])
class PlaybackRegisterAction : VimActionHandler.SingleExecution() {
  override val type: Command.Type = Command.Type.OTHER_SELF_SYNCHRONIZED
  override val argumentType: Argument.Type = Argument.Type.REGISTER

  // Replay each macro keystroke as its own command so a `u` inside the macro can undo earlier macro changes
  override val executesNestedCommands: Boolean = true

  override fun execute(
    editor: VimEditor,
    context: ExecutionContext,
    cmd: Command,
    operatorArguments: OperatorArguments,
  ): Boolean {
    val argument = cmd.argument as? Argument.Character ?: return false
    val reg = argument.character
    return when {
      reg == LAST_COMMAND_REGISTER || (reg == '@' && injector.macro.lastRegister == LAST_COMMAND_REGISTER) -> {
        try {
          var success = false
          for (i in 0 until cmd.count) {
            // Unlike `@reg`, the last-command path doesn't replay keystrokes through the key handler, so it isn't
            // wrapped in a command by anyone (this action runs without an outer command, see [executesNestedCommands]).
            // Give each execution its own command so the document write is valid and independently undoable, as in Vim.
            injector.actionExecutor.executeCommand(editor, {
              success = injector.vimscriptExecutor.executeLastCommand(editor, context)
            }, id, null)
            if (!success) break
          }
          if (reg != '@') { // @ is not a register itself, it just tells vim to use the last register
            injector.macro.lastRegister = reg
          }
          success
        } catch (_: ExException) {
          false
        }
      }

      reg == '@' -> injector.macro.playbackLastRegister(editor, context, cmd.count)

      else -> injector.macro.playbackRegister(editor, context, reg, cmd.count)
    }
  }
}
